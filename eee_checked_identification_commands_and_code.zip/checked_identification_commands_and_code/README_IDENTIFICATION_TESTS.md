# Load-transfer identification test package

Files:
- `run_oc_simple_time_sim_arbitrary.m`: simulator with optional identification.
- `my_model.m`: model parameterized with runtime `pv = [kappa; H; q1; q2]`.
- `my_params.m`: unchanged user parameter file.
- `run_identification_tests_one_by_one.m`: MATLAB command script with independent test sections.

Recommended order:
1. Run Test 0 in `run_identification_tests_one_by_one.m`: simulation only.
2. Run Test 1: clean Fz-only identification.
3. Run Tests 2-4: different Fz noise levels.
4. Run Test 5: Fz+Fx+Fy joint target.
5. Run Tests 6-8: immediate, uniform, and late horizon weighting.

Default simulation behavior is unchanged when:
```matlab
opts.do_identification = false;
```

Identification is optional and runs only when:
```matlab
opts.do_identification = true;
```

For clean self-generated data, the identified values should be close to:
```matlab
veh.H
veh.q1
veh.q2
veh.d
```

If noisy tests have high standard deviation, the maneuver/noise level does not robustly identify the parameter.
