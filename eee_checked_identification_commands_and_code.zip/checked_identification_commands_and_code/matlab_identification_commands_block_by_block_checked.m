% MATLAB COMMANDS FOR LOAD-TRANSFER IDENTIFICATION TESTS
% =========================================================

% Put these files in the same MATLAB folder before running:
%   run_oc_simple_time_sim_arbitrary.m
%   my_model.m
%   my_params.m

% Recommended order:
%   Test 0 -> Test 1 -> Test 3 -> then continue with the rest.


% =========================================================
%% TEST 0 — Simulation only, no identification
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;              % faster first test
opts.do_plot = true;
opts.do_identification = false;    % simulation only

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);


% =========================================================
%% TEST 1 — Clean Fz-only identification
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = true;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = false;
opts.ident_plot = true;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

veh = model.veh;

fprintf('\nExpected nominal parameters:\n');
fprintf('veh.H  = %.6f m\n', veh.H);
fprintf('veh.q1 = %.6f m\n', veh.q1);
fprintf('veh.q2 = %.6f m\n', veh.q2);
fprintf('veh.d  = %.6f m\n', veh.d);

fprintf('\nIdentified free [H,q1,q2]:\n');
fprintf('H  = %.6f m\n', id_result.free.H);
fprintf('q1 = %.6f m\n', id_result.free.q1);
fprintf('q2 = %.6f m\n', id_result.free.q2);

fprintf('\nIdentified scalar d:\n');
fprintf('d  = %.6f m\n', id_result.scalar_d.d);
fprintf('H  = %.6f m\n', id_result.scalar_d.H);

disp(id_result.consistency);
disp(id_result.recommendation);


% =========================================================
%% TEST 2 — Noisy Fz robustness, low noise: 20 N
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 10;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 20;      % low Fz noise [N]
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;
veh = model.veh;

fprintf('\nNominal:\n');
fprintf('H  = %.6f, q1 = %.6f, q2 = %.6f, d = %.6f\n', ...
    veh.H, veh.q1, veh.q2, veh.d);

fprintf('\nMonte Carlo free [H,q1,q2], mean +/- std:\n');
fprintf('H  = %.6f +/- %.6f\n', mc.free_mean(1), mc.free_std(1));
fprintf('q1 = %.6f +/- %.6f\n', mc.free_mean(2), mc.free_std(2));
fprintf('q2 = %.6f +/- %.6f\n', mc.free_mean(3), mc.free_std(3));

fprintf('\nMonte Carlo scalar d, mean +/- std:\n');
fprintf('d  = %.6f +/- %.6f\n', mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 3 — Noisy Fz robustness, medium noise: 50 N
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 20;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 50;      % medium Fz noise [N]
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;
veh = model.veh;

fprintf('\nNominal:\n');
fprintf('H  = %.6f, q1 = %.6f, q2 = %.6f, d = %.6f\n', ...
    veh.H, veh.q1, veh.q2, veh.d);

fprintf('\nMonte Carlo free [H,q1,q2], mean +/- std:\n');
fprintf('H  = %.6f +/- %.6f\n', mc.free_mean(1), mc.free_std(1));
fprintf('q1 = %.6f +/- %.6f\n', mc.free_mean(2), mc.free_std(2));
fprintf('q2 = %.6f +/- %.6f\n', mc.free_mean(3), mc.free_std(3));

fprintf('\nMonte Carlo scalar d, mean +/- std:\n');
fprintf('d  = %.6f +/- %.6f\n', mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 4 — Noisy Fz robustness, high noise: 100 N
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 30;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 100;     % high Fz noise [N]
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;
veh = model.veh;

fprintf('\nNominal:\n');
fprintf('H  = %.6f, q1 = %.6f, q2 = %.6f, d = %.6f\n', ...
    veh.H, veh.q1, veh.q2, veh.d);

fprintf('\nMonte Carlo free [H,q1,q2], mean +/- std:\n');
fprintf('H  = %.6f +/- %.6f\n', mc.free_mean(1), mc.free_std(1));
fprintf('q1 = %.6f +/- %.6f\n', mc.free_mean(2), mc.free_std(2));
fprintf('q2 = %.6f +/- %.6f\n', mc.free_mean(3), mc.free_std(3));

fprintf('\nMonte Carlo scalar d, mean +/- std:\n');
fprintf('d  = %.6f +/- %.6f\n', mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 5 — Joint Fz + Fx + Fy identification with noise
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'FzFxFy';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 40;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 50;      % [N]
opts.ident_noise_std_Fx = 30;      % [N]
opts.ident_noise_std_Fy = 30;      % [N]

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;
veh = model.veh;

fprintf('\nNominal:\n');
fprintf('H  = %.6f, q1 = %.6f, q2 = %.6f, d = %.6f\n', ...
    veh.H, veh.q1, veh.q2, veh.d);

fprintf('\nFz+Fx+Fy Monte Carlo free [H,q1,q2], mean +/- std:\n');
fprintf('H  = %.6f +/- %.6f\n', mc.free_mean(1), mc.free_std(1));
fprintf('q1 = %.6f +/- %.6f\n', mc.free_mean(2), mc.free_std(2));
fprintf('q2 = %.6f +/- %.6f\n', mc.free_mean(3), mc.free_std(3));

fprintf('\nFz+Fx+Fy Monte Carlo scalar d, mean +/- std:\n');
fprintf('d  = %.6f +/- %.6f\n', mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 6 — Immediate horizon weighting
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;

opts.ident_weight_mode = 'immediate';
opts.ident_weight_tau = 0.3;       % smaller = more immediate emphasis

opts.ident_noise_enable = true;
opts.ident_noise_seed = 50;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;

fprintf('\nImmediate weighting result:\n');
fprintf('free mean [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_mean(1), mc.free_mean(2), mc.free_mean(3));
fprintf('free std  [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_std(1), mc.free_std(2), mc.free_std(3));
fprintf('scalar d mean/std = %.6f / %.6f\n', ...
    mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 7 — Uniform full-horizon weighting
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;

opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 60;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;

fprintf('\nUniform weighting result:\n');
fprintf('free mean [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_mean(1), mc.free_mean(2), mc.free_mean(3));
fprintf('free std  [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_std(1), mc.free_std(2), mc.free_std(3));
fprintf('scalar d mean/std = %.6f / %.6f\n', ...
    mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 8 — Late horizon weighting
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;

opts.ident_weight_mode = 'late';
opts.ident_weight_power = 2.0;     % larger = stronger late-window emphasis

opts.ident_noise_enable = true;
opts.ident_noise_seed = 70;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;

fprintf('\nLate weighting result:\n');
fprintf('free mean [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_mean(1), mc.free_mean(2), mc.free_mean(3));
fprintf('free std  [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_std(1), mc.free_std(2), mc.free_std(3));
fprintf('scalar d mean/std = %.6f / %.6f\n', ...
    mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 9 — Compare different steering manoeuvre: sine_steer
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.sine_mag = deg2rad(8.0);
opts.sine_freq = 0.5;
opts.sine_tau = 0.4;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 80;
opts.ident_noise_runs = 10;

opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('sine_steer', opts);

mc = id_result.noise_monte_carlo;

fprintf('\nSine steer Fz robustness result:\n');
fprintf('free mean [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_mean(1), mc.free_mean(2), mc.free_mean(3));
fprintf('free std  [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_std(1), mc.free_std(2), mc.free_std(3));
fprintf('scalar d mean/std = %.6f / %.6f\n', ...
    mc.scalar_d_mean, mc.scalar_d_std);


% =========================================================
%% TEST 10 — Stronger Monte Carlo after everything works
% =========================================================

clear; clc; close all;

opts = struct();

opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';

opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 100;
opts.ident_noise_runs = 50;        % stronger Monte Carlo, slower

opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;

opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts);

mc = id_result.noise_monte_carlo;
veh = model.veh;

fprintf('\nFinal stronger robustness test:\n');
fprintf('Nominal H/q1/q2/d = %.6f / %.6f / %.6f / %.6f\n', ...
    veh.H, veh.q1, veh.q2, veh.d);

fprintf('free mean [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_mean(1), mc.free_mean(2), mc.free_mean(3));
fprintf('free std  [H q1 q2] = [%.6f %.6f %.6f]\n', ...
    mc.free_std(1), mc.free_std(2), mc.free_std(3));
fprintf('scalar d mean/std = %.6f / %.6f\n', ...
    mc.scalar_d_mean, mc.scalar_d_std);
