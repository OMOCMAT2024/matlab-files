%% RUN_IDENTIFICATION_TESTS_ONE_BY_ONE
% This script is a menu of independent tests for
% run_oc_simple_time_sim_arbitrary.m.
%
% Recommended use:
%   1) Put this file, run_oc_simple_time_sim_arbitrary.m, my_model.m,
%      and my_params.m in the same MATLAB folder.
%   2) Run ONE SECTION at a time using MATLAB's "Run Section" button.
%   3) Start with Test 0, then Test 1, then noisy robustness.
%
% Notes:
% - opts.run_dae = false is used for speed. Set true only if you want the DAE
%   branch too.
% - opts.ident_sample_stride = 1 uses all selected samples. Increase to 2, 3,
%   or 5 for faster first debugging.
% - For robustness, increase opts.ident_noise_runs after the first successful
%   test.

%% Test 0: simulation only, no identification
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = true;
opts.do_identification = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

%% Test 1: clean Fz-only identification, uniform 3 s window
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = true;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = false;
opts.ident_noise_runs = 1;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);

%% Test 2: noisy Fz-only robustness, low noise level: Fz std = 20 N
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 100;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 20;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 3: noisy Fz-only robustness, medium noise level: Fz std = 50 N
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 200;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 4: noisy Fz-only robustness, high noise level: Fz std = 100 N
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 300;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 100;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 5: joint Fz + Fx + Fy identification with noisy output data
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'FzFxFy';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 400;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 30;
opts.ident_noise_std_Fy = 30;
opts.ident_plot = true;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 6: immediate-horizon weighting, Fz-only, noisy target
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;

opts.ident_weight_mode = 'immediate';
opts.ident_weight_tau = 0.3;   % smaller means stronger emphasis on first samples

opts.ident_noise_enable = true;
opts.ident_noise_seed = 500;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 7: long/full-horizon weighting, Fz-only, noisy target
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;

opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 600;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 8: late-horizon weighting, Fz-only, noisy target
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;

opts.ident_weight_mode = 'late';
opts.ident_weight_power = 2.0;

opts.ident_noise_enable = true;
opts.ident_noise_seed = 700;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);


%% Test 9: compare different steering manoeuvre, sine_steer, Fz-only noisy target
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.sine_mag = deg2rad(8.0);
opts.sine_freq = 0.5;
opts.sine_tau = 0.4;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 800;
opts.ident_noise_runs = 10;
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('sine_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);

%% Test 10: stronger Monte Carlo robustness after previous tests work
clear; clc; close all;

opts = struct();
opts.run_dae = false;
opts.do_plot = false;

opts.do_identification = true;
opts.ident_source = 'ode15s';
opts.ident_fit_targets = 'Fz';
opts.ident_horizon = 3.0;
opts.ident_sample_stride = 1;
opts.ident_weight_mode = 'uniform';

opts.ident_noise_enable = true;
opts.ident_noise_seed = 1000;
opts.ident_noise_runs = 50;        % slower but better robustness statistics
opts.ident_noise_std_Fz = 50;
opts.ident_noise_std_Fx = 0;
opts.ident_noise_std_Fy = 0;
opts.ident_plot = false;

[sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = ...
    run_oc_simple_time_sim_arbitrary('step_steer', opts);

print_identification_brief(model, id_result);
print_noise_brief(id_result);


%% Local helper: print one-run result summary
function print_identification_brief(model, id_result)
veh = model.veh;
fprintf('\n================ IDENTIFICATION BRIEF ================\n');
fprintf('Nominal my_params: H = %.6f, q1 = %.6f, q2 = %.6f, d = %.6f m\n', ...
    veh.H, veh.q1, veh.q2, veh.d);
if isfield(id_result, 'data_info')
    fprintf('Data window: %.4f to %.4f s, samples = %d\n', ...
        id_result.data_info.window_start, id_result.data_info.window_end, id_result.data_info.n_samples);
end
if isfield(id_result, 'free') && ~isempty(id_result.free)
    fprintf('Free fit:     H = %.6f, q1 = %.6f, q2 = %.6f m, J = %.6e\n', ...
        id_result.free.H, id_result.free.q1, id_result.free.q2, id_result.free.objective);
end
if isfield(id_result, 'scalar_d') && ~isempty(id_result.scalar_d)
    fprintf('Scalar-d fit: d = %.6f, H = %.6f m, J = %.6e\n', ...
        id_result.scalar_d.d, id_result.scalar_d.H, id_result.scalar_d.objective);
end
if isfield(id_result, 'consistency') && ~isempty(id_result.consistency)
    fprintf('Single-d consistency: q_spread = %.6f m, H_mismatch = %.6f m, supported = %d\n', ...
        id_result.consistency.q_spread_abs, id_result.consistency.H_mismatch_abs, ...
        id_result.consistency.is_consistent);
end
if isfield(id_result, 'recommendation')
    fprintf('Recommendation: %s\n', id_result.recommendation);
end
fprintf('======================================================\n\n');
end

%% Local helper: print Monte-Carlo robustness summary
function print_noise_brief(id_result)
if ~isfield(id_result, 'noise_monte_carlo') || isempty(id_result.noise_monte_carlo)
    fprintf('No Monte Carlo robustness result stored. Set ident_noise_enable=true and ident_noise_runs>1.\n');
    return;
end
mc = id_result.noise_monte_carlo;
fprintf('\n================ NOISE ROBUSTNESS BRIEF ===============\n');
fprintf('Monte Carlo runs: %d\n', mc.n_runs);
fprintf('Free [H,q1,q2] mean: [%.6f, %.6f, %.6f] m\n', ...
    mc.free_mean(1), mc.free_mean(2), mc.free_mean(3));
fprintf('Free [H,q1,q2] std : [%.6f, %.6f, %.6f] m\n', ...
    mc.free_std(1), mc.free_std(2), mc.free_std(3));
fprintf('Scalar d mean/std  : %.6f / %.6f m\n', ...
    mc.scalar_d_mean, mc.scalar_d_std);
fprintf('======================================================\n\n');
end
