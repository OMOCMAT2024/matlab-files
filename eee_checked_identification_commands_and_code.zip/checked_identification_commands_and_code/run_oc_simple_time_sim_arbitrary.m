function [sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, id_result] = run_oc_simple_time_sim_arbitrary(profile, user_opts)

% % -------------------------------------------------------------------------
% % 3. Target-speed preparation settings
% % -------------------------------------------------------------------------
% opts = struct();
% 
% opts.U_target = 60/3.6;                  % [m/s], target speed = 60 km/h
% opts.drive_torque_mode = 'max_accel_hold_release';
% 
% opts.t_accel = 4.0;                      % [s], planned fast approach time
% opts.t_hold = 3.0;                       % [s], extra time to settle near target speed
% opts.t_steer_delay = 0.7;                % [s], zero-torque/no-steering delay
% 
% opts.speed_hold_Kp = 1.5;                % [1/s], speed-hold feedback gain
% 
% % Diagnostic tolerances for your ultimate requirement:
% % before torque release / steering delay, speed should be near target and
% % ux_dot or ax should be small.
% opts.do_presteer_diagnostic = true;
% opts.diag_speed_tol_kmh = 1.0;           % [km/h]
% opts.diag_uxdot_tol = 0.05;              % [m/s^2]
% opts.diag_ax_tol = 0.05;                 % [m/s^2]
% opts.diag_torque_tol = 1e-6;             % [Nm]
% opts.diag_steer_tol_deg = 1e-6;          % [deg]
% 
% % Total simulation time. The final +5.0 s is the steering-observation window.
% opts.t_end = opts.t_accel + opts.t_hold + opts.t_steer_delay + 5.0;
% 
% % Solver / plotting options
% opts.run_dae = true;                     % set false for faster first tests
% opts.do_plot = true;
% 
% % -------------------------------------------------------------------------
% % 4. Step steering test
% % -------------------------------------------------------------------------
% opts_step = opts;
% opts_step.step_mag = deg2rad(5.0);       % [rad]
% opts_step.step_dur = 2.0;                % [s]
% 
% [sim_step_ode15s, sim_step_fixed, sim_step_dae, model_step, ctrl_step] = ...
%     run_oc_simple_time_sim_arbitrary('step_steer', opts_step);
% 
% % -------------------------------------------------------------------------
% % 5. Sine steering test
% % -------------------------------------------------------------------------
% opts_sine = opts;
% opts_sine.sine_mag = deg2rad(8.0);       % [rad]
% opts_sine.sine_freq = 0.5;               % [Hz]
% opts_sine.sine_tau = 0.4;                % [s]
% 
% [sim_sine_ode15s, sim_sine_fixed, sim_sine_dae, model_sine, ctrl_sine] = ...
%     run_oc_simple_time_sim_arbitrary('sine_steer', opts_sine);
% 
% % -------------------------------------------------------------------------
% % 6. Linear steering test
% % -------------------------------------------------------------------------
% opts_linear = opts;
% opts_linear.linear_slope = deg2rad(3.0); % [rad/s]
% 
% [sim_linear_ode15s, sim_linear_fixed, sim_linear_dae, model_linear, ctrl_linear] = ...
%     run_oc_simple_time_sim_arbitrary('linear_steer', opts_linear);

if nargin < 1 || isempty(profile)
profile = 'mild_sine';
end
if nargin < 2 || isempty(user_opts)
user_opts = struct();
end

fprintf('\n=== Simple time simulation from my_model.m only ===\n');
fprintf('Profile: %s\n', profile);
fprintf('Simulator version: 2026-06-25-v8-command-actual-power-limit-no-clamps.\n');

model = build_model_functions_from_my_model();
veh = model.veh;
opts = default_options(user_opts, veh);
ctrl = make_arbitrary_controls(profile, opts, veh);
id_result = [];

x0_scaled = make_initial_state_scaled(veh, model);
z0_static_scaled = static_load_guess_scaled(veh, model);

% For the reduced-ODE integrators, improve z0 by solving h_load = 0 once.
% For the true DAE integrator, use z0_static_scaled and let decic/ode15i
% determine a consistent algebraic initial condition without calling our
% tyre-load Newton solve.
u0_scaled = make_applied_control_scaled(ctrl.t(1), x0_scaled, ctrl, veh, model, opts);
kappa0 = eval_kappa(opts, 0, x0_scaled);
pv0 = make_model_pv(opts, kappa0, veh);
z0_reduced_scaled = solve_loads_newton(model, x0_scaled, u0_scaled, pv0, z0_static_scaled, opts, true);

% Variable-step stiff integration using ode15s. This is an ODE in x only,
% with the tyre-load algebraic equations solved inside the RHS.
fprintf('Running ode15s variable-step stiff simulation...\n');
t_ode_start = tic;
z_cache = z0_reduced_scaled;
odefun = @(t,xs) rhs_scaled(t, xs, ctrl, veh, model, opts, z_cache);
% Use nested wrapper to update the z cache after each accepted/internal call.
function dxs = rhs_cached(t, xs)
[dxs, z_cache] = rhs_scaled(t, xs, ctrl, veh, model, opts, z_cache);
end

tspan = 0:opts.output_dt:opts.t_end;
ode_opts = odeset('RelTol', opts.ode_reltol, 'AbsTol', opts.ode_abstol, ...
'MaxStep', opts.ode_max_step);
[t_ode, x_ode] = ode15s(@rhs_cached, tspan, x0_scaled, ode_opts);
time_ode15s = toc(t_ode_start);
fprintf(' ode15s wall time: %.3f s, output points: %d.\n', time_ode15s, numel(t_ode));
sim_ode15s = postprocess_solution('ode15s', t_ode(:), x_ode.', ctrl, veh, model, opts, z0_reduced_scaled);

% Fixed-step RK4 integration.
fprintf('Running fixed-step RK4 simulation... fixed_dt = %.4g s, stages/step = 4.\n', opts.fixed_dt);
t_fixed_start = tic;
sim_fixed = simulate_fixed_rk4(x0_scaled, z0_reduced_scaled, ctrl, veh, model, opts);

time_fixed = toc(t_fixed_start);
fprintf(' fixed RK4 wall time: %.3f s, steps: %d, nominal RHS calls: %d.\n', time_fixed, numel(sim_fixed.t)-1, 4*(numel(sim_fixed.t)-1));

% True DAE integration using ode15i. Here the four tyre vertical loads are
% solver variables, not quantities solved by our RHS Newton reduction. MATLAB
% will solve the coupled nonlinear DAE residual internally.
if opts.run_dae
fprintf('Running ode15i true DAE simulation for [x; z]...\n');
t_dae_start = tic;
sim_ode15i_dae = simulate_ode15i_dae(x0_scaled, z0_static_scaled, ctrl, veh, model, opts);
time_dae = toc(t_dae_start);
fprintf(' ode15i DAE wall time: %.3f s, output points: %d.\n', time_dae, numel(sim_ode15i_dae.t));
else
sim_ode15i_dae = [];
end

if isempty(sim_ode15i_dae)
fprintf('Done. Max |h_load| ode15s = %.3e, fixed = %.3e\n', ...
max(abs(sim_ode15s.h_load(:))), max(abs(sim_fixed.h_load(:))));
else
fprintf('Done. Max |h_load| ode15s = %.3e, fixed = %.3e, ode15i DAE = %.3e\n', ...
max(abs(sim_ode15s.h_load(:))), max(abs(sim_fixed.h_load(:))), max(abs(sim_ode15i_dae.h_load(:))));
end

if opts.do_presteer_diagnostic
print_presteer_diagnostic(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, opts, veh);
end

if opts.do_identification
fprintf('\n=== Optional load-transfer parameter identification ===\n');
id_result = run_identification_workflow(sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, veh, opts);
fprintf('=== End optional load-transfer parameter identification ===\n\n');
end

if opts.do_plot
plot_simple_results(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, veh);
end
end

%% ------------------------------------------------------------------------
function model = build_model_functions_from_my_model()
% Build only single-output CasADi functions. No NLP, no collocation, no IPOPT.
import casadi.*
veh = my_params(); %#ok<NASGU>
run('my_model.m');

% required = {'x','u','z','pv','y_xdot','h_load','y_acc','y_torque','y_mu','y_load', ...
% 'x_s','u_s','z_s','x_min','x_max','z_min','z_max','nx','nz'};
required = {'x','u','z','pv','y_xdot','h_load','y_acc','y_torque','y_mu','y_load','y_tyre', ...
'x_s','u_s','z_s','x_min','x_max','z_min','z_max','nx','nz'};
for i = 1:numel(required)
assert(exist(required{i}, 'var') == 1, 'my_model.m did not define %s.', required{i});
end

model = struct();
model.veh = veh;
model.nx = nx;
model.nz = nz;
model.npv = size(pv, 1);
model.pv_nominal_no_kappa = [veh.H; veh.q1; veh.q2];
model.x_s = full(x_s(:));
model.u_s = full(u_s(:));
model.z_s = full(z_s(:));
model.x_min = full(x_min(:));
model.x_max = full(x_max(:));
model.z_min = full(z_min(:));
model.z_max = full(z_max(:));

% Single-output functions only. This avoids the previous multi-output and
% concatenated-output issues completely.
model.f_xdot = casadi.Function('sim_f_xdot', {x,u,z,pv}, {y_xdot});
model.f_hload = casadi.Function('sim_f_hload', {x,u,z,pv}, {h_load});
model.f_hload_jac_z = casadi.Function('sim_f_hload_jac_z', {x,u,z,pv}, {jacobian(h_load, z)});
model.f_acc = casadi.Function('sim_f_acc', {x,u,z,pv}, {y_acc});
model.f_torque = casadi.Function('sim_f_torque', {x,u,z,pv}, {y_torque});
model.f_mu = casadi.Function('sim_f_mu', {x,u,z,pv}, {y_mu});
model.f_load = casadi.Function('sim_f_load', {x,u,z,pv}, {y_load});

model.f_tyre = casadi.Function('sim_f_tyre', {x,u,z,pv}, {y_tyre});

fprintf('Built CasADi functions from my_model.m. nx = %d, nz = %d, npv = %d.\n', model.nx, model.nz, model.npv);
end

%% ------------------------------------------------------------------------
function opts = default_options(user_opts, veh)
opts = struct();
opts.t_end = 15.0;
opts.output_dt = 0.02;
opts.fixed_dt = 1e-3;
% opts.ode_reltol = 1e-6;
% opts.ode_abstol = 1e-8;
opts.ode_reltol = 1e-12;
opts.ode_abstol = 1e-14;
opts.ode_max_step = 0.02;
opts.dae_reltol = 1e-12;
opts.dae_abstol = 1e-14;
opts.dae_max_step = 0.02;
opts.do_plot = true;
opts.run_dae = true;
% Fixed RK4 should not silently clamp states by default, because ode15s and
% ode15i do not impose the NLP state bounds during simulation. Set this true
% only as a numerical guard for aggressive arbitrary inputs.
opts.enforce_state_bounds_fixed = false;
opts.kappa_constant = 0.0; % straight road by default
opts.load_tol = 1e-8;
opts.load_max_iter = 12;
opts.load_fd_rel = 1e-6;
opts.warn_load_residual = 1e-5;
opts.min_power_omega = max(1.0, veh.omega_rear_axle_min);

% Diagnostics for the target-speed / pre-steering requirement.
% These do not change the simulation; they only print and plot checks.
opts.do_presteer_diagnostic = true;
opts.diag_speed_tol_kmh = 1.0;      % [km/h], target-speed tolerance before torque release
opts.diag_uxdot_tol = 0.05;         % [m/s^2], acceptable |ux_dot| before torque release
opts.diag_ax_tol = 0.05;            % [m/s^2], acceptable |ax| before torque release
opts.diag_torque_tol = 1e-6;        % [Nm], zero-torque diagnostic tolerance
opts.diag_steer_tol_deg = 1e-6;     % [deg], zero-steering diagnostic tolerance

% Optional load-transfer parameter identification. All defaults keep the
% original simulation behavior untouched. Set opts.do_identification = true
% to identify [H,q1,q2] and scalar d from one completed simulation.
opts.do_identification = false;
opts.ident_source = 'ode15s';       % 'ode15s', 'fixed', or 'dae'
opts.ident_fit_targets = 'Fz';      % 'Fz', 'FxFy', or 'FzFxFy'
opts.ident_start_time = [];         % [] => steering start if available
opts.ident_end_time = [];           % [] => start + opts.ident_horizon
opts.ident_horizon = 3.0;           % [s], default window after steering start
opts.ident_sample_stride = 1;       % use every n-th sample in the selected window
opts.ident_weight_mode = 'uniform'; % 'uniform', 'immediate', or 'late'
opts.ident_weight_tau = 0.5;        % [s], for immediate/exponential weighting
opts.ident_weight_power = 1.0;      % for late weighting
opts.ident_fit_free_H_q = true;
opts.ident_fit_scalar_d = true;
opts.ident_lower_frac_h = 0.0;      % lower bound as fraction of CG height h
opts.ident_upper_frac_h = 1.0;      % upper bound as fraction of CG height h
opts.ident_bound_penalty = 1e6;
opts.ident_max_fun_evals = 300;
opts.ident_max_iter = 300;
opts.ident_tol_x = 1e-5;
opts.ident_tol_fun = 1e-8;
opts.ident_optimizer_display = 'off';
opts.ident_min_abs_Y = 25.0;        % [N], avoid division by tiny lateral force in diagnostic LS
opts.ident_consistency_abs_tol = 0.03; % [m]
opts.ident_consistency_rel_tol = 0.15; % [-]
opts.ident_Fz_scale = veh.m*veh.g/4;
opts.ident_Fx_scale = veh.m*veh.g/4;
opts.ident_Fy_scale = veh.m*veh.g/4;
opts.ident_plot = true;
opts.ident_noise_enable = false;
opts.ident_noise_seed = 1;
opts.ident_noise_runs = 1;
opts.ident_noise_std_Fz = 0.0;      % [N], output noise added to target Fz only
opts.ident_noise_std_Fx = 0.0;      % [N], output noise added to target Fx only
opts.ident_noise_std_Fy = 0.0;      % [N], output noise added to target Fy only

names = fieldnames(user_opts);
for i = 1:numel(names)
opts.(names{i}) = user_opts.(names{i});
end
end

%% ------------------------------------------------------------------------
% function ctrl = make_arbitrary_controls(profile, opts, veh)
% t = 0:opts.output_dt:opts.t_end;
% Tt_max = veh.Tt_max;
%
% switch lower(profile)
% case 'straight_accel'
% Tt = 0.45*Tt_max*(1 - exp(-t/2.0));
% delta = zeros(size(t));
% case 'mild_sine'
% Tt = 0.35*Tt_max*(1 - exp(-t/2.0)).*(1 + 0.08*sin(2*pi*0.20*t));
% delta = deg2rad(3.0)*sin(2*pi*0.18*t).*(1 - exp(-t/1.0));
% case 'slalom'
% Tt = 0.25*Tt_max*(1 - exp(-t/1.5));
% delta = deg2rad(6.0)*sin(2*pi*0.35*t).*(1 - exp(-t/1.0));
% otherwise
% error('Unknown profile "%s". Use straight_accel, mild_sine, or slalom.', profile);
% end
%
% ctrl = struct();
% ctrl.t = t(:).';
% ctrl.Tt_cmd = min(max(Tt(:).', veh.Tt_min), veh.Tt_max);
% ctrl.delta_cmd = min(max(delta(:).', veh.delta_min), veh.delta_max);
% ctrl.Tb_cmd = zeros(size(ctrl.t)); % brake torque fixed zero as requested
% end









% function ctrl = make_arbitrary_controls(profile, opts, veh)
% % Generates open-loop control signals for vehicle simulations.
% % Integrates original legacy profiles with new multi-phase steering tests.
%
% t = 0:opts.output_dt:opts.t_end;
% Tt_max = veh.Tt_max;
%
% % Pre-allocate outputs with zeros to ensure clean initialization
% Tt = zeros(size(t));
% delta = zeros(size(t));
%
% % --- Phased Profile Configuration Defaults ---
% % These variables read customizable fields from "opts". If they do not exist,
% % they gracefully fall back to safe default values.
% t_spinup = iffield(opts, 't_spinup', 3.0); % Time to spin up the vehicle speed [s]
% t_hold = iffield(opts, 't_hold', 2.0); % Time to maintain constant torque [s]
% Tt_target = iffield(opts, 'Tt_target', 0.25 * Tt_max); % Dynamic equilibrium target torque
%
% % Compute absolute transition time markers
% t1 = t_spinup;
% t2 = t1 + t_hold;
%
% switch lower(profile)
% % =========================================================================
% % LEGACY PROFILES (Maintained exactly as originally provided)
% % =========================================================================
% case 'straight_accel'
% Tt = 0.45*Tt_max*(1 - exp(-t/2.0));
% delta = zeros(size(t));
%
% case 'mild_sine'
% Tt = 0.35*Tt_max*(1 - exp(-t/2.0)).*(1 + 0.08*sin(2*pi*0.20*t));
% delta = deg2rad(3.0)*sin(2*pi*0.18*t).*(1 - exp(-t/1.0));
%
% case 'slalom'
% Tt = 0.25*Tt_max*(1 - exp(-t/1.5));
% delta = deg2rad(6.0)*sin(2*pi*0.35*t).*(1 - exp(-t/1.0));
%
% % =========================================================================
% % NEW PHASED TEST PROFILES (Torque drop -> Steering activation)
% % =========================================================================
% case 'step_steer'
% % Setup common multi-phase torque profile
% Tt = compute_phased_torque(t, t1, t2, Tt_target);
%
% % Extract custom steering step parameters
% mag_step = iffield(opts, 'step_mag', deg2rad(5.0)); % Step input magnitude [rad]
% dur_step = iffield(opts, 'step_dur', 2.0); % Duration to hold the step [s]
%
% % Step is active from t2 up to (t2 + dur_step)
% idx_step = (t >= t2 & t < (t2 + dur_step));
% delta(idx_step) = mag_step;
%
% case 'sine_steer'
% % Setup common multi-phase torque profile
% Tt = compute_phased_torque(t, t1, t2, Tt_target);
%
% % Extract custom sinusoidal parameters
% mag_sine = iffield(opts, 'sine_mag', deg2rad(8.0)); % Peak amplitude [rad]
% freq_sine = iffield(opts, 'sine_freq', 0.5); % Frequency [Hz]
% tau_sine = iffield(opts, 'sine_tau', 0.4); % Steering ramp-in/steepness factor [s]
%
% % Shift time index to start cleanly at t2 (the moment torque cuts to 0)
% idx_steer = (t >= t2);
% t_rel = t(idx_steer) - t2;
%
% % Sinusoidal command with smooth exponential steepness curve
% delta(idx_steer) = mag_sine * sin(2*pi*freq_sine * t_rel) .* (1 - exp(-t_rel / tau_sine));
%
% case 'linear_steer'
% % Setup common multi-phase torque profile
% Tt = compute_phased_torque(t, t1, t2, Tt_target);
%
% % Extract custom linear ramp parameters
% slope_linear = iffield(opts, 'linear_slope', deg2rad(3.0)); % Ramp rate [rad/s]
%
% % Linear slope starts incrementing exactly at t2
% idx_steer = (t >= t2);
% t_rel = t(idx_steer) - t2;
% delta(idx_steer) = slope_linear * t_rel;
%
% % Strictly enforce vehicle max physical limits to avoid numerical issues
% delta = max(min(delta, veh.delta_max), veh.delta_min);
%
% otherwise
% error('Unknown profile "%s". Use straight_accel, mild_sine, slalom, step_steer, sine_steer, or linear_steer.', profile);
% end
%
% % Check total duration window for steering inputs (Capping total user execution if requested)
% if isfield(opts, 't_steer')
% idx_past_steer_window = (t >= (t2 + opts.t_steer));
% delta(idx_past_steer_window) = 0;
% end
%
% % Assign back to the expected output control struct format
% % ctrl.Tt = Tt;
% % ctrl.delta = delta;
%
% ctrl = struct();
% ctrl.t = t(:).';
% ctrl.Tt_cmd = min(max(Tt(:).', veh.Tt_min), veh.Tt_max);
% ctrl.delta_cmd = min(max(delta(:).', veh.delta_min), veh.delta_max);
% ctrl.Tb_cmd = zeros(size(ctrl.t)); % brake torque fixed zero as requested
%
% end
%
% % =========================================================================
% % LOCAL HELPER FUNCTIONS
% % =========================================================================
%
% function Tt = compute_phased_torque(t, t1, t2, Tt_target)
% % Computes the vectorized phased torque sequence across 3 specific timelines:
% % Phase 1: Exponential spin up to target torque
% % Phase 2: Constant torque hold for dynamic equilibrium
% % Phase 3: Immediate torque cut to 0
%
% Tt = zeros(size(t));
%
% % Phase 1: Smooth exponential buildup up to t1
% % idx_p1 = (t >= 0 & t < t1);
% % tau_torque = t1 / 3; % Reaches roughly 95% of target by t1 limit
% % Tt(idx_p1) = Tt_target * (1 - exp(-t(idx_p1) / tau_torque));
% idx_p1 = (t >= 0 & t < t1);
% Tt(idx_p1) = Tt_target * (t(idx_p1) / t1);
%
% % Phase 2: Constant torque boundary from t1 to t2
% idx_p2 = (t >= t1 & t < t2);
% Tt(idx_p2) = Tt_target;
%
% % Phase 3: Immediate torque drop to 0 starting at t2
% idx_p3 = (t >= t2);
% Tt(idx_p3) = 0;
% end
%
% function val = iffield(strct, field, default_val)
% % Safe check utility function to keep defaults if options structure fields are omitted
% if isfield(strct, field)
% val = strct.(field);
% else
% val = default_val;
% end
% end










function ctrl = make_arbitrary_controls(profile, opts, veh)
% Generates open-loop steering command histories and metadata for a simple
% closed-loop pre-steering speed-preparation torque controller.
%
% For the three phased steering profiles, the steering timing is still a
% clean time history:
%
%   0 <= t < t_release
%       steering = 0
%       drive torque is generated online by make_applied_control_phys using
%       current vehicle speed feedback.
%
%   t_release <= t < t_steer_start
%       drive torque = 0, steering = 0
%
%   t >= t_steer_start
%       drive torque = 0, selected steering command starts
%
% where
%
%   t_release      = t_accel + t_hold
%   t_steer_start  = t_release + t_steer_delay
%
% The speed-preparation drive torque is intentionally NOT finalized here,
% because this function does not know the current simulated state. Instead,
% this function stores the target speed, release time, and controller gains
% inside ctrl. The actual closed-loop drive-torque command is computed in
% make_applied_control_phys(t,xs,...), where the current state xs is known.
%
% Typical use:
%
%   opts.U_target = 60/3.6;
%   opts.drive_torque_mode = 'max_accel_hold_release';
%   opts.t_accel = 4.0;
%   opts.t_hold = 2.0;
%   opts.t_steer_delay = 0.7;
%   opts.speed_hold_Kp = 1.5;
%
% For backward compatibility, opts.delta_t is also accepted if
% opts.t_steer_delay is not provided.

t = 0:opts.output_dt:opts.t_end;
Tt_max = veh.Tt_max;

% Pre-allocate outputs with zeros to ensure clean initialization.
Tt = zeros(size(t));
delta = zeros(size(t));

% -------------------------------------------------------------------------
% Phased Profile Configuration Defaults
% -------------------------------------------------------------------------
% drive_torque_mode only selects the maximum allowed requested acceleration
% command. The pre-release torque itself is closed-loop in
% make_applied_control_phys.
drive_torque_mode = iffield(opts, 'drive_torque_mode', 'max_accel_hold_release');

switch lower(drive_torque_mode)
case {'smooth_accel_hold_release', 'smooth_accel', 'smooth', 'set1'}
    default_t_accel = 6.0;
case {'max_accel_hold_release', 'max_accel', 'max', 'set2'}
    default_t_accel = 4.0;
otherwise
    error(['Unknown opts.drive_torque_mode "%s". Use ', ...
        'smooth_accel_hold_release or max_accel_hold_release.'], drive_torque_mode);
end

% t_accel is the planned fast approach time. t_hold is the additional
% straight-running speed-hold time before torque release.
t_accel = iffield(opts, 't_accel', iffield(opts, 't_spinup', default_t_accel)); % [s]
t_hold = iffield(opts, 't_hold', 2.0); % [s]

if ~isscalar(t_accel) || ~isfinite(t_accel) || t_accel <= 0
    error('opts.t_accel must be a finite positive scalar.');
end
if ~isscalar(t_hold) || ~isfinite(t_hold) || t_hold < 0
    error('opts.t_hold must be a finite nonnegative scalar.');
end

U_target = iffield(opts, 'U_target', 60/3.6); % [m/s]
if ~isscalar(U_target) || ~isfinite(U_target) || U_target <= 0
    error('opts.U_target must be a finite positive scalar.');
end

% Feedforward drag-balancing torque. This is not used alone as the holding
% command; it is the feedforward term in the online speed controller.
Tt_eq_computed = 0.5 * veh.drag_coeff * U_target^2 * veh.rw;
Tt_eq = iffield(opts, 'Tt_hold_cmd', iffield(opts, 'Tt_target', Tt_eq_computed));
if ~isscalar(Tt_eq) || ~isfinite(Tt_eq) || Tt_eq < 0
    error('opts.Tt_hold_cmd / opts.Tt_target must be a finite nonnegative scalar.');
end

% Smooth set-1 acceleration command estimate based on the same initial speed
% used in make_initial_state_scaled unless opts.ux0_for_cmd is overridden.
ux0_for_cmd = iffield(opts, 'ux0_for_cmd', 5.0); % [m/s]
a_cmd = max((U_target - ux0_for_cmd) / t_accel, 0.0); % [m/s^2]
Tt_accel_cmd_smooth_default = Tt_eq + veh.m * veh.rw * a_cmd;

% Maximum command available to the online speed-preparation controller. The
% actual applied torque is still protected later by min(Tt_cmd,Td_max,Pmax/omega).
if any(strcmpi(drive_torque_mode, {'smooth_accel_hold_release', 'smooth_accel', 'smooth', 'set1'}))
    Tt_accel_cmd = iffield(opts, 'Tt_accel_cmd', Tt_accel_cmd_smooth_default);
else
    Tt_accel_cmd = iffield(opts, 'Tt_accel_cmd', Tt_max);
end
if ~isscalar(Tt_accel_cmd) || ~isfinite(Tt_accel_cmd) || Tt_accel_cmd < 0
    error('opts.Tt_accel_cmd must be a finite nonnegative scalar.');
end
Tt_accel_cmd = min(Tt_accel_cmd, Tt_max);

% Proportional speed-hold gain. Units are approximately [1/s] in the simple
% straight-line force balance T = T_drag + m*rw*Kp*(U_target - ux).
speed_hold_Kp = iffield(opts, 'speed_hold_Kp', 1.5);
if ~isscalar(speed_hold_Kp) || ~isfinite(speed_hold_Kp) || speed_hold_Kp <= 0
    error('opts.speed_hold_Kp must be a finite positive scalar.');
end

% Delay between torque release and steering start.
if isfield(opts, 't_steer_delay')
    t_steer_delay = opts.t_steer_delay;
elseif isfield(opts, 'delta_t')
    t_steer_delay = opts.delta_t;
else
    t_steer_delay = 0.7;
end
if ~isscalar(t_steer_delay) || ~isfinite(t_steer_delay) || t_steer_delay < 0
    error('opts.t_steer_delay must be a finite nonnegative scalar.');
end

% Compute absolute transition time markers.
t1 = t_accel;
t2 = t1 + t_hold;              % torque release time
t_steer_start = t2 + t_steer_delay;

% Reference time used by optional steering-window cut-off.
t_steer_window_ref = t2;
is_phased_steer_profile = false;

switch lower(profile)

% =========================================================================
% LEGACY PROFILES
% =========================================================================
case 'straight_accel'
    Tt = 0.45*Tt_max*(1 - exp(-t/2.0));
    delta = zeros(size(t));

case 'mild_sine'
    Tt = 0.35*Tt_max*(1 - exp(-t/2.0)).*(1 + 0.08*sin(2*pi*0.20*t));
    delta = deg2rad(3.0)*sin(2*pi*0.18*t).*(1 - exp(-t/1.0));

case 'slalom'
    Tt = 0.25*Tt_max*(1 - exp(-t/1.5));
    delta = deg2rad(6.0)*sin(2*pi*0.35*t).*(1 - exp(-t/1.0));

% =========================================================================
% PHASED TEST PROFILES
% Closed-loop speed preparation -> torque release -> steering activation
% =========================================================================
case 'step_steer'
    is_phased_steer_profile = true;
    % Nominal table only. The actual pre-release Tt command is computed
    % online from current speed inside make_applied_control_phys.
    Tt = compute_nominal_phased_torque(t, t2, Tt_accel_cmd);

    t_steer_window_ref = t_steer_start;

    mag_step = iffield(opts, 'step_mag', deg2rad(5.0)); % [rad]
    dur_step = iffield(opts, 'step_dur', 2.0); % [s]
    ramp_step = iffield(opts, 'step_ramp_time', 0.10); % [s], smooth rise/fall for DAE robustness

    idx_step = (t >= t_steer_start & t < (t_steer_start + dur_step));
    t_step_rel = t(idx_step) - t_steer_start;
    delta(idx_step) = mag_step .* smooth_step_pulse(t_step_rel, dur_step, ramp_step);

case 'sine_steer'
    is_phased_steer_profile = true;
    Tt = compute_nominal_phased_torque(t, t2, Tt_accel_cmd);

    t_steer_window_ref = t_steer_start;

    mag_sine = iffield(opts, 'sine_mag', deg2rad(8.0)); % [rad]
    freq_sine = iffield(opts, 'sine_freq', 0.5); % [Hz]
    tau_sine = iffield(opts, 'sine_tau', 0.4); % [s]

    idx_steer = (t >= t_steer_start);
    t_rel = t(idx_steer) - t_steer_start;

    delta(idx_steer) = mag_sine ...
        .* sin(2*pi*freq_sine * t_rel) ...
        .* (1 - exp(-t_rel / tau_sine));

case 'linear_steer'
    is_phased_steer_profile = true;
    Tt = compute_nominal_phased_torque(t, t2, Tt_accel_cmd);

    t_steer_window_ref = t_steer_start;

    slope_linear = iffield(opts, 'linear_slope', deg2rad(3.0)); % [rad/s]

    idx_steer = (t >= t_steer_start);
    t_rel = t(idx_steer) - t_steer_start;

    delta(idx_steer) = slope_linear * t_rel;
    % No steering command clamp here: ctrl.delta_cmd is the raw user command.

otherwise
    error(['Unknown profile "%s". Use straight_accel, mild_sine, slalom, ', ...
        'step_steer, sine_steer, or linear_steer.'], profile);
end

% -------------------------------------------------------------------------
% Optional steering duration cap
% -------------------------------------------------------------------------
if isfield(opts, 't_steer')
    idx_past_steer_window = (t >= (t_steer_window_ref + opts.t_steer));
    delta(idx_past_steer_window) = 0;
end

% Assign back to the expected output control struct format.
ctrl = struct();
ctrl.t = t(:).';
ctrl.Tt_cmd = Tt(:).';       % nominal/raw table; feedback may override before release
ctrl.delta_cmd = delta(:).'; % raw command, not clipped by NLP bounds
ctrl.Tb_cmd = zeros(size(ctrl.t));

% Metadata for the online speed-preparation torque controller.
ctrl.speed_prep_enable = is_phased_steer_profile && iffield(opts, 'speed_prep_enable', true);
ctrl.U_target = U_target;
ctrl.t_release = t2;
ctrl.t_steer_start = t_steer_start;
ctrl.t_accel = t_accel;
ctrl.t_hold = t_hold;
ctrl.t_steer_delay = t_steer_delay;
ctrl.Tt_accel_cmd = Tt_accel_cmd;
ctrl.Tt_hold_ff = Tt_eq;
ctrl.speed_hold_Kp = speed_hold_Kp;
ctrl.drive_torque_mode = drive_torque_mode;

% Steering metadata for exact online command evaluation in
% make_applied_control_phys. This avoids small interpolation ramps at the
% release/steering switching instants when t_release or t_steer_start is not
% exactly on the ctrl.t grid.
ctrl.profile = lower(profile);
ctrl.step_mag = iffield(opts, 'step_mag', deg2rad(5.0));
ctrl.step_dur = iffield(opts, 'step_dur', 2.0);
ctrl.step_ramp_time = iffield(opts, 'step_ramp_time', 0.10);
ctrl.sine_mag = iffield(opts, 'sine_mag', deg2rad(8.0));
ctrl.sine_freq = iffield(opts, 'sine_freq', 0.5);
ctrl.sine_tau = iffield(opts, 'sine_tau', 0.4);
ctrl.linear_slope = iffield(opts, 'linear_slope', deg2rad(3.0));
if isfield(opts, 't_steer')
    ctrl.t_steer = opts.t_steer;
else
    ctrl.t_steer = inf;
end

end

% =========================================================================
% LOCAL HELPER FUNCTIONS
% =========================================================================

function Tt = compute_nominal_phased_torque(t, t_release, Tt_accel_cmd)
% Nominal pre-release torque table used for plotting/interpolation fallback.
% The real pre-release command for phased steering tests is computed online
% from current speed in make_applied_control_phys.
Tt = zeros(size(t));
Tt(t < t_release) = Tt_accel_cmd;
Tt(t >= t_release) = 0;
end

function val = iffield(strct, field, default_val)
% Safe check utility function to keep defaults if options structure fields are omitted.
if isfield(strct, field)
    val = strct.(field);
else
    val = default_val;
end
end









%% ------------------------------------------------------------------------
function x0_scaled = make_initial_state_scaled(veh, model)
ux0 = 5.0;
x0_phys = [ ...
ux0; % ux
0; % uy
0; % r
0; % phi
0; % phidot
0; % theta
0; % thetadot
0; % n
0; % xi
ux0/veh.rw; % omega_fl
ux0/veh.rw; % omega_fr
ux0/veh.rw; % omega_rl
ux0/veh.rw]; % omega_rr
x0_scaled = x0_phys(:) ./ model.x_s(:);
% x0_scaled = min(max(x0_scaled, model.x_min), model.x_max);
end

%% ------------------------------------------------------------------------
function z0_scaled = static_load_guess_scaled(veh, model)
Z_front = veh.m*veh.g*veh.lr/veh.l;
Z_rear = veh.m*veh.g*veh.lf/veh.l;
z_phys = [0.5*Z_front; 0.5*Z_front; 0.5*Z_rear; 0.5*Z_rear];
z0_scaled = z_phys ./ model.z_s(:);
% z0_scaled = min(max(z0_scaled, model.z_min), model.z_max);
end

%% ------------------------------------------------------------------------
function [dxs, z_new] = rhs_scaled(t, xs, ctrl, veh, model, opts, z_guess)
xs = xs(:);
kappa = eval_kappa(opts, t, xs);
pv = make_model_pv(opts, kappa, veh);
u_scaled = make_applied_control_scaled(t, xs, ctrl, veh, model, opts);
z_new = solve_loads_newton(model, xs, u_scaled, pv, z_guess, opts, false);
dxs = full(model.f_xdot(xs, u_scaled, z_new, pv));
dxs = dxs(:);
end

%% ------------------------------------------------------------------------
function u_cmd_phys = make_command_control_phys(t, ctrl)
% Interpolate the raw arbitrary command histories. These are intentionally
% not clipped by the NLP control bounds; they are the commands the user asked
% the open-loop simulator to replay.
Tt_cmd = interp1(ctrl.t, ctrl.Tt_cmd, t, 'linear', 'extrap');
Tb_cmd = interp1(ctrl.t, ctrl.Tb_cmd, t, 'linear', 'extrap');
delta_cmd = interp1(ctrl.t, ctrl.delta_cmd, t, 'linear', 'extrap');
u_cmd_phys = [Tt_cmd; Tb_cmd; delta_cmd];
end

%% ------------------------------------------------------------------------
function [u_phys, u_diag] = make_applied_control_phys(t, xs, ctrl, veh, model, opts)
% Convert commands to the actual controls seen by my_model.m.
%
% For legacy profiles, Tt_cmd is simply the interpolated command table.
%
% For step_steer / sine_steer / linear_steer with ctrl.speed_prep_enable,
% the pre-release drive torque is computed online from the current simulated
% longitudinal speed:
%
%   Tt_cmd = T_drag_now + m*rw*Kp*(U_target - ux)
%
% and then clipped to [0, ctrl.Tt_accel_cmd]. This gives a simple and robust
% closed-loop behavior:
%   - far below target speed, the command saturates at high/max torque;
%   - near target speed, the command backs off smoothly;
%   - at target speed, the command approaches the drag-balancing torque;
%   - after ctrl.t_release, the command table sets drive torque to zero.
%
% The actual applied drive torque is still protected by the requested
% motor-torque / motor-power cap:
%
%   Tt_actual = min(Tt_cmd, Td_max, Pmax/omega_rear)

u_cmd_raw_phys = make_command_control_phys(t, ctrl);
Tt_cmd = u_cmd_raw_phys(1);
Tb_cmd = u_cmd_raw_phys(2);
delta_cmd = u_cmd_raw_phys(3);

% -------------------------------------------------------------------------
% Closed-loop speed-preparation drive torque before torque release.
% -------------------------------------------------------------------------
if isfield(ctrl, 'speed_prep_enable') && ctrl.speed_prep_enable
    if t < ctrl.t_release
        ux_phys = xs(1) * model.x_s(1);

        % Current-speed drag feedforward. Use max(ux,0) only to avoid an
        % unphysical positive drag-feedforward value for accidental reverse speed.
        ux_for_drag = max(ux_phys, 0.0);
        T_drag_now = 0.5 * veh.drag_coeff * ux_for_drag^2 * veh.rw;

        % Simple proportional speed feedback. Units are approximately [Nm].
        T_speed_fb = veh.m * veh.rw * ctrl.speed_hold_Kp * (ctrl.U_target - ux_phys);

        Tt_cmd = T_drag_now + T_speed_fb;

        % No brake is used in this test. If the car is above target, command zero
        % drive torque and let drag slow it down. If far below target, command the
        % chosen acceleration torque; the actual torque limiter below still applies.
        Tt_cmd = min(max(Tt_cmd, 0.0), ctrl.Tt_accel_cmd);
        delta_cmd = 0.0;
    else
        % After the release time, force the drive command to zero exactly. Do
        % not rely on interpolation of ctrl.Tt_cmd, because a release time that
        % is not on ctrl.t can otherwise create a small artificial ramp.
        Tt_cmd = 0.0;

        % Evaluate the phased steering command analytically from the current
        % solver time. This is solver-safe because it is a pure function of
        % time and ctrl metadata, with no persistent state or history.
        delta_cmd = phased_steering_command(t, ctrl);
    end
end

omega_rl = xs(12) * model.x_s(12);
omega_rr = xs(13) * model.x_s(13);
omega_rear = 0.5*(omega_rl + omega_rr);

% Denominator guard only. Do not use abs(omega_rear): the NLP formula uses
% the signed rear-axle average, and normal forward driving keeps it positive.
omega_for_power = max(omega_rear, opts.min_power_omega);
Tt_power_max = veh.power_motor_max / omega_for_power;

Td_max = veh.Tt_max;
if isfield(veh, 'Td_state_max')
    Td_max = veh.Td_state_max;
end

% Old bounded-control policy, intentionally disabled:
% Tt = min(max(Tt_cmd, veh.Tt_min), min(veh.Tt_max, Tt_power_max));
% Tb = 0.0;
% delta = min(max(delta_cmd, veh.delta_min), veh.delta_max);

Tt = min([Tt_cmd; Td_max; Tt_power_max]);
Tb = Tb_cmd;
delta = delta_cmd;

u_phys = [Tt; Tb; delta];

if nargout > 1
    u_diag = struct();
    % Effective command after speed-feedback override, before actual limiter.
    u_diag.u_cmd_phys = [Tt_cmd; Tb_cmd; delta_cmd];
    % Raw table command before speed-feedback override, useful for debugging.
    u_diag.u_cmd_raw_phys = u_cmd_raw_phys;
    u_diag.omega_rl = omega_rl;
    u_diag.omega_rr = omega_rr;
    u_diag.omega_rear = omega_rear;
    u_diag.omega_for_power = omega_for_power;
    u_diag.Tt_power_max = Tt_power_max;
    u_diag.Td_max = Td_max;
    u_diag.Tt_upper_bound = min(Td_max, Tt_power_max);
    u_diag.power_rear = Tt * omega_rear;
    u_diag.power_motor_max = veh.power_motor_max;
end
end

%% ------------------------------------------------------------------------
function delta_cmd = phased_steering_command(t, ctrl)
% Evaluate the phased steering command exactly from solver time.
% This avoids relying on linear interpolation across discontinuities.
delta_cmd = 0.0;

if ~isfield(ctrl, 't_steer_start') || t < ctrl.t_steer_start
    return;
end

if isfield(ctrl, 't_steer') && isfinite(ctrl.t_steer) && ...
        t >= ctrl.t_steer_start + ctrl.t_steer
    return;
end

t_rel = t - ctrl.t_steer_start;

switch lower(ctrl.profile)
case 'step_steer'
    delta_cmd = ctrl.step_mag .* smooth_step_pulse(t_rel, ctrl.step_dur, ctrl.step_ramp_time);

case 'sine_steer'
    delta_cmd = ctrl.sine_mag ...
        .* sin(2*pi*ctrl.sine_freq*t_rel) ...
        .* (1 - exp(-t_rel/ctrl.sine_tau));

case 'linear_steer'
    delta_cmd = ctrl.linear_slope * t_rel;

otherwise
    % Legacy profiles should not call this helper because speed_prep_enable
    % is false for them. Keep zero as a safe fallback.
    delta_cmd = 0.0;
end
end

%% ------------------------------------------------------------------------
function y = smooth_step_pulse(t_rel, dur_step, ramp_step)
%SMOOTH_STEP_PULSE Unit-amplitude smoothed step pulse for the step-steer input.
% The pulse is exactly zero before t_rel = 0 and after t_rel >= dur_step.
% It uses a half-cosine rise/fall so ode15i does not see an ideal
% discontinuity at the steering start/end instants.
y = zeros(size(t_rel));

if ~isscalar(dur_step) || ~isfinite(dur_step) || dur_step <= 0
    return;
end
if ~isscalar(ramp_step) || ~isfinite(ramp_step)
    ramp_step = 0.0;
end

ramp_step = max(ramp_step, 0.0);
if ramp_step <= 0
    y(t_rel >= 0 & t_rel < dur_step) = 1.0;
    return;
end

ramp_step = min(ramp_step, 0.5*dur_step);

idx_rise = (t_rel >= 0) & (t_rel < ramp_step);
y(idx_rise) = 0.5 * (1 - cos(pi * t_rel(idx_rise) / ramp_step));

idx_hold = (t_rel >= ramp_step) & (t_rel < dur_step - ramp_step);
y(idx_hold) = 1.0;

idx_fall = (t_rel >= dur_step - ramp_step) & (t_rel < dur_step);
tau_fall = t_rel(idx_fall) - (dur_step - ramp_step);
y(idx_fall) = 0.5 * (1 + cos(pi * tau_fall / ramp_step));
end

%% ------------------------------------------------------------------------
function u_scaled = make_applied_control_scaled(t, xs, ctrl, veh, model, opts)
u_phys = make_applied_control_phys(t, xs, ctrl, veh, model, opts);
u_scaled = u_phys ./ model.u_s(:);
end

%% ------------------------------------------------------------------------
function kappa = eval_kappa(opts, t, xs) %#ok<INUSD>
% The simple simulator uses a straight road by default. You can replace this
% with a function handle through opts.kappa_fun if needed.
if isfield(opts, 'kappa_fun') && ~isempty(opts.kappa_fun)
kappa = opts.kappa_fun(t, xs);
else
kappa = opts.kappa_constant;
end
end

%% ------------------------------------------------------------------------
function pv = make_model_pv(opts, kappa, veh)
% Runtime parameter vector used by my_model.m:
%   pv = [kappa; H; q1; q2].
% Defaults reproduce the parameters from my_params.m exactly. If opts.model_d
% is provided, the single-d constraint H=h-d, q1=q2=d is used for simulation.
if isfield(opts, 'model_d') && ~isempty(opts.model_d)
    d = opts.model_d;
    H = veh.h - d;
    q1 = d;
    q2 = d;
else
    H = iffield(opts, 'model_H', veh.H);
    q1 = iffield(opts, 'model_q1', veh.q1);
    q2 = iffield(opts, 'model_q2', veh.q2);
end
pv = [kappa; H; q1; q2];
end

%% ------------------------------------------------------------------------
function z = solve_loads_newton(model, xs, us, pv, z_guess, opts, do_warn)
% Solve the four lifted tyre-load equations h_load(x,u,z,kappa)=0.
%
% This is the core DAE reduction used by both integrators. z is not
% integrated as a state; at every RHS/stage evaluation it is recomputed so
% that the exact same Chapter-9 load residuals from my_model.m are satisfied.
%
% Version v2 uses the analytic CasADi Jacobian dh_load/dz instead of finite
% differencing the four algebraic variables. This is much faster for RK4,
% because RK4 evaluates the RHS four times per fixed step.
z = z_guess(:);
% z = min(max(z, model.z_min), model.z_max);

r = full(model.f_hload(xs, us, z, pv));
r = r(:);
if norm(r, inf) < opts.load_tol
return;
end

for iter = 1:opts.load_max_iter
r = full(model.f_hload(xs, us, z, pv));
r = r(:);
rnorm = norm(r, inf);
if rnorm < opts.load_tol
return;
end

J = full(model.f_hload_jac_z(xs, us, z, pv));
if any(~isfinite(J(:))) || any(~isfinite(r(:)))
break;
end

% Four-by-four Newton system. Use pinv only as a last-resort guard.
if rcond(J) < 1e-12
step = -pinv(J) * r;
else
step = -J \ r;
end
if any(~isfinite(step))
break;
end

% Damped Newton with simple backtracking and z-bounds preservation.
alpha = 1.0;
accepted = false;
for bt = 1:8
z_trial = z + alpha*step;
% z_trial = min(max(z_trial, model.z_min), model.z_max);
r_trial = full(model.f_hload(xs, us, z_trial, pv));
r_trial = r_trial(:);
if norm(r_trial, inf) <= 0.9*rnorm || norm(r_trial, inf) < opts.load_tol
z = z_trial;
accepted = true;
break;
end
alpha = 0.5*alpha;
end

if ~accepted
% Do not take a full bad Newton step; take a guarded small step.
% z = min(max(z + 0.10*step, model.z_min), model.z_max);
z = z + 0.10*step;
end
end

r = full(model.f_hload(xs, us, z, pv));
rnorm = norm(r(:), inf);
if do_warn || rnorm > opts.warn_load_residual
warning('Tyre-load Newton residual max |h_load| = %.3e.', rnorm);
end
end

%% ------------------------------------------------------------------------
function sim = simulate_fixed_rk4(x0_scaled, z0_scaled, ctrl, veh, model, opts)
dt = opts.fixed_dt;
t = 0:dt:opts.t_end;
X = zeros(model.nx, numel(t));
Z = zeros(model.nz, numel(t));
X(:,1) = x0_scaled(:);
Z(:,1) = z0_scaled(:);
z_guess = z0_scaled(:);

for k = 1:numel(t)-1
tk = t(k);
xk = X(:,k);

[k1, z1] = rhs_scaled(tk, xk, ctrl, veh, model, opts, z_guess);
[k2, z2] = rhs_scaled(tk + 0.5*dt, xk + 0.5*dt*k1, ctrl, veh, model, opts, z1);
[k3, z3] = rhs_scaled(tk + 0.5*dt, xk + 0.5*dt*k2, ctrl, veh, model, opts, z2);
[k4, z4] = rhs_scaled(tk + dt, xk + dt*k3, ctrl, veh, model, opts, z3);

X(:,k+1) = xk + (dt/6)*(k1 + 2*k2 + 2*k3 + k4);
% if opts.enforce_state_bounds_fixed
% X(:,k+1) = min(max(X(:,k+1), model.x_min), model.x_max);
% end
Z(:,k+1) = z4;
z_guess = z4;
end

sim = postprocess_solution('fixed_rk4', t(:), X, ctrl, veh, model, opts, z0_scaled);
end

%% ------------------------------------------------------------------------
function sim = simulate_ode15i_dae(x0_scaled, z0_scaled, ctrl, veh, model, opts)
%SIMULATE_ODE15I_DAE True index-1 DAE integration of [x; z].
%
% Residual form for ode15i:
% 0 = xdot - f_xdot(x,u,z,kappa)
% 0 = h_load(x,u,z,kappa)
%
% Unlike ode15s/RK4 above, this function does not call solve_loads_newton in
% the RHS. The four lifted tyre loads z are part of the solver state vector.
% MATLAB's DAE solver handles the nonlinear algebraic coupling internally.
% A consistent initial condition is found by decic, with x(0) fixed and z(0)
% allowed to move from the static-load guess.

t0 = 0.0;
y0_guess = [x0_scaled(:); z0_scaled(:)];
yp0_guess = zeros(model.nx + model.nz, 1);

% Give decic a good derivative guess for the differential states. This does
% not solve h_load manually; it only improves decic's starting point.
u0 = make_applied_control_scaled(t0, x0_scaled, ctrl, veh, model, opts);
k0 = eval_kappa(opts, t0, x0_scaled);
pv0 = make_model_pv(opts, k0, veh);
try
yp0_guess(1:model.nx) = full(model.f_xdot(x0_scaled(:), u0, z0_scaled(:), pv0));
catch
yp0_guess(1:model.nx) = 0;
end

fixed_y0 = [true(model.nx,1); false(model.nz,1)]; % keep physical initial x fixed; let loads become consistent
fixed_yp0 = [false(model.nx,1); true(model.nz,1)]; % z_dot is absent from residual, so fix it to zero

resfun = @(t,y,yp) dae_residual_scaled(t, y, yp, ctrl, veh, model, opts);
decic_opts = odeset('RelTol', opts.dae_reltol, 'AbsTol', opts.dae_abstol);
[y0_cons, yp0_cons] = decic(resfun, t0, y0_guess, fixed_y0, yp0_guess, fixed_yp0, decic_opts);
res0_cons = resfun(t0, y0_cons, yp0_cons);
res0_cons_norm = norm(res0_cons, inf);
if res0_cons_norm > 100*opts.dae_abstol
warning('decic returned a relatively large initial DAE residual: %.3e.', res0_cons_norm);
end

% Integrate the DAE. ode15i uses variable steps internally; tspan below only
% fixes the requested output times for easier comparison with the other runs.
tspan = 0:opts.output_dt:opts.t_end;
dae_opts = odeset('RelTol', opts.dae_reltol, 'AbsTol', opts.dae_abstol, ...
'MaxStep', opts.dae_max_step);
[t_dae, y_dae] = ode15i(resfun, tspan, y0_cons, yp0_cons, dae_opts);

Y = y_dae.';
X = Y(1:model.nx,:);
Z = Y(model.nx+1:model.nx+model.nz,:);

% Do not re-solve tyre loads here. Use the algebraic variables returned by
% ode15i so that the diagnostic residual reflects the true DAE solution.
sim = postprocess_dae_solution('ode15i_DAE', t_dae(:), X, Z, ctrl, veh, model, opts);

% Useful diagnostics for users comparing the reduced-ODE and true-DAE paths.
sim.y0_guess = y0_guess;
sim.y0_consistent = y0_cons;
sim.yp0_consistent = yp0_cons;
sim.decic_residual_inf = res0_cons_norm;
sim.initial_z_shift_scaled = y0_cons(model.nx+1:end) - z0_scaled(:);
sim.initial_z_shift_phys = sim.initial_z_shift_scaled .* model.z_s(:);

sim.tyre = sim.tyre;

end

%% ------------------------------------------------------------------------
function res = dae_residual_scaled(t, y, yp, ctrl, veh, model, opts)
y = y(:);
yp = yp(:);
xs = y(1:model.nx);
zs = y(model.nx+1:model.nx+model.nz);
xsdot = yp(1:model.nx);

kap = eval_kappa(opts, t, xs);
pv = make_model_pv(opts, kap, veh);
us = make_applied_control_scaled(t, xs, ctrl, veh, model, opts);

f = full(model.f_xdot(xs, us, zs, pv));
h = full(model.f_hload(xs, us, zs, pv));

res = [xsdot(:) - f(:); h(:)];
end

%% ------------------------------------------------------------------------
function sim = postprocess_solution(name, t, X, ctrl, veh, model, opts, z0_scaled)
N = numel(t);
Z = zeros(model.nz, N);
U = zeros(3, N);
Ucmd = zeros(3, N);
H = zeros(model.nz, N);
ACC = zeros(7, N);
TORQUE = zeros(4, N);
MU = zeros(4, N);
LOAD = zeros(11, N);

TYRE = zeros(12, N);

omega_rear = zeros(1, N);
omega_for_power = zeros(1, N);
Tt_power_max = zeros(1, N);
Td_max_hist = zeros(1, N);
Tt_upper_bound = zeros(1, N);
power_rear = zeros(1, N);
z_guess = z0_scaled(:);

for k = 1:N
xs = X(:,k);
kap = eval_kappa(opts, t(k), xs);
pv = make_model_pv(opts, kap, veh);
[u_phys, u_diag] = make_applied_control_phys(t(k), xs, ctrl, veh, model, opts);
us = u_phys ./ model.u_s(:);
zs = solve_loads_newton(model, xs, us, pv, z_guess, opts, false);
z_guess = zs;

Z(:,k) = zs;
U(:,k) = us;
Ucmd(:,k) = u_diag.u_cmd_phys;
omega_rear(k) = u_diag.omega_rear;
omega_for_power(k) = u_diag.omega_for_power;
Tt_power_max(k) = u_diag.Tt_power_max;
Td_max_hist(k) = u_diag.Td_max;
Tt_upper_bound(k) = u_diag.Tt_upper_bound;
power_rear(k) = u_diag.power_rear;
H(:,k) = full(model.f_hload(xs, us, zs, pv));
ACC(:,k) = full(model.f_acc(xs, us, zs, pv));
TORQUE(:,k) = full(model.f_torque(xs, us, zs, pv));
MU(:,k) = full(model.f_mu(xs, us, zs, pv));
LOAD(:,k) = full(model.f_load(xs, us, zs, pv));

TYRE(:,k) = full(model.f_tyre(xs, us, zs, pv));
end

sim = struct();
sim.name = name;
sim.t = t(:).';
sim.x_scaled = X;
sim.x_phys = X .* model.x_s(:);
sim.z_scaled = Z;
sim.z_phys = Z .* model.z_s(:);
sim.u_scaled = U;
sim.u_phys = U .* model.u_s(:);
sim.u_cmd_phys = Ucmd;
sim.omega_rear = omega_rear;
sim.omega_for_power = omega_for_power;
sim.Tt_power_max = Tt_power_max;
sim.Td_max = Td_max_hist;
sim.Tt_upper_bound = Tt_upper_bound;
sim.power_rear = power_rear;
sim.h_load = H;
sim.acc = ACC;
sim.torque = TORQUE;
sim.mu = MU;
sim.load = LOAD;

sim.tyre = TYRE;

end

%% ------------------------------------------------------------------------
function sim = postprocess_dae_solution(name, t, X, Z, ctrl, veh, model, opts)
N = numel(t);
U = zeros(3, N);
Ucmd = zeros(3, N);
H = zeros(model.nz, N);
ACC = zeros(7, N);
TORQUE = zeros(4, N);
MU = zeros(4, N);
LOAD = zeros(11, N);

TYRE = zeros(12, N);

omega_rear = zeros(1, N);
omega_for_power = zeros(1, N);
Tt_power_max = zeros(1, N);
Td_max_hist = zeros(1, N);
Tt_upper_bound = zeros(1, N);
power_rear = zeros(1, N);

for k = 1:N
xs = X(:,k);
zs = Z(:,k);
kap = eval_kappa(opts, t(k), xs);
pv = make_model_pv(opts, kap, veh);
[u_phys, u_diag] = make_applied_control_phys(t(k), xs, ctrl, veh, model, opts);
us = u_phys ./ model.u_s(:);

U(:,k) = us;
Ucmd(:,k) = u_diag.u_cmd_phys;
omega_rear(k) = u_diag.omega_rear;
omega_for_power(k) = u_diag.omega_for_power;
Tt_power_max(k) = u_diag.Tt_power_max;
Td_max_hist(k) = u_diag.Td_max;
Tt_upper_bound(k) = u_diag.Tt_upper_bound;
power_rear(k) = u_diag.power_rear;
H(:,k) = full(model.f_hload(xs, us, zs, pv));
ACC(:,k) = full(model.f_acc(xs, us, zs, pv));
TORQUE(:,k) = full(model.f_torque(xs, us, zs, pv));
MU(:,k) = full(model.f_mu(xs, us, zs, pv));
LOAD(:,k) = full(model.f_load(xs, us, zs, pv));

TYRE(:,k) = full(model.f_tyre(xs, us, zs, pv));

end

sim = struct();
sim.name = name;
sim.t = t(:).';
sim.x_scaled = X;
sim.x_phys = X .* model.x_s(:);
sim.z_scaled = Z;
sim.z_phys = Z .* model.z_s(:);
sim.u_scaled = U;
sim.u_phys = U .* model.u_s(:);
sim.u_cmd_phys = Ucmd;
sim.omega_rear = omega_rear;
sim.omega_for_power = omega_for_power;
sim.Tt_power_max = Tt_power_max;
sim.Td_max = Td_max_hist;
sim.Tt_upper_bound = Tt_upper_bound;
sim.power_rear = power_rear;
sim.h_load = H;
sim.acc = ACC;
sim.torque = TORQUE;
sim.mu = MU;
sim.load = LOAD;

sim.tyre = TYRE;

end

%% ------------------------------------------------------------------------
function id_result = run_identification_workflow(sim_ode15s, sim_fixed, sim_ode15i_dae, model, ctrl, veh, opts)
%RUN_IDENTIFICATION_WORKFLOW Optional one-step load-transfer identification.
%
% This does not modify the already-completed simulation. It uses one selected
% simulation as clean synthetic data, optionally adds output noise, then fits:
%   1) free [H,q1,q2]
%   2) scalar d with H=h-d and q1=q2=d
% The comparison tests whether the single-d assumption is supported.

sim_id = select_identification_sim(sim_ode15s, sim_fixed, sim_ode15i_dae, opts);
data = make_identification_data(sim_id, ctrl, veh, model, opts);
[target, noise_info] = make_identification_target(data, opts, opts.ident_noise_seed);

id_result = struct();
id_result.source = sim_id.name;
id_result.options = collect_identification_options(opts);
id_result.data_info = data.info;
id_result.noise = noise_info;
id_result.diagnostic = diagnostic_closed_form_q(data, target, veh, opts);

fprintf('Identification source      : %s\n', sim_id.name);
fprintf('Identification target      : %s\n', opts.ident_fit_targets);
fprintf('Identification window      : %.6f to %.6f s, samples = %d\n', ...
    data.t(1), data.t(end), numel(data.t));
fprintf('Time weighting             : %s\n', opts.ident_weight_mode);
fprintf('Simulation parameter values: H = %.6f m, q1 = %.6f m, q2 = %.6f m, d_if_single = %.6f m\n', ...
    data.info.simulation_H, data.info.simulation_q1, data.info.simulation_q2, data.info.simulation_d_if_single);
fprintf('my_params nominal values   : H = %.6f m, q1 = %.6f m, q2 = %.6f m, d = %.6f m\n', ...
    veh.H, veh.q1, veh.q2, veh.d);
fprintf('Closed-form diagnostic q1  : %.6f m using %d/%d samples\n', ...
    id_result.diagnostic.q1_ls, id_result.diagnostic.n_front, numel(data.t));
fprintf('Closed-form diagnostic q2  : %.6f m using %d/%d samples\n', ...
    id_result.diagnostic.q2_ls, id_result.diagnostic.n_rear, numel(data.t));

if opts.ident_fit_free_H_q
    id_result.free = fit_free_H_q1_q2(data, target, model, veh, opts);
    [id_result.free.prediction, id_result.free.prediction_sse] = evaluate_identification_prediction(data, model, veh, opts, ...
        id_result.free.H, id_result.free.q1, id_result.free.q2, target);
    fprintf('Free fit [H,q1,q2]         : H = %.6f m, q1 = %.6f m, q2 = %.6f m, J = %.6e\n', ...
        id_result.free.H, id_result.free.q1, id_result.free.q2, id_result.free.objective);
else
    id_result.free = [];
end

if opts.ident_fit_scalar_d
    id_result.scalar_d = fit_scalar_d(data, target, model, veh, opts);
    [id_result.scalar_d.prediction, id_result.scalar_d.prediction_sse] = evaluate_identification_prediction(data, model, veh, opts, ...
        id_result.scalar_d.H, id_result.scalar_d.q1, id_result.scalar_d.q2, target);
    fprintf('Scalar-d fit               : d = %.6f m, H = %.6f m, J = %.6e\n', ...
        id_result.scalar_d.d, id_result.scalar_d.H, id_result.scalar_d.objective);
else
    id_result.scalar_d = [];
end

id_result.error_to_simulation = make_identification_error_metrics(id_result, data);
print_identification_error_metrics(id_result.error_to_simulation);

if ~isempty(id_result.free)
    id_result.consistency = check_single_d_consistency(id_result.free, veh, opts);
    fprintf('Single-d consistency check : q spread = %.6f m, H mismatch = %.6f m => %s\n', ...
        id_result.consistency.q_spread_abs, id_result.consistency.H_mismatch_abs, ...
        passfail(id_result.consistency.is_consistent));
    if id_result.consistency.is_consistent
        id_result.recommendation = 'single_d_is_supported_by_this_dataset';
        fprintf('Recommendation             : single scalar d is supported by this dataset.\n');
    else
        id_result.recommendation = 'keep_free_H_q1_q2_or_fit_state_scheduled_parameters';
        fprintf('Recommendation             : do not force scalar d; keep [H,q1,q2] separate or fit a state-scheduled model.\n');
    end
else
    id_result.consistency = [];
    id_result.recommendation = 'not_available_without_free_H_q1_q2_fit';
end

if opts.ident_noise_enable && opts.ident_noise_runs > 1
    id_result.noise_monte_carlo = run_identification_noise_monte_carlo(data, model, veh, opts);
    print_noise_monte_carlo_summary(id_result.noise_monte_carlo);
else
    id_result.noise_monte_carlo = [];
end

if opts.ident_plot
    plot_identification_results(data, target, id_result, opts);
end
end

%% ------------------------------------------------------------------------
function sim_id = select_identification_sim(sim_ode15s, sim_fixed, sim_ode15i_dae, opts)
src = lower(opts.ident_source);
switch src
case {'ode15s','ode','reduced','reduced_ode'}
    sim_id = sim_ode15s;
case {'fixed','rk4','fixed_rk4'}
    sim_id = sim_fixed;
case {'dae','ode15i','ode15i_dae'}
    if isempty(sim_ode15i_dae)
        error('opts.ident_source requested DAE, but opts.run_dae was false or the DAE result is empty.');
    end
    sim_id = sim_ode15i_dae;
otherwise
    error('Unknown opts.ident_source "%s". Use ode15s, fixed, or dae.', opts.ident_source);
end
end

%% ------------------------------------------------------------------------
function data = make_identification_data(sim, ctrl, veh, model, opts)
t_all = sim.t(:).';
if isempty(opts.ident_start_time)
    % For phased steering tests, the physically meaningful default window
    % starts when steering actually starts after the zero-torque delay.  For
    % legacy profiles, ctrl.t_steer_start exists only as metadata from the
    % phased-profile option block, so detect the first nonzero steering
    % command from the recorded command table instead.
    if isfield(ctrl, 'speed_prep_enable') && ctrl.speed_prep_enable && isfield(ctrl, 't_steer_start')
        t0 = ctrl.t_steer_start;
    else
        delta_abs = abs(ctrl.delta_cmd(:).');
        idx_delta = find(delta_abs > 1e-10, 1, 'first');
        if isempty(idx_delta)
            t0 = t_all(1);
        else
            t0 = ctrl.t(idx_delta);
        end
    end
else
    t0 = opts.ident_start_time;
end
if isempty(opts.ident_end_time)
    tf = min(t_all(end), t0 + opts.ident_horizon);
else
    tf = opts.ident_end_time;
end
idx = find(t_all >= t0 & t_all <= tf);
if isempty(idx)
    error('No samples found in identification window [%.6f, %.6f] s.', t0, tf);
end
stride = max(1, round(opts.ident_sample_stride));
idx = idx(1:stride:end);

N = numel(idx);
kappa_hist = zeros(1,N);
for k = 1:N
    kappa_hist(k) = eval_kappa(opts, t_all(idx(k)), sim.x_scaled(:,idx(k)));
end

data = struct();
data.t = t_all(idx);
data.idx = idx;
data.x_scaled = sim.x_scaled(:,idx);
data.x_phys = sim.x_phys(:,idx);
data.z_scaled = sim.z_scaled(:,idx);
data.z_phys = sim.z_phys(:,idx);
data.u_scaled = sim.u_scaled(:,idx);
data.u_phys = sim.u_phys(:,idx);
data.tyre = sim.tyre(:,idx);
data.kappa = kappa_hist;
data.weights = identification_time_weights(data.t, opts);
data.info = struct();
data.info.window_start = data.t(1);
data.info.window_end = data.t(end);
data.info.n_samples = N;
data.info.source_name = sim.name;
pv_sim_nom = make_model_pv(opts, 0.0, veh);
data.info.simulation_H = pv_sim_nom(2);
data.info.simulation_q1 = pv_sim_nom(3);
data.info.simulation_q2 = pv_sim_nom(4);
data.info.simulation_d_if_single = 0.5*(pv_sim_nom(3) + pv_sim_nom(4));
data.info.nominal_H = veh.H;
data.info.nominal_q1 = veh.q1;
data.info.nominal_q2 = veh.q2;
data.info.nominal_d = veh.d;
end

%% ------------------------------------------------------------------------
function w = identification_time_weights(t, opts)
tau = max(opts.ident_weight_tau, eps);
trel = t(:).' - t(1);
mode = lower(opts.ident_weight_mode);
switch mode
case {'uniform','flat','long','full'}
    w = ones(size(trel));
case {'immediate','exp','exponential','exponential_decay'}
    w = exp(-trel./tau);
case {'late','future','terminal'}
    if numel(trel) == 1
        w = ones(size(trel));
    else
        denom = max(trel(end), eps);
        w = (trel./denom).^opts.ident_weight_power;
        w(1) = min(w(2:end));
    end
otherwise
    error('Unknown opts.ident_weight_mode "%s".', opts.ident_weight_mode);
end
w = w ./ max(mean(w), eps);
end

%% ------------------------------------------------------------------------
function [target, noise_info] = make_identification_target(data, opts, seed)
target = struct();
target.Fz = data.z_phys;
target.Fx = data.tyre(1:4,:);
target.Fy = data.tyre(5:8,:);

noise_info = struct();
noise_info.enabled = opts.ident_noise_enable;
noise_info.seed = seed;
noise_info.std_Fz = opts.ident_noise_std_Fz;
noise_info.std_Fx = opts.ident_noise_std_Fx;
noise_info.std_Fy = opts.ident_noise_std_Fy;

if opts.ident_noise_enable
    old_rng = rng;
    rng(seed);
    if opts.ident_noise_std_Fz > 0
        target.Fz = target.Fz + opts.ident_noise_std_Fz .* randn(size(target.Fz));
    end
    if opts.ident_noise_std_Fx > 0
        target.Fx = target.Fx + opts.ident_noise_std_Fx .* randn(size(target.Fx));
    end
    if opts.ident_noise_std_Fy > 0
        target.Fy = target.Fy + opts.ident_noise_std_Fy .* randn(size(target.Fy));
    end
    rng(old_rng);
end
end

%% ------------------------------------------------------------------------
function out = collect_identification_options(opts)
fields = {'ident_source','ident_fit_targets','ident_start_time','ident_end_time', ...
    'ident_horizon','ident_sample_stride','ident_weight_mode','ident_weight_tau', ...
    'ident_noise_enable','ident_noise_seed','ident_noise_runs', ...
    'ident_noise_std_Fz','ident_noise_std_Fx','ident_noise_std_Fy'};
out = struct();
for i = 1:numel(fields)
    out.(fields{i}) = opts.(fields{i});
end
end

%% ------------------------------------------------------------------------
function diag = diagnostic_closed_form_q(data, target, veh, opts)
delta = data.u_phys(3,:);
Fx = target.Fx;
Fy = target.Fy;
Fz = target.Fz;

fxf = Fx(1,:) + Fx(2,:);
fyf = Fy(1,:) + Fy(2,:);
Y1 = fyf .* cos(delta) + fxf .* sin(delta);
Y2 = Fy(3,:) + Fy(4,:);

phi = data.x_phys(4,:);
phidot = data.x_phys(5,:);

a1 = 0.5*veh.t1 .* (Fz(2,:) - Fz(1,:)) - veh.kphi1.*phi - veh.cphi1.*phidot;
a2 = 0.5*veh.t2 .* (Fz(4,:) - Fz(3,:)) - veh.kphi2.*phi - veh.cphi2.*phidot;

w = data.weights;
mask1 = abs(Y1) > opts.ident_min_abs_Y;
mask2 = abs(Y2) > opts.ident_min_abs_Y;
q1_inst = NaN(size(Y1));
q2_inst = NaN(size(Y2));
q1_inst(mask1) = a1(mask1)./Y1(mask1);
q2_inst(mask2) = a2(mask2)./Y2(mask2);

if any(mask1)
    q1_ls = sum(w(mask1).*Y1(mask1).*a1(mask1)) / max(sum(w(mask1).*Y1(mask1).^2), eps);
else
    q1_ls = NaN;
end
if any(mask2)
    q2_ls = sum(w(mask2).*Y2(mask2).*a2(mask2)) / max(sum(w(mask2).*Y2(mask2).^2), eps);
else
    q2_ls = NaN;
end

diag = struct();
diag.q1_ls = q1_ls;
diag.q2_ls = q2_ls;
diag.q1_inst = q1_inst;
diag.q2_inst = q2_inst;
diag.Y1 = Y1;
diag.Y2 = Y2;
diag.a1 = a1;
diag.a2 = a2;
diag.n_front = nnz(mask1);
diag.n_rear = nnz(mask2);
end

%% ------------------------------------------------------------------------
function fit = fit_free_H_q1_q2(data, target, model, veh, opts)
if isfield(data, 'info') && isfield(data.info, 'simulation_H')
    p0 = [data.info.simulation_H; data.info.simulation_q1; data.info.simulation_q2];
else
    p0 = [veh.H; veh.q1; veh.q2];
end
eta0 = p0 ./ veh.h;
opt = optimset('Display', opts.ident_optimizer_display, ...
    'MaxFunEvals', opts.ident_max_fun_evals, ...
    'MaxIter', opts.ident_max_iter, ...
    'TolX', opts.ident_tol_x, ...
    'TolFun', opts.ident_tol_fun);
obj = @(eta) identification_sse_H_q(eta(:).*veh.h, data, target, model, veh, opts);
[eta_hat, fval, exitflag, output] = fminsearch(obj, eta0, opt);
p_hat = clamp_ident_params(eta_hat(:).*veh.h, veh, opts);
fit = struct();
fit.H = p_hat(1);
fit.q1 = p_hat(2);
fit.q2 = p_hat(3);
fit.objective = identification_sse_H_q(p_hat, data, target, model, veh, opts);
fit.raw_objective = fval;
fit.exitflag = exitflag;
fit.output = output;
end

%% ------------------------------------------------------------------------
function fit = fit_scalar_d(data, target, model, veh, opts)
lb = opts.ident_lower_frac_h * veh.h;
ub = opts.ident_upper_frac_h * veh.h;
opt = optimset('Display', opts.ident_optimizer_display, ...
    'MaxFunEvals', opts.ident_max_fun_evals, ...
    'MaxIter', opts.ident_max_iter, ...
    'TolX', opts.ident_tol_x);
obj = @(d) identification_sse_scalar_d(d, data, target, model, veh, opts);
[d_hat, fval, exitflag, output] = fminbnd(obj, lb, ub, opt);
fit = struct();
fit.d = d_hat;
fit.H = veh.h - d_hat;
fit.q1 = d_hat;
fit.q2 = d_hat;
fit.objective = fval;
fit.exitflag = exitflag;
fit.output = output;
end

%% ------------------------------------------------------------------------
function J = identification_sse_scalar_d(d, data, target, model, veh, opts)
H = veh.h - d;
q1 = d;
q2 = d;
J = identification_sse_H_q([H; q1; q2], data, target, model, veh, opts);
end

%% ------------------------------------------------------------------------
function J = identification_sse_H_q(p, data, target, model, veh, opts)
p = p(:);
if ~all(isfinite(p))
    J = opts.ident_bound_penalty * (1 + nnz(~isfinite(p)));
    return;
end
J = ident_bound_penalty(p, veh, opts);
lb = opts.ident_lower_frac_h * veh.h;
ub = opts.ident_upper_frac_h * veh.h;
if any(p < lb) || any(p > ub)
    % Do not evaluate the tyre-load Newton solve with clearly unphysical
    % candidate heights during unconstrained fminsearch exploration.
    J = J + opts.ident_bound_penalty;
    return;
end
[~, sse] = evaluate_identification_prediction(data, model, veh, opts, p(1), p(2), p(3), target);
J = J + sse;
end

%% ------------------------------------------------------------------------
function [pred, sse] = evaluate_identification_prediction(data, model, veh, opts, H, q1, q2, target)
% If target is supplied, return normalized weighted SSE against it. If target
% is omitted, only return model predictions for plotting/reporting.
if nargin < 8
    target = [];
end
N = numel(data.t);
pred = struct();
pred.Fz = zeros(4,N);
pred.Fx = zeros(4,N);
pred.Fy = zeros(4,N);
pred.z_scaled = zeros(model.nz,N);
pred.h_load = zeros(model.nz,N);

opts_eval = opts;
opts_eval.warn_load_residual = inf;
z_guess = data.z_scaled(:,1);
sse = 0.0;
use = identification_target_flags(opts.ident_fit_targets);

for k = 1:N
    xs = data.x_scaled(:,k);
    us = data.u_scaled(:,k);
    pv = [data.kappa(k); H; q1; q2];
    zs = solve_loads_newton(model, xs, us, pv, z_guess, opts_eval, false);
    if any(~isfinite(zs(:)))
        if ~isempty(target)
            sse = opts.ident_bound_penalty * 1e3;
            return;
        end
        zs = NaN(model.nz,1);
    end
    z_guess = zs;
    tyre = full(model.f_tyre(xs, us, zs, pv));
    hres = full(model.f_hload(xs, us, zs, pv));
    if any(~isfinite(tyre(:))) || any(~isfinite(hres(:)))
        if ~isempty(target)
            sse = opts.ident_bound_penalty * 1e3;
            return;
        end
    end

    pred.z_scaled(:,k) = zs;
    pred.Fz(:,k) = zs .* model.z_s(:);
    pred.Fx(:,k) = tyre(1:4);
    pred.Fy(:,k) = tyre(5:8);
    pred.h_load(:,k) = hres(:);

    if ~isempty(target)
        wk = sqrt(data.weights(k));
        if use.Fz
            rz = wk .* (pred.Fz(:,k) - target.Fz(:,k)) ./ max(abs(opts.ident_Fz_scale), eps);
            sse = sse + sum(rz.^2);
        end
        if use.Fx
            rx = wk .* (pred.Fx(:,k) - target.Fx(:,k)) ./ max(abs(opts.ident_Fx_scale), eps);
            sse = sse + sum(rx.^2);
        end
        if use.Fy
            ry = wk .* (pred.Fy(:,k) - target.Fy(:,k)) ./ max(abs(opts.ident_Fy_scale), eps);
            sse = sse + sum(ry.^2);
        end
        if ~isfinite(sse)
            sse = opts.ident_bound_penalty * 1e3;
            return;
        end
    end
end
end

%% ------------------------------------------------------------------------
function use = identification_target_flags(target_string)
ts = lower(strrep(target_string, '_', ''));
use = struct();
use.Fz = contains(ts, 'fz');
use.Fx = contains(ts, 'fx');
use.Fy = contains(ts, 'fy');
if ~use.Fz && ~use.Fx && ~use.Fy
    error('opts.ident_fit_targets must contain Fz, Fx, and/or Fy.');
end
end

%% ------------------------------------------------------------------------
function p = clamp_ident_params(p, veh, opts)
lb = opts.ident_lower_frac_h * veh.h;
ub = opts.ident_upper_frac_h * veh.h;
p = min(max(p(:), lb), ub);
end

%% ------------------------------------------------------------------------
function pen = ident_bound_penalty(p, veh, opts)
if ~all(isfinite(p(:)))
    pen = opts.ident_bound_penalty * (1 + nnz(~isfinite(p(:))));
    return;
end
lb = opts.ident_lower_frac_h * veh.h;
ub = opts.ident_upper_frac_h * veh.h;
low = max(lb - p(:), 0.0) ./ max(veh.h, eps);
high = max(p(:) - ub, 0.0) ./ max(veh.h, eps);
pen = opts.ident_bound_penalty * sum(low.^2 + high.^2);
end

%% ------------------------------------------------------------------------
function consistency = check_single_d_consistency(free_fit, veh, opts)
d_from_q = 0.5*(free_fit.q1 + free_fit.q2);
H_from_q = veh.h - d_from_q;
q_spread = abs(free_fit.q1 - free_fit.q2);
H_mismatch = abs(free_fit.H - H_from_q);
q_scale = max(abs(d_from_q), 1e-3);
H_scale = max(abs(H_from_q), 1e-3);
q_ok = q_spread <= opts.ident_consistency_abs_tol + opts.ident_consistency_rel_tol*q_scale;
H_ok = H_mismatch <= opts.ident_consistency_abs_tol + opts.ident_consistency_rel_tol*H_scale;
consistency = struct();
consistency.d_from_q = d_from_q;
consistency.H_from_q = H_from_q;
consistency.q_spread_abs = q_spread;
consistency.H_mismatch_abs = H_mismatch;
consistency.q_spread_rel = q_spread / q_scale;
consistency.H_mismatch_rel = H_mismatch / H_scale;
consistency.q_ok = q_ok;
consistency.H_ok = H_ok;
consistency.is_consistent = q_ok && H_ok;
end

%% ------------------------------------------------------------------------
function err = make_identification_error_metrics(id_result, data)
%MAKE_IDENTIFICATION_ERROR_METRICS Compare fitted values to the parameters
%actually used to generate the selected simulation data.
sim_p = [data.info.simulation_H; data.info.simulation_q1; data.info.simulation_q2];
err = struct();
err.simulation_H_q1_q2 = sim_p;
err.simulation_d_if_single = data.info.simulation_d_if_single;

if isfield(id_result, 'free') && ~isempty(id_result.free)
    free_p = [id_result.free.H; id_result.free.q1; id_result.free.q2];
    err.free_H_q1_q2 = free_p;
    err.free_error_H_q1_q2 = free_p - sim_p;
    err.free_abs_error_H_q1_q2 = abs(err.free_error_H_q1_q2);
    err.free_max_abs_error = max(err.free_abs_error_H_q1_q2);
else
    err.free_H_q1_q2 = [];
    err.free_error_H_q1_q2 = [];
    err.free_abs_error_H_q1_q2 = [];
    err.free_max_abs_error = NaN;
end

if isfield(id_result, 'scalar_d') && ~isempty(id_result.scalar_d)
    scalar_p = [id_result.scalar_d.H; id_result.scalar_d.q1; id_result.scalar_d.q2];
    err.scalar_H_q1_q2 = scalar_p;
    err.scalar_error_H_q1_q2 = scalar_p - sim_p;
    err.scalar_abs_error_H_q1_q2 = abs(err.scalar_error_H_q1_q2);
    err.scalar_max_abs_error = max(err.scalar_abs_error_H_q1_q2);
    err.scalar_d = id_result.scalar_d.d;
    err.scalar_d_error_vs_sim_qmean = id_result.scalar_d.d - data.info.simulation_d_if_single;
else
    err.scalar_H_q1_q2 = [];
    err.scalar_error_H_q1_q2 = [];
    err.scalar_abs_error_H_q1_q2 = [];
    err.scalar_max_abs_error = NaN;
    err.scalar_d = NaN;
    err.scalar_d_error_vs_sim_qmean = NaN;
end
end

%% ------------------------------------------------------------------------
function print_identification_error_metrics(err)
fprintf('Fit error vs simulation    :\n');
if ~isempty(err.free_error_H_q1_q2)
    fprintf('  free [H,q1,q2] error     : [%+.6e, %+.6e, %+.6e] m, max abs = %.6e m\n', ...
        err.free_error_H_q1_q2(1), err.free_error_H_q1_q2(2), err.free_error_H_q1_q2(3), ...
        err.free_max_abs_error);
end
if ~isempty(err.scalar_error_H_q1_q2)
    fprintf('  scalar-d [H,q1,q2] error : [%+.6e, %+.6e, %+.6e] m, max abs = %.6e m\n', ...
        err.scalar_error_H_q1_q2(1), err.scalar_error_H_q1_q2(2), err.scalar_error_H_q1_q2(3), ...
        err.scalar_max_abs_error);
    fprintf('  scalar d error vs q mean : %+.6e m\n', err.scalar_d_error_vs_sim_qmean);
end
end


%% ------------------------------------------------------------------------
function mc = run_identification_noise_monte_carlo(data, model, veh, opts)
R = max(1, round(opts.ident_noise_runs));
free_params = NaN(3,R);
scalar_d = NaN(1,R);
free_J = NaN(1,R);
scalar_J = NaN(1,R);
for r = 1:R
    [target_r, ~] = make_identification_target(data, opts, opts.ident_noise_seed + r - 1);
    if opts.ident_fit_free_H_q
        fit_free = fit_free_H_q1_q2(data, target_r, model, veh, opts);
        free_params(:,r) = [fit_free.H; fit_free.q1; fit_free.q2];
        free_J(r) = fit_free.objective;
    end
    if opts.ident_fit_scalar_d
        fit_d = fit_scalar_d(data, target_r, model, veh, opts);
        scalar_d(r) = fit_d.d;
        scalar_J(r) = fit_d.objective;
    end
end
mc = struct();
mc.n_runs = R;
mc.free_params = free_params;
mc.scalar_d = scalar_d;
mc.free_objective = free_J;
mc.scalar_objective = scalar_J;
mc.free_mean = mean(free_params, 2, 'omitnan');
mc.free_std = std(free_params, 0, 2, 'omitnan');
mc.scalar_d_mean = mean(scalar_d, 'omitnan');
mc.scalar_d_std = std(scalar_d, 0, 'omitnan');
end

%% ------------------------------------------------------------------------
function print_noise_monte_carlo_summary(mc)
fprintf('Noise Monte Carlo runs     : %d\n', mc.n_runs);
fprintf('  Free H/q mean/std        : H %.6f / %.6f, q1 %.6f / %.6f, q2 %.6f / %.6f m\n', ...
    mc.free_mean(1), mc.free_std(1), mc.free_mean(2), mc.free_std(2), mc.free_mean(3), mc.free_std(3));
fprintf('  Scalar d mean/std        : %.6f / %.6f m\n', mc.scalar_d_mean, mc.scalar_d_std);
end

%% ------------------------------------------------------------------------
function plot_identification_results(data, target, id_result, opts) %#ok<INUSD>
labels = {'FL','FR','RL','RR'};
figure('Name','Identification: tyre vertical-load fit');
tiledlayout(2,2);
for i = 1:4
    nexttile;
    plot(data.t, target.Fz(i,:), 'k', 'LineWidth', 1.3); hold on; grid on;
    leg = {'target'};
    if isfield(id_result, 'free') && ~isempty(id_result.free)
        plot(data.t, id_result.free.prediction.Fz(i,:), '--', 'LineWidth', 1.1);
        leg{end+1} = 'free [H,q1,q2]'; %#ok<AGROW>
    end
    if isfield(id_result, 'scalar_d') && ~isempty(id_result.scalar_d)
        plot(data.t, id_result.scalar_d.prediction.Fz(i,:), ':', 'LineWidth', 1.4);
        leg{end+1} = 'scalar d'; %#ok<AGROW>
    end
    xlabel('t [s]'); ylabel('F_z [N]'); title(labels{i});
    legend(leg, 'Location','best');
end

figure('Name','Identification: instantaneous q diagnostic');
plot(data.t, id_result.diagnostic.q1_inst, 'LineWidth', 1.1); hold on; grid on;
plot(data.t, id_result.diagnostic.q2_inst, 'LineWidth', 1.1);
yline(id_result.diagnostic.q1_ls, '--', 'q1 LS');
yline(id_result.diagnostic.q2_ls, '--', 'q2 LS');
xlabel('t [s]'); ylabel('effective q [m]');
legend('q1 instantaneous','q2 instantaneous','q1 LS','q2 LS','Location','best');
title('Closed-form diagnostic effective front/rear load-transfer heights');
end


%% ------------------------------------------------------------------------

function plot_command_vs_actual_controls(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, veh)
% Plot raw command histories together with the actual controls used in the
% vehicle dynamics. The only intentional command-vs-actual difference should
% be drive torque when the motor power/torque cap is active.
has_dae = ~isempty(sim_ode15i_dae);

figure('Name','Simple time simulation: command vs actual controls');
tiledlayout(4,1);

nexttile;
plot(sim_ode15s.t, sim_ode15s.u_cmd_phys(1,:), 'k', 'LineWidth', 1.4); hold on; grid on;
plot(sim_ode15s.t, sim_ode15s.u_phys(1,:), 'LineWidth', 1.1);
plot(sim_fixed.t, sim_fixed.u_phys(1,:), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.u_phys(1,:), ':', 'LineWidth', 1.4); end
plot(sim_ode15s.t, sim_ode15s.Tt_upper_bound, '-.', 'LineWidth', 1.0);
ylabel('T_t [Nm]');
title('Drive torque: effective command vs actual applied to dynamics');
if has_dae
legend('effective command','ode15s actual','RK4 actual','ode15i actual','min(Td max, Pmax/omega)', 'Location','best');
else
legend('effective command','ode15s actual','RK4 actual','min(Td max, Pmax/omega)', 'Location','best');
end

nexttile;
plot(ctrl.t, ctrl.Tb_cmd, 'k', 'LineWidth', 1.4); hold on; grid on;
plot(sim_ode15s.t, sim_ode15s.u_phys(2,:), 'LineWidth', 1.1);
plot(sim_fixed.t, sim_fixed.u_phys(2,:), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.u_phys(2,:), ':', 'LineWidth', 1.4); end
ylabel('T_b [Nm]');
title('Brake torque: command vs actual applied to dynamics');

nexttile;
plot(ctrl.t, rad2deg(ctrl.delta_cmd), 'k', 'LineWidth', 1.4); hold on; grid on;
plot(sim_ode15s.t, rad2deg(sim_ode15s.u_phys(3,:)), 'LineWidth', 1.1);
plot(sim_fixed.t, rad2deg(sim_fixed.u_phys(3,:)), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.u_phys(3,:)), ':', 'LineWidth', 1.4); end
ylabel('\delta [deg]');
title('Steering: command vs actual applied to dynamics');

nexttile;
plot(sim_ode15s.t, sim_ode15s.power_rear/veh.power_motor_max, 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.power_rear/veh.power_motor_max, '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.power_rear/veh.power_motor_max, ':', 'LineWidth', 1.4); end
yline(1.0, 'k-.', 'P_{max}');
xlabel('t [s]'); ylabel('T_t \omega_{rear}/P_{max} [-]');
title('Rear drive power usage after actual torque limiting');

figure('Name','Drive torque limiter diagnostics');
hold on; grid on;

plot(sim_ode15s.t, sim_ode15s.Td_max, 'LineWidth', 1.2);
plot(sim_ode15s.t, sim_ode15s.Tt_power_max, 'LineWidth', 1.2);
plot(sim_ode15s.t, sim_ode15s.Tt_upper_bound, 'k--', 'LineWidth', 1.4);
plot(sim_ode15s.t, sim_ode15s.u_phys(1,:), 'LineWidth', 1.2);

xlabel('t [s]');
ylabel('Torque [Nm]');
legend('Td max','Pmax / omega','min(Td max, Pmax / omega)','actual Tt', ...
       'Location','best');
title('Drive torque limiter components');
end


%% ------------------------------------------------------------------------
function print_presteer_diagnostic(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, opts, veh)
%PRINT_PRESTEER_DIAGNOSTIC Check the target-speed / no-torque / no-steering phases.
%
% This is diagnostic-only. It does not change commands, controls, dynamics,
% solvers, tyre-loads, or initial conditions.

if ~isfield(ctrl, 't_release') || ~isfield(ctrl, 't_steer_start')
    fprintf('\n=== Target-speed / pre-steering diagnostic skipped ===\n');
    fprintf('The selected profile does not define ctrl.t_release / ctrl.t_steer_start.\n');
    fprintf('Use step_steer, sine_steer, or linear_steer for this diagnostic.\n');
    return;
end

if isfield(ctrl, 'U_target')
    U_target = ctrl.U_target;
else
    U_target = opts.U_target;
end

fprintf('\n=== Target-speed / pre-steering diagnostic ===\n');
fprintf('Target speed        : %.3f km/h\n', 3.6*U_target);
fprintf('Torque release time : %.6f s\n', ctrl.t_release);
fprintf('Steering start time : %.6f s\n', ctrl.t_steer_start);
fprintf('Torque-off delay    : %.6f s\n', ctrl.t_steer_start - ctrl.t_release);
fprintf('Speed tolerance     : %.3f km/h\n', opts.diag_speed_tol_kmh);
fprintf('|ux_dot| tolerance  : %.6f m/s^2\n', opts.diag_uxdot_tol);
fprintf('|ax| tolerance      : %.6f m/s^2\n', opts.diag_ax_tol);

print_single_presteer_diagnostic('ode15s reduced ODE', sim_ode15s, ctrl, opts, U_target);
print_single_presteer_diagnostic('fixed RK4 reduced ODE', sim_fixed, ctrl, opts, U_target);
if ~isempty(sim_ode15i_dae)
    print_single_presteer_diagnostic('ode15i true DAE', sim_ode15i_dae, ctrl, opts, U_target);
end

if opts.do_plot
    plot_presteer_diagnostic(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, opts, veh, U_target);
end

fprintf('=== End target-speed / pre-steering diagnostic ===\n\n');
end

%% ------------------------------------------------------------------------
function print_single_presteer_diagnostic(label, sim, ctrl, opts, U_target)
% Diagnostic convention:
%   1. "Before torque-off delay" is checked at the last output sample strictly
%      before ctrl.t_release, because at ctrl.t_release the code intentionally
%      sets drive torque to zero.
%   2. "During torque-off delay" is checked on ctrl.t_release <= t < ctrl.t_steer_start.
%   3. "At steering start" is checked at the first output sample at/after ctrl.t_steer_start.

fprintf('\n--- %s ---\n', label);

t = sim.t(:).';
if numel(t) < 2
    fprintf('Not enough output samples for diagnostic. [FAIL]\n');
    return;
end

dt_nom = median(diff(t));
k_pre = find(t <= ctrl.t_release - 0.5*dt_nom, 1, 'last');
if isempty(k_pre)
    k_pre = find(t < ctrl.t_release, 1, 'last');
end
if isempty(k_pre)
    k_pre = 1;
end

ux_kmh = 3.6*sim.x_phys(1,k_pre);
speed_err_kmh = ux_kmh - 3.6*U_target;
ax_now = sim.acc(1,k_pre);
uxdot_now = sim.acc(3,k_pre);
Tt_pre = sim.u_phys(1,k_pre);
Tb_pre = sim.u_phys(2,k_pre);
delta_pre_deg = rad2deg(sim.u_phys(3,k_pre));

speed_ok = abs(speed_err_kmh) <= opts.diag_speed_tol_kmh;
uxdot_ok = abs(uxdot_now) <= opts.diag_uxdot_tol;
ax_ok = abs(ax_now) <= opts.diag_ax_tol;
accel_ok = uxdot_ok || ax_ok;
pre_steer_zero_ok = abs(delta_pre_deg) <= opts.diag_steer_tol_deg;
pre_brake_zero_ok = abs(Tb_pre) <= opts.diag_torque_tol;
pre_ok = speed_ok && accel_ok && pre_steer_zero_ok && pre_brake_zero_ok;

fprintf('Last pre-release sample: t = %.6f s\n', t(k_pre));
fprintf('  ux                  = %.6f km/h, error from target = %.6f km/h [%s]\n', ...
    ux_kmh, speed_err_kmh, passfail(speed_ok));
fprintf('  ux_dot              = %.9f m/s^2 [%s]\n', uxdot_now, passfail(uxdot_ok));
fprintf('  ax                  = %.9f m/s^2 [%s]\n', ax_now, passfail(ax_ok));
fprintf('  acceleration check  = |ux_dot| small OR |ax| small [%s]\n', passfail(accel_ok));
fprintf('  Tt actual           = %.9f Nm\n', Tt_pre);
fprintf('  Tb actual           = %.9f Nm [%s]\n', Tb_pre, passfail(pre_brake_zero_ok));
fprintf('  steering actual     = %.9f deg [%s]\n', delta_pre_deg, passfail(pre_steer_zero_ok));

delay_mask = (t >= ctrl.t_release) & (t < ctrl.t_steer_start);
if any(delay_mask)
    max_Tt_delay = max(abs(sim.u_phys(1,delay_mask)));
    max_Tb_delay = max(abs(sim.u_phys(2,delay_mask)));
    max_delta_delay_deg = max(abs(rad2deg(sim.u_phys(3,delay_mask))));
    speed_delay_start_kmh = 3.6*sim.x_phys(1,find(delay_mask,1,'first'));
    speed_delay_end_kmh = 3.6*sim.x_phys(1,find(delay_mask,1,'last'));
else
    max_Tt_delay = NaN;
    max_Tb_delay = NaN;
    max_delta_delay_deg = NaN;
    speed_delay_start_kmh = NaN;
    speed_delay_end_kmh = NaN;
end

drive_zero_delay_ok = isfinite(max_Tt_delay) && max_Tt_delay <= opts.diag_torque_tol;
brake_zero_delay_ok = isfinite(max_Tb_delay) && max_Tb_delay <= opts.diag_torque_tol;
steer_zero_delay_ok = isfinite(max_delta_delay_deg) && max_delta_delay_deg <= opts.diag_steer_tol_deg;
delay_ok = drive_zero_delay_ok && brake_zero_delay_ok && steer_zero_delay_ok;

fprintf('Torque-off delay samples: %d\n', nnz(delay_mask));
fprintf('  max |Tt| in [t_release, t_steer_start)       = %.9e Nm [%s]\n', ...
    max_Tt_delay, passfail(drive_zero_delay_ok));
fprintf('  max |Tb| in [t_release, t_steer_start)       = %.9e Nm [%s]\n', ...
    max_Tb_delay, passfail(brake_zero_delay_ok));
fprintf('  max |steering| in [t_release, t_steer_start) = %.9e deg [%s]\n', ...
    max_delta_delay_deg, passfail(steer_zero_delay_ok));
fprintf('  ux at start/end of torque-off delay          = %.6f / %.6f km/h\n', ...
    speed_delay_start_kmh, speed_delay_end_kmh);

k_start = find(t >= ctrl.t_steer_start, 1, 'first');
if isempty(k_start)
    steering_start_ok = false;
    fprintf('First sample at/after steering start: not available because integration ended early. [FAIL]\n');
else
    Tt_start = sim.u_phys(1,k_start);
    Tb_start = sim.u_phys(2,k_start);
    ux_start_kmh = 3.6*sim.x_phys(1,k_start);
    speed_start_ok = abs(ux_start_kmh - 3.6*U_target) <= opts.diag_speed_tol_kmh;
    drive_zero_start_ok = abs(Tt_start) <= opts.diag_torque_tol;
    brake_zero_start_ok = abs(Tb_start) <= opts.diag_torque_tol;
    steering_start_ok = drive_zero_start_ok && brake_zero_start_ok;

    fprintf('First sample at/after steering start: t = %.6f s\n', t(k_start));
    fprintf('  ux at steering start = %.6f km/h, error = %.6f km/h [%s]\n', ...
        ux_start_kmh, ux_start_kmh - 3.6*U_target, passfail(speed_start_ok));
    fprintf('  Tt at steering start = %.9e Nm [%s]\n', Tt_start, passfail(drive_zero_start_ok));
    fprintf('  Tb at steering start = %.9e Nm [%s]\n', Tb_start, passfail(brake_zero_start_ok));
end

fprintf('Overall requirement before torque-off delay: speed near target AND (ux_dot or ax small), no brake, no steering [%s]\n', ...
    passfail(pre_ok));
fprintf('Overall requirement during torque-off delay: no drive torque, no brake, no steering [%s]\n', ...
    passfail(delay_ok));
fprintf('Overall requirement at steering start: no drive torque and no brake torque [%s]\n', ...
    passfail(steering_start_ok));
end

%% ------------------------------------------------------------------------
function plot_presteer_diagnostic(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, opts, veh, U_target) %#ok<INUSD>
has_dae = ~isempty(sim_ode15i_dae);

figure('Name','Target-speed / pre-steering diagnostic');
tiledlayout(4,1);

nexttile;
plot(sim_ode15s.t, 3.6*sim_ode15s.x_phys(1,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, 3.6*sim_fixed.x_phys(1,:), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, 3.6*sim_ode15i_dae.x_phys(1,:), ':', 'LineWidth', 1.4); end
yline(3.6*U_target, 'k--', 'target');
xline(ctrl.t_release, 'k-.', 'release');
xline(ctrl.t_steer_start, 'k:', 'steer start');
ylabel('u_x [km/h]');
title('Target-speed preparation');
if has_dae
    legend('ode15s','RK4','ode15i','Location','best');
else
    legend('ode15s','RK4','Location','best');
end

nexttile;
plot(sim_ode15s.t, sim_ode15s.acc(3,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.acc(3,:), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.acc(3,:), ':', 'LineWidth', 1.4); end
yline(opts.diag_uxdot_tol, 'k--', '+tol');
yline(-opts.diag_uxdot_tol, 'k--', '-tol');
xline(ctrl.t_release, 'k-.', 'release');
xline(ctrl.t_steer_start, 'k:', 'steer start');
ylabel('u_x dot [m/s^2]');
title('Longitudinal speed derivative diagnostic');

nexttile;
plot(sim_ode15s.t, sim_ode15s.acc(1,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.acc(1,:), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.acc(1,:), ':', 'LineWidth', 1.4); end
yline(opts.diag_ax_tol, 'k--', '+tol');
yline(-opts.diag_ax_tol, 'k--', '-tol');
xline(ctrl.t_release, 'k-.', 'release');
xline(ctrl.t_steer_start, 'k:', 'steer start');
ylabel('a_x [m/s^2]');
title('Body-frame longitudinal acceleration diagnostic');

nexttile;
plot(sim_ode15s.t, sim_ode15s.u_phys(1,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.u_phys(1,:), '--', 'LineWidth', 1.0);
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.u_phys(1,:), ':', 'LineWidth', 1.4); end
plot(sim_ode15s.t, rad2deg(sim_ode15s.u_phys(3,:)), 'LineWidth', 1.0);
xline(ctrl.t_release, 'k-.', 'release');
xline(ctrl.t_steer_start, 'k:', 'steer start');
xlabel('t [s]');
ylabel('T_t [Nm] and \delta [deg]');
title('Drive torque release and steering start');
end

%% ------------------------------------------------------------------------
function txt = passfail(flag)
if flag
    txt = 'PASS';
else
    txt = 'FAIL';
end
end


%% ------------------------------------------------------------------------
function plot_simple_results(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, veh)
has_dae = ~isempty(sim_ode15i_dae);

figure('Name','Simple time simulation: speed comparison');
plot(sim_ode15s.t, 3.6*sim_ode15s.x_phys(1,:), 'LineWidth', 1.2); hold on; grid on;
plot(sim_fixed.t, 3.6*sim_fixed.x_phys(1,:), '--', 'LineWidth', 1.0);
if has_dae
plot(sim_ode15i_dae.t, 3.6*sim_ode15i_dae.x_phys(1,:), ':', 'LineWidth', 1.5);
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE');
end
xlabel('t [s]'); ylabel('u_x [km/h]'); title('Longitudinal speed');

% figure('Name','Simple time simulation: selected states comparison');
% tiledlayout(3,1);
% nexttile;
% plot(sim_ode15s.t, 3.6*sim_ode15s.x_phys(1,:), 'LineWidth', 1.1); hold on; grid on;
% plot(sim_fixed.t, 3.6*sim_fixed.x_phys(1,:), '--');
% if has_dae, plot(sim_ode15i_dae.t, 3.6*sim_ode15i_dae.x_phys(1,:), ':', 'LineWidth', 1.4); end
% xlabel('t [s]'); ylabel('u_x [km/h]'); title('Speed');
% nexttile;
% plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(3,:)), 'LineWidth', 1.1); hold on; grid on;
% plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(3,:)), '--');
% if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(3,:)), ':', 'LineWidth', 1.4); end
% xlabel('t [s]'); ylabel('r [deg/s]'); title('Yaw rate');
% nexttile;
% plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(9,:)), 'LineWidth', 1.1); hold on; grid on;
% plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(9,:)), '--');
% if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(9,:)), ':', 'LineWidth', 1.4); end
% xlabel('t [s]'); ylabel('\xi [deg]'); title('Course angle');
% if has_dae
% legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
% else
% legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
% end

figure('Name','Simple time simulation: selected states comparison group 1');
tiledlayout(3,1);
nexttile;
plot(sim_ode15s.t, 3.6*sim_ode15s.x_phys(1,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, 3.6*sim_fixed.x_phys(1,:), '--');
if has_dae, plot(sim_ode15i_dae.t, 3.6*sim_ode15i_dae.x_phys(1,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('u_x [km/h]'); title('ux');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(3,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(3,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(3,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('r [deg/s]'); title('Yaw rate');
nexttile;
plot(sim_ode15s.t, 3.6*sim_ode15s.x_phys(2,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, 3.6*sim_fixed.x_phys(2,:), '--');
if has_dae, plot(sim_ode15i_dae.t, 3.6*sim_ode15i_dae.x_phys(2,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('u_y [km/h]'); title('uy');
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end

figure('Name','Simple time simulation: selected states comparison group 2');
tiledlayout(4,1);
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(4,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(4,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(4,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('phi [deg]'); title('phi');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(5,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(5,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(5,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('phi dot [deg/s]'); title('phi dot');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(6,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(6,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(6,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('theta [deg]'); title('theta');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(7,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(7,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(7,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('theta dot [deg/s]'); title('theta dot');
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end

figure('Name','Simple time simulation: selected states comparison group 3');
tiledlayout(4,1);
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(10,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(10,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(10,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('omega FL [deg/s]'); title('omega FL');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(11,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(11,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(11,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('omega FR [deg/s]'); title('omega FR');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(12,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(12,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(12,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('omega RL [deg/s]'); title('omega RL');
nexttile;
plot(sim_ode15s.t, rad2deg(sim_ode15s.x_phys(13,:)), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, rad2deg(sim_fixed.x_phys(13,:)), '--');
if has_dae, plot(sim_ode15i_dae.t, rad2deg(sim_ode15i_dae.x_phys(13,:)), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('omega RR [deg/s]'); title('omega RR');
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end






figure('Name','Simple time simulation: selected states comparison group 4');
tiledlayout(4,1);
nexttile;
plot(sim_ode15s.t, sim_ode15s.acc(1,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.acc(1,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.acc(1,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('ax [ms2]'); title('ax');
nexttile;
plot(sim_ode15s.t, sim_ode15s.acc(2,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.acc(2,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.acc(2,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('ay [ms2]'); title('ay');
nexttile;
plot(sim_ode15s.t, sim_ode15s.acc(3,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.acc(3,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.acc(3,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('ux dot [ms2]'); title('ux dot');
nexttile;
plot(sim_ode15s.t, sim_ode15s.acc(4,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.acc(4,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.acc(4,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('uy dot [ms2]'); title('uy dot');
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end







% Old command-only plot, intentionally replaced by command-vs-actual plot.
% figure('Name','Simple time simulation: controls');
% plot(ctrl.t, ctrl.Tt_cmd, 'LineWidth', 1.2); hold on; grid on;
% yyaxis right; plot(ctrl.t, rad2deg(ctrl.delta_cmd), 'LineWidth', 1.2);
% xlabel('t [s]'); yyaxis left; ylabel('T_t command [Nm]'); yyaxis right; ylabel('\delta command [deg]');
% title('Arbitrary command histories');
plot_command_vs_actual_controls(sim_ode15s, sim_fixed, sim_ode15i_dae, ctrl, veh);

figure('Name','Simple time simulation: tyre loads comparison');
tiledlayout(2,2);
labels = {'FL','FR','RL','RR'};
for i = 1:4
nexttile;
plot(sim_ode15s.t, sim_ode15s.z_phys(i,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.z_phys(i,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.z_phys(i,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('F_z [N]'); title(labels{i});
end
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end

figure('Name','Simple time simulation: tyre Fx comparison');
tiledlayout(2,2);
labels = {'FL','FR','RL','RR'};
for i = 1:4
nexttile;
plot(sim_ode15s.t, sim_ode15s.tyre(i,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.tyre(i,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.tyre(i,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('F_x [N]'); title(labels{i});
end
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end

figure('Name','Simple time simulation: tyre Fy comparison');
tiledlayout(2,2);
labels = {'FL','FR','RL','RR'};
for i = (1:4) + 4
nexttile;
plot(sim_ode15s.t, sim_ode15s.tyre(i,:), 'LineWidth', 1.1); hold on; grid on;
plot(sim_fixed.t, sim_fixed.tyre(i,:), '--');
if has_dae, plot(sim_ode15i_dae.t, sim_ode15i_dae.tyre(i,:), ':', 'LineWidth', 1.4); end
xlabel('t [s]'); ylabel('F_y [N]'); title(labels{i-4});
end
if has_dae
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE', 'Location','best');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE', 'Location','best');
end

figure('Name','Simple time simulation: load residual comparison');
semilogy(sim_ode15s.t, max(abs(sim_ode15s.h_load),[],1) + eps, 'LineWidth', 1.2); hold on; grid on;
semilogy(sim_fixed.t, max(abs(sim_fixed.h_load),[],1) + eps, '--', 'LineWidth', 1.0);
if has_dae
semilogy(sim_ode15i_dae.t, max(abs(sim_ode15i_dae.h_load),[],1) + eps, ':', 'LineWidth', 1.5);
legend('ode15s reduced ODE','fixed RK4 reduced ODE','ode15i true DAE');
else
legend('ode15s reduced ODE','fixed RK4 reduced ODE');
end
xlabel('t [s]'); ylabel('max |h_{load}| [-]'); title('Tyre-load algebraic residual');

if has_dae
% Compare the two reduced-ODE results to the DAE result at common DAE times.
tx = sim_ode15i_dae.t;
ux_ode = interp1(sim_ode15s.t, sim_ode15s.x_phys(1,:), tx, 'linear', 'extrap');
ux_rk4 = interp1(sim_fixed.t, sim_fixed.x_phys(1,:), tx, 'linear', 'extrap');
ux_dae = sim_ode15i_dae.x_phys(1,:);
figure('Name','Simple time simulation: speed difference to DAE');
plot(tx, 3.6*(ux_ode - ux_dae), 'LineWidth', 1.2); hold on; grid on;
plot(tx, 3.6*(ux_rk4 - ux_dae), '--', 'LineWidth', 1.0);
xlabel('t [s]'); ylabel('\Delta u_x [km/h]');
legend('ode15s reduced ODE - ode15i DAE','fixed RK4 reduced ODE - ode15i DAE');
title('Speed difference relative to true DAE solution');
end

debug = 0;

end