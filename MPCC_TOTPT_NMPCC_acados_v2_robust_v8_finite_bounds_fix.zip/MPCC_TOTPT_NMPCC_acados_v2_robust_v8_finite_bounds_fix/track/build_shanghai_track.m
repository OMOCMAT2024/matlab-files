function track = build_shanghai_track(cfg, veh)
%BUILD_SHANGHAI_TRACK Build a periodic distance-parameterized Shanghai track.
% Uses the exact source MAT files supplied with the direct OCP package.
D = cfg.track.data_dir;
req = {'C_true_project.mat','S_all_points.mat','nl.mat','nr.mat', ...
       'OmegaB.mat','Theta.mat','P_L.mat','P_R.mat'};
for i=1:numel(req)
    if ~isfile(fullfile(D,req{i}))
        error('MPCC:MissingTrackFile','Missing track file: %s',fullfile(D,req{i}));
    end
end
load(fullfile(D,'C_true_project.mat'),'C_true_project');
load(fullfile(D,'S_all_points.mat'),'S_all_points');
load(fullfile(D,'nl.mat'),'nl');
load(fullfile(D,'nr.mat'),'nr');
load(fullfile(D,'OmegaB.mat'),'OmegaB');
load(fullfile(D,'Theta.mat'),'Theta');
load(fullfile(D,'P_L.mat'),'P_L');
load(fullfile(D,'P_R.mat'),'P_R');

sraw = S_all_points(:);
if any(~isfinite(sraw)) || any(diff(sraw) <= 0)
    error('MPCC:BadTrackArcLength','S_all_points must be finite and strictly increasing.');
end
curv = OmegaB(:,3);
if cfg.track.apply_curvature_patch
    ia = cfg.track.curvature_patch_first;
    ib = cfg.track.curvature_patch_last;
    if ia < 1 || ib > numel(curv) || ia > ib
        error('MPCC:BadCurvaturePatch','Curvature patch indices are outside the supplied track data.');
    end
    curv(ia:ib) = cfg.track.curvature_patch_scale .* curv(ia:ib);
end

% Mirror my_oc.m exactly: the raw Shanghai data repeat the first centerline
% point as the last point, and the direct-OCP package removes that duplicate
% before calling calc_track_interp(). Apply the same removal to every raw
% signal before the MPCC interpolation.
nraw = numel(sraw);
if size(C_true_project,1)~=nraw || numel(nl)~=nraw || numel(nr)~=nraw || ...
        size(OmegaB,1)~=nraw || numel(Theta)~=nraw || ...
        size(P_L,1)~=nraw || size(P_R,1)~=nraw
    error('MPCC:TrackArrayLength','Supplied Shanghai track arrays do not share one raw mesh.');
end
C_true_project(end,:)=[];
nl(end,:)=[]; nr(end,:)=[]; OmegaB(end,:)=[]; Theta(end,:)=[];
P_L(end,:)=[]; P_R(end,:)=[]; sraw(end,:)=[]; curv(end,:)=[];

L = sraw(end);
s = linspace(0,L,cfg.track.num_points).';
interp = @(v) interp1(sraw,double(v),s,'linear');
track.s = s;
track.L = L;
track.x = interp(C_true_project(:,1));
track.y = interp(C_true_project(:,2));
track.z = interp(C_true_project(:,3));
track.wr = interp(-nr(:,1));            % positive distance from centerline to right boundary
track.wl = interp( nl(:,1));            % positive distance from centerline to left boundary
track.Theta = interp(Theta(:));
track.curvature = interp(curv);
track.P_L = [interp(P_L(:,1)), interp(P_L(:,2)), interp(P_L(:,3))];
track.P_R = [interp(P_R(:,1)), interp(P_R(:,2)), interp(P_R(:,3))];

% Enforce exact periodic endpoint values for functions embedded in acados.
periodic_fields = {'x','y','z','wr','wl','Theta','curvature'};
for i=1:numel(periodic_fields)
    f=periodic_fields{i};
    if strcmp(f,'Theta')
        % Preserve the unwrapped heading trend but force the expected 2*pi
        % equivalent endpoint closest to the measured last value.
        theta0 = track.Theta(1);
        thetaEnd = track.Theta(end);
        k = round((thetaEnd-theta0)/(2*pi));
        track.Theta(end) = theta0 + 2*pi*k;
    else
        track.(f)(end) = track.(f)(1);
    end
end
track.P_L(end,:) = track.P_L(1,:);
track.P_R(end,:) = track.P_R(1,:);

% Aerodynamic/KERS schedules are intentionally not stored in the MPCC track.
% The controller wrapper supplies constant veh.Cd_nominal and zero KERS flags.

if any(track.wl <= veh.wt/2+veh.ws) || any(track.wr <= veh.wt/2+veh.ws)
    error('MPCC:TrackTooNarrow','Track width is smaller than the vehicle half-width plus tyre-width margin.');
end
end
