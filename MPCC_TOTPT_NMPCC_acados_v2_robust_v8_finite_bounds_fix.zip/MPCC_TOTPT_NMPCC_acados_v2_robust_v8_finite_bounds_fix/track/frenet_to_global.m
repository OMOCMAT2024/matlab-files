function [X,Y] = frenet_to_global(track,s_abs,n)
%FRENET_TO_GLOBAL Convert direct-OCP (s,n) coordinates to global planar XY.
sw = mod(s_abs,track.L);
xc = interp1(track.s,track.x,sw,'linear');
yc = interp1(track.s,track.y,sw,'linear');
th = interp1(track.s,unwrap(track.Theta),sw,'linear');
X = xc - n.*sin(th);
Y = yc + n.*cos(th);
end
