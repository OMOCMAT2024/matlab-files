function tf = make_casadi_track_functions(track, suffix)
%MAKE_CASADI_TRACK_FUNCTIONS Periodic piecewise-linear CasADi track maps.
import casadi.*
if nargin < 2, suffix = 'totpt_v2'; end
s = track.s(:);
L = track.L;
spad = [s(1:end-1)-L; s; s(2:end)+L];
mk = @(name,v) interpolant([name '_' suffix],'linear',{spad.'}, ...
                           [v(1:end-1); v; v(2:end)].');
tf.kappa = mk('kappa',track.curvature(:));
tf.wl = mk('wl',track.wl(:));
tf.wr = mk('wr',track.wr(:));
tf.x = mk('track_x',track.x(:));
tf.y = mk('track_y',track.y(:));
tf.Theta = mk('track_theta',track.Theta(:));
tf.L = L;
tf.domain = [-L, 2*L];
end
