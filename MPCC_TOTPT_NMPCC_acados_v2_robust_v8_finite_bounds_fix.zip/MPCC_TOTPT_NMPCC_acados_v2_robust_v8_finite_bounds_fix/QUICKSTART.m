%% QUICKSTART - robust nonlinear TOTPT/acados MPCC v2
startup_mpcc_package

%% 1) Non-compiling model/track/initialization audit
report = run_preflight(); %#ok<NASGU>

%% 2) First real acados code-generation + 0.5 s closed-loop test
result_short = run_short_smoke_test(); %#ok<NASGU>

%% 3) Full closed-loop run
% result = run_mpcc_totpt_nmpcc();

%% Optional: strict original drive/brake complementarity equality
% cfg = mpcc_default_config();
% cfg.constraints.strict_direct_oc = true;
% result_strict = run_mpcc_totpt_nmpcc(cfg);
