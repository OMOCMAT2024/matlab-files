function result = run_all_checks()
%RUN_ALL_CHECKS Run preflight and then compile/execute the short closed-loop test.
run_package_preflight();
result = run_short_smoke_test();
fprintf('PASS: nonlinear acados NMPCC short closed-loop smoke test completed.\n');
end
