function report = run_package_preflight()
%RUN_PACKAGE_PREFLIGHT Symbolic/model/track/scaling checks before code generation.
startup_mpcc_package();
cfg = mpcc_default_config();
check_totpt_nmpcc_requirements();
validate_mpcc_config(cfg);
base = build_direct_oc_base_functions(cfg);
track = build_shanghai_track(cfg,base.veh);
dyn = build_nmpcc_dae_model(cfg,base,track);
[x0,z0,warm] = make_initial_state(cfg,dyn,track);

assert(base.nx_vehicle == 13,'Expected 13 direct-OCP vehicle states.');
assert(base.nu_actuator == 3,'Expected 3 direct-OCP actuator variables.');
assert(base.nz == 4,'Expected 4 lifted tyre-load variables.');
assert(dyn.nx == 17 && dyn.nu == 3 && dyn.nz == 4,'Unexpected NMPCC dimensions.');
assert(numel(track.s) == cfg.track.num_points,'Unexpected Shanghai track point count.');
assert(all(diff(track.s) > 0),'Track progress grid must be strictly increasing.');
assert(track.L > 5000 && track.L < 6000,'Shanghai track length sanity check failed.');
assert(all(track.wl > 0) && all(track.wr > 0),'Track widths must be positive.');
assert(all(isfinite(base.x_s)) && all(base.x_s > 0),'State scales must be finite and positive.');
assert(all(isfinite(base.u_s)) && all(base.u_s > 0),'Actuator scales must be finite and positive.');
assert(all(isfinite(base.z_s)) && all(base.z_s > 0),'Load scales must be finite and positive.');
assert(all(isfinite(base.rate_scale)) && all(base.rate_scale > 0),'Rate scales must be finite and positive.');

u0=zeros(3,1); p0=0;
hload=full(dyn.h_load(x0,u0,z0,p0));
assert(norm(hload,inf) <= max(1e-8,100*cfg.plant.load_newton_tol),'Initial lifted-load residual is too large.');
h0=full(dyn.path(x0,u0,z0,p0));
assert(numel(h0)==dyn.nh,'Path-constraint dimension mismatch.');

% Label-based checks avoid brittle hard-coded indices when strict mode changes.
for i=1:numel(dyn.path_labels)
    lab=dyn.path_labels{i}; val=h0(i);
    if strcmp(lab,'rear_power_limit') || startsWith(lab,'slip_') || startsWith(lab,'track_')
        assert(val <= 2*cfg.constraints.original_tol,'Initial constraint %s is infeasible: %.3e',lab,val);
    elseif strcmp(lab,'progress_rate_n')
        assert(val >= -1e-8,'Initial progress rate is negative.');
    elseif strcmp(lab,'frenet_denominator')
        assert(val >= cfg.constraints.min_curvilinear_denominator,'Initial Frenet denominator is unsafe.');
    elseif strcmp(lab,'drive_brake_product')
        assert(abs(val)<=2*cfg.constraints.original_tol,'Strict complementarity equality is infeasible initially.');
    end
end
assert(all(z0 >= base.z_min-1e-8) && all(z0 <= base.z_max+1e-8),'Initial tyre loads violate bounds.');

% Verify MPCC really disables DRS/KERS at several positions.
for sig=[0,0.25,0.7]
    xt=x0; xt(dyn.idx.sigma)=sig;
    pv=full(dyn.pv(xt,0));
    assert(abs(pv(2)-base.veh.Cd_nominal)<1e-12,'Cd must be constant nominal in MPCC.');
    assert(all(abs(pv(3:4))<1e-12),'KERS flags must be identically zero in MPCC.');
end

% Local frame invariance.
xA=x0; xA(dyn.idx.sigma)=0.25; pA=0.10;
ds=dyn.s_scale*xA(dyn.idx.sigma);
xB=xA; xB(dyn.idx.sigma)=0; pB=pA+ds/track.L;
pvA=full(dyn.pv(xA,pA)); pvB=full(dyn.pv(xB,pB));
assert(norm(pvA-pvB,inf)<1e-11,'Local progress anchor/reset is not invariant.');

% Fixed-step plant micro-step.
[x1,z1,info]=plant_step_rk4_newton(dyn,x0,u0,z0,p0,cfg.plant.fixed_dt,cfg.plant); %#ok<ASGLU>
assert(all(isfinite(x1)) && all(isfinite(z1)),'Plant preflight produced non-finite values.');
assert(info.max_load_residual <= max(1e-8,100*cfg.plant.load_newton_tol),'Plant load residual is too large.');

% Warm-start guess: finite, within rate bounds, algebraically projected.
guess=make_direct_oc_guess(cfg,dyn,track,warm,x0,z0,0);
assert(all(isfinite(guess.X(:))) && all(isfinite(guess.U(:))) && all(isfinite(guess.Z(:))),'Initial guess contains non-finite values.');
rlb=base.du_phys_min./base.rate_scale; rub=base.du_phys_max./base.rate_scale;
assert(all(all(guess.U >= rlb-1e-12)) && all(all(guess.U <= rub+1e-12)),'Warm-start actuator rates violate bounds.');
max_guess_load=0;
max_guess_power_residual=-inf;
for k=1:cfg.controller.N
    max_guess_load=max(max_guess_load,norm(full(dyn.h_load(guess.X(:,k),guess.U(:,k),guess.Z(:,k),0)),inf));
    hk=full(dyn.path(guess.X(:,k),guess.U(:,k),guess.Z(:,k),0));
    ip=find(strcmp(dyn.path_labels,'rear_power_limit'),1);
    max_guess_power_residual=max(max_guess_power_residual,hk(ip));
end
assert(max_guess_load <= 1e-6,'Warm-start lifted-load consistency is too poor: %.3e',max_guess_load);
assert(max_guess_power_residual <= 2*cfg.constraints.original_tol, ...
    'Projected direct-OCP guess still violates rear power limit: %.3e',max_guess_power_residual);

% Full shooting-node feasibility audit against the EXACT bounds sent to acados.
% This catches cross-version bound/sign mistakes that a label-specific check can
% miss, including accidental conversion of a one-sided constraint to h >= 0.
bounds = make_nmpcc_constraint_bounds(cfg,base);
margin = base.veh.wt/2 + base.veh.ws;
xmin = [base.x_min; -cfg.constraints.progress_backtrack_m/dyn.s_scale; base.u_min];
xmax = [base.x_max; cfg.constraints.progress_horizon_factor*base.veh.V_max* ...
    (cfg.controller.N*cfg.controller.Ts)/dyn.s_scale; base.u_max];
xmin(8) = max(xmin(8), min((-track.wr + margin)/base.veh.n_s));
xmax(8) = min(xmax(8), max(( track.wl - margin)/base.veh.n_s));

[direct_violation,direct_label] = audit_guess(guess,'direct-OCP',dyn,bounds,xmin,xmax,0);
flat_guess = make_flat_guess(cfg,dyn,track,x0,z0,0);
[flat_violation,flat_label] = audit_guess(flat_guess,'flat',dyn,bounds,xmin,xmax,0);
assert(direct_violation <= 1e-8,'Direct-OCP guess bound violation %.3e at %s.',direct_violation,direct_label);
assert(flat_violation <= 1e-8,'Flat guess bound violation %.3e at %s.',flat_violation,flat_label);

report=struct();
report.pass=true;
report.nx_controller=dyn.nx;
report.nu_controller=dyn.nu;
report.nz_controller=dyn.nz;
report.nh=dyn.nh;
report.track_length_m=track.L;
report.initial_load_residual_inf=norm(hload,inf);
report.warmstart_max_load_residual_inf=max_guess_load;
report.warmstart_max_power_residual=max_guess_power_residual;
report.plant_test_load_residual_inf=info.max_load_residual;
report.strict_direct_oc=cfg.constraints.strict_direct_oc;
report.direct_guess_max_bound_violation=direct_violation;
report.flat_guess_max_bound_violation=flat_violation;
fprintf('PASS: v2 symbolic preflight. nx=%d, nu=%d, nz=%d, nh=%d, L=%.3f m.\n',dyn.nx,dyn.nu,dyn.nz,dyn.nh,track.L);
fprintf('PASS: KERS/DRS disabled; initial load %.3e; warm-start load %.3e; plant load %.3e.\n', ...
    report.initial_load_residual_inf,report.warmstart_max_load_residual_inf,report.plant_test_load_residual_inf);
fprintf('PASS: exact acados-bound audit; direct guess %.3e, flat guess %.3e.\n', ...
    direct_violation,flat_violation);
end

function [vmax,label] = audit_guess(guess,name,dyn,bounds,xmin,xmax,p)
N=size(guess.U,2);
vmax=0; label=[name ' none'];
for k=1:N+1
    x=guess.X(:,k);
    [vmax,label]=take_max(vmax,label,max(xmin-x),sprintf('%s X lower stage %d',name,k-1));
    [vmax,label]=take_max(vmax,label,max(x-xmax),sprintf('%s X upper stage %d',name,k-1));
    if k<=N
        u=guess.U(:,k); z=guess.Z(:,k);
        h=full(dyn.path(x,u,z,p));
        [vmax,label]=take_max(vmax,label,max(bounds.lh-h),sprintf('%s h lower stage %d',name,k-1));
        [vmax,label]=take_max(vmax,label,max(h-bounds.uh),sprintf('%s h upper stage %d',name,k-1));
    else
        he=full(dyn.path_e(x,p));
        [vmax,label]=take_max(vmax,label,max(bounds.lh_e-he),sprintf('%s h_e lower stage %d',name,k-1));
        [vmax,label]=take_max(vmax,label,max(he-bounds.uh_e),sprintf('%s h_e upper stage %d',name,k-1));
    end
end
vmax=max(0,vmax);
end

function [vmax,label] = take_max(vmax,label,v,where)
if v>vmax
    vmax=v; label=where;
end
end
