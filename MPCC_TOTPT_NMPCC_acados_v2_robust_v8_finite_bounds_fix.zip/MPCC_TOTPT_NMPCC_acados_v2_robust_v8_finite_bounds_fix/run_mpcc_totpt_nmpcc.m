function result = run_mpcc_totpt_nmpcc(cfg)
%RUN_MPCC_TOTPT_NMPCC Full nonlinear MPCC closed-loop simulation.
% Runtime dependencies: MATLAB + CasADi + acados only.
if nargin<1 || isempty(cfg), cfg=mpcc_default_config(); end
startup_mpcc_package();
check_totpt_nmpcc_requirements();
validate_mpcc_config(cfg);

fprintf('\n=== TOTPT vehicle + Shanghai track nonlinear MPCC ===\n');
base=build_direct_oc_base_functions(cfg);
track=build_shanghai_track(cfg,base.veh);
dyn=build_nmpcc_dae_model(cfg,base,track);
[x,z,warm]=make_initial_state(cfg,dyn,track);
ctrl=create_acados_nmpcc_solver(cfg,dyn,track,x);
if strcmpi(cfg.plant.method,'acados_irk_dae')
    plant=create_acados_plant_solver(cfg,dyn);
else
    plant=[];
end

N=cfg.controller.N; Ts=cfg.controller.Ts;
s_anchor=0; cumulative_progress=0;
guess=make_direct_oc_guess(cfg,dyn,track,warm,x,z,s_anchor);

Kmax=cfg.simulation.max_steps;
Xlog=zeros(dyn.nx,Kmax+1); Zlog=zeros(dyn.nz,Kmax+1);
Uratelog=zeros(dyn.nu,Kmax); Alog=zeros(3,Kmax+1);
Slog=zeros(1,Kmax+1); Cumlog=zeros(1,Kmax+1); Tlog=zeros(1,Kmax+1);
solve_time=zeros(1,Kmax); status_log=zeros(1,Kmax); load_res=zeros(1,Kmax+1);
pathlog=nan(dyn.nh,Kmax); Xg=zeros(1,Kmax+1); Yg=zeros(1,Kmax+1);
Xlog(:,1)=x; Zlog(:,1)=z; Alog(:,1)=base.u_s.*x(dyn.idx.actuator);
Slog(1)=s_anchor; load_res(1)=norm(full(dyn.h_load(x,zeros(3,1),z,0)),inf);
[Xg(1),Yg(1)]=frenet_to_global(track,s_anchor,base.veh.n_s*x(8));

kfinal=0;
for k=1:Kmax
    p=s_anchor/track.L;
    set_initial_state_constraint(ctrl.solver,x);
    set_stage_parameter_all(ctrl.solver,p,N);
    set_nmpcc_initial_guess(ctrl.solver,guess);

    [status,solve_time(k)]=solve_acados_checked(ctrl.solver);
    if status~=0 && cfg.robustness.retry_from_direct_oc
        warning('MPCC:Retry','acados status %d at step %d. Retrying from fresh projected direct-OCP guess.',status,k);
        guess_retry=make_direct_oc_guess(cfg,dyn,track,warm,x,z,s_anchor);
        set_nmpcc_initial_guess(ctrl.solver,guess_retry);
        [status,solve_time(k)]=solve_acados_checked(ctrl.solver);
    end
    if status~=0 && cfg.robustness.retry_from_flat_guess
        warning('MPCC:RetryFlat','acados status %d at step %d. Retrying from conservative flat guess.',status,k);
        guess_retry=make_flat_guess(cfg,dyn,track,x,z,s_anchor);
        set_nmpcc_initial_guess(ctrl.solver,guess_retry);
        [status,solve_time(k)]=solve_acados_checked(ctrl.solver);
    end
    if status~=0
        print_acados_statistics(ctrl.solver);
        error('MPCC:ControllerFailure','acados NMPCC failed with status %d at closed-loop step %d.',status,k);
    end
    status_log(k)=status;
    u_rate=full(ctrl.solver.get('u',0));
    prev=get_nmpcc_solution(ctrl.solver,N,dyn.nx,dyn.nu,dyn.nz);
    pathlog(:,k)=full(dyn.path(x,u_rate,z,p));

    switch lower(cfg.plant.method)
        case 'rk4_newton'
            [xnext,znext,pinfo]=plant_step_rk4_newton(dyn,x,u_rate,z,p,Ts,cfg.plant); %#ok<NASGU>
        case 'acados_irk_dae'
            [xnext,znext,pinfo]=plant_step_acados_irk(plant,dyn,x,u_rate,z,p,cfg); %#ok<NASGU>
        otherwise
            error('MPCC:PlantMethod','Unknown cfg.plant.method: %s',cfg.plant.method);
    end

    ds=xnext(dyn.idx.sigma)*dyn.s_scale;
    if ~isfinite(ds)
        error('MPCC:BadProgress','Plant produced non-finite progress at step %d.',k);
    end
    cumulative_progress=cumulative_progress+ds;
    s_anchor=mod(s_anchor+ds,track.L);
    xnext(dyn.idx.sigma)=0; % exact local-progress frame reset

    % Shift the nonlinear solution into the new frame for the next SQP.
    if cfg.initialization.reuse_previous_nmpcc_solution
        guess=shift_nmpcc_solution(prev,xnext,znext,ds/dyn.s_scale,s_anchor/track.L,dyn,cfg);
    else
        guess=make_direct_oc_guess(cfg,dyn,track,warm,xnext,znext,s_anchor);
    end

    x=xnext; z=znext;
    Tlog(k+1)=k*Ts; Xlog(:,k+1)=x; Zlog(:,k+1)=z;
    Uratelog(:,k)=u_rate; Alog(:,k+1)=base.u_s.*x(dyn.idx.actuator);
    Slog(k+1)=s_anchor; Cumlog(k+1)=cumulative_progress;
    load_res(k+1)=norm(full(dyn.h_load(x,u_rate,z,s_anchor/track.L)),inf);
    [Xg(k+1),Yg(k+1)]=frenet_to_global(track,s_anchor,base.veh.n_s*x(8));
    kfinal=k;

    if mod(k,cfg.simulation.print_every)==0 || k==1
        fprintf('step %5d  t=%7.2f s  s=%7.1f m  lap=%5.2f  ux=%6.1f km/h  solve=%7.2f ms\n', ...
            k,k*Ts,s_anchor,cumulative_progress/track.L,3.6*base.veh.ux_s*x(1),1e3*solve_time(k));
    end
    if cumulative_progress >= cfg.simulation.stop_after_laps*track.L
        fprintf('Reached %.3f lap(s) at t=%.3f s.\n',cumulative_progress/track.L,k*Ts);
        break
    end
end

K=kfinal;
result.time=Tlog(1:K+1);
result.x_scaled=Xlog(:,1:K+1);
result.z_scaled=Zlog(:,1:K+1);
result.u_rate_normalized=Uratelog(:,1:K);
result.actuator_phys=Alog(:,1:K+1);
result.s=Slog(1:K+1);
result.cumulative_progress=Cumlog(1:K+1);
result.solve_time=solve_time(1:K);
result.status=status_log(1:K);
result.path_h=pathlog(:,1:K);
result.load_residual_inf=load_res(1:K+1);
result.X_global=Xg(1:K+1); result.Y_global=Yg(1:K+1);
result.x_vehicle_phys=base.x_s.*result.x_scaled(1:13,:);
result.z_phys=base.z_s.*result.z_scaled;
result.actuator_rate_phys=base.rate_scale.*result.u_rate_normalized;
result.track=track;
result.cfg=cfg;

if ~isfield(cfg.simulation,'make_plots') || cfg.simulation.make_plots
    plot_mpcc_results(result,track,base);
end
end
