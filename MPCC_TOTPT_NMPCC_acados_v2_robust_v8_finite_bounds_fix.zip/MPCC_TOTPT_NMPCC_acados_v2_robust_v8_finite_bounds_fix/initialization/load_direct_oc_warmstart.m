function warm = load_direct_oc_warmstart(cfg,base)
%LOAD_DIRECT_OC_WARMSTART Load direct-OCP result only as an initial iterate.
if ~isfile(cfg.reference.warmstart_file)
    error('MPCC:WarmstartMissing','Warm-start file not found: %s',cfg.reference.warmstart_file);
end
W=load(cfg.reference.warmstart_file);
required={'x_opt','u_opt','z_opt','t_opt','lap_fraction'};
for i=1:numel(required)
    if ~isfield(W,required{i}), error('MPCC:BadWarmstart','Missing %s.',required{i}); end
end
if size(W.x_opt,1)~=13 || size(W.u_opt,1)~=3 || size(W.z_opt,1)~=4
    error('MPCC:BadWarmstart','Warm-start dimensions do not match the direct-OCP model.');
end
warm=W;
warm.x_scaled = W.x_opt ./ base.x_s;
warm.u_scaled = W.u_opt ./ base.u_s;
warm.z_scaled = W.z_opt ./ base.z_s;
warm.lap_fraction = W.lap_fraction(:);
warm.t_opt = W.t_opt(:);
if any(diff(warm.t_opt) <= 0) || any(diff(warm.lap_fraction) < 0)
    error('MPCC:BadWarmstart','t_opt must increase strictly and lap_fraction must be nondecreasing.');
end
warm.lap_time = warm.t_opt(end)-warm.t_opt(1);
end
