function [ua,info] = project_actuator_fixed_power(base,xv,ua)
%PROJECT_ACTUATOR_FIXED_POWER Enforce the MPCC's fixed rear-power cap on an actuator state.
% xv and ua are the normalized vehicle-state and actuator vectors used by
% the direct-OCP model.  Only positive drive torque is reduced; brake and
% steering are unchanged.  This is an initialization/warm-start projection,
% not a change to the vehicle model or to the hard acados path constraint.

if numel(xv) ~= base.nx_vehicle || numel(ua) ~= base.nu_actuator
    error('MPCC:PowerProjectionDimension', ...
        'Expected xv(%d) and ua(%d), got xv(%d) and ua(%d).', ...
        base.nx_vehicle,base.nu_actuator,numel(xv),numel(ua));
end

veh = base.veh;
xv = xv(:);
ua = ua(:);

% Direct-OCP state order: rear wheel speeds are states 12 and 13.
omega_rl = base.x_s(12)*xv(12);
omega_rr = base.x_s(13)*xv(13);
omega_rear = 0.5*(omega_rl + omega_rr);
Tt_before = base.u_s(1)*ua(1);
Tt_after = Tt_before;

% The hard constraint is Tt*omega_rear <= power_motor_max.  At zero or
% negative rear speed, non-negative drive torque cannot violate this upper
% power bound, so no division is required.
if omega_rear > 0 && Tt_before > 0
    Tt_power_max = veh.power_motor_max/omega_rear;
    Tt_after = min(Tt_before,Tt_power_max);
end

% Preserve the source actuator box bound as well.  This should normally be
% inactive, but keeps the projector safe if a stale warm-start is supplied.
Tt_after = min(max(Tt_after,base.u_min(1)*base.u_s(1)), ...
                         base.u_max(1)*base.u_s(1));
ua(1) = Tt_after/base.u_s(1);

info = struct();
info.omega_rear_rad_s = omega_rear;
info.Tt_before_Nm = Tt_before;
info.Tt_after_Nm = Tt_after;
info.power_before_W = Tt_before*omega_rear;
info.power_after_W = Tt_after*omega_rear;
info.was_projected = Tt_after < Tt_before - 10*eps(max(1,abs(Tt_before)));
end
