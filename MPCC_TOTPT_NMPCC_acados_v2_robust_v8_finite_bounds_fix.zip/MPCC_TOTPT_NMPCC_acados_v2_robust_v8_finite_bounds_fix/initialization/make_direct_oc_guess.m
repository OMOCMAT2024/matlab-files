function guess = make_direct_oc_guess(cfg,dyn,track,warm,x_meas,z_meas,s_anchor)
%MAKE_DIRECT_OC_GUESS Build a smooth, algebraically consistent SQP iterate.
N=cfg.controller.N; Ts=cfg.controller.Ts;
base=dyn.base;
p_anchor=s_anchor/track.L;
guess.X=zeros(dyn.nx,N+1);
guess.U=zeros(dyn.nu,N);
guess.Z=zeros(dyn.nz,N);

if isempty(warm)
    guess = make_flat_guess(cfg,dyn,track,x_meas,z_meas,s_anchor);
    return
end

% Map current track location to the direct-OCP lap time, then sample that
% closed trajectory in PHYSICAL TIME. This is more dynamically meaningful
% than the v1 constant-speed distance extrapolation.
frac0 = mod(s_anchor/track.L,1);
t0 = interp1(warm.lap_fraction,warm.t_opt,frac0,'linear','extrap');
tgrid = warm.t_opt;
Tlap = warm.lap_time;
trel = (0:N)*Ts;
tq = t0 + trel;

% Periodic time copies.
tpad = [tgrid(1:end-1)-Tlap; tgrid; tgrid(2:end)+Tlap];
fracpad = [warm.lap_fraction(1:end-1)-1; warm.lap_fraction; warm.lap_fraction(2:end)+1];
Xpad = [warm.x_scaled(:,1:end-1), warm.x_scaled, warm.x_scaled(:,2:end)];
Upad = [warm.u_scaled(:,1:end-1), warm.u_scaled, warm.u_scaled(:,2:end)];
Zpad = [warm.z_scaled(:,1:end-1), warm.z_scaled, warm.z_scaled(:,2:end)];

for k=1:N+1
    tqk=tq(k);
    while tqk > tgrid(end)+Tlap, tqk=tqk-Tlap; end
    while tqk < tgrid(1)-Tlap, tqk=tqk+Tlap; end
    xv=zeros(13,1); ua=zeros(3,1); zz=zeros(4,1);
    for i=1:13, xv(i)=interp1(tpad,Xpad(i,:).',tqk,'linear','extrap'); end
    for i=1:3,  ua(i)=interp1(tpad,Upad(i,:).',tqk,'linear','extrap'); end
    for i=1:4,  zz(i)=interp1(tpad,Zpad(i,:).',tqk,'linear','extrap'); end
    fq=interp1(tpad,fracpad,tqk,'linear','extrap');
    ds=(fq-frac0)*track.L;

    % Interpolation of an historical direct-OCP trajectory can recover
    % actuator values from KERS-enabled portions of that trajectory.  The
    % MPCC has a hard fixed-power constraint at every shooting node, so
    % project the interpolated drive torque onto the CURRENT no-KERS cap.
    ua=project_actuator_fixed_power(base,xv,ua);

    guess.X(:,k)=[xv; ds/dyn.s_scale; ua];
    if k<=N, guess.Z(:,k)=zz; end
end

guess.X(:,1)=x_meas;
guess.Z(:,1)=z_meas;

% Convert actuator-state profile into normalized physical rate controls.
rate_lb=base.du_phys_min./base.rate_scale;
rate_ub=base.du_phys_max./base.rate_scale;
for k=1:N
    du_phys=(base.u_s.*(guess.X(dyn.idx.actuator,k+1)-guess.X(dyn.idx.actuator,k)))/Ts;
    guess.U(:,k)=min(max(du_phys./base.rate_scale,rate_lb),rate_ub);
end

% Reproject every lifted load to the CURRENT no-KERS/no-DRS DAE. This fixes
% a real weakness of v1: copied z values need not satisfy the modified DAE.
if cfg.initialization.project_loads_on_every_guess_stage
    zseed=z_meas;
    for k=1:N
        [zk,ok,res]=solve_lifted_loads_newton(dyn,guess.X(:,k),guess.U(:,k),zseed,p_anchor,cfg.plant);
        if ~ok
            warning('MPCC:GuessLoadProjection','Warm-start load projection failed at stage %d (%.3e); using last seed.',k,res);
            zk=zseed;
        end
        guess.Z(:,k)=zk;
        zseed=zk;
    end
end
end
