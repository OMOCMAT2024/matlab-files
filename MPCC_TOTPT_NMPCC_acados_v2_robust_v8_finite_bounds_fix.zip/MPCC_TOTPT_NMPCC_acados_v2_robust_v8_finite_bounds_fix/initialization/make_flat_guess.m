function guess = make_flat_guess(cfg,dyn,track,x_meas,z_meas,s_anchor)
%MAKE_FLAT_GUESS Conservative fallback guess independent of direct-OCP data.
N=cfg.controller.N; Ts=cfg.controller.Ts;
base=dyn.base; veh=base.veh;
p_anchor=s_anchor/track.L;
guess.X=repmat(x_meas,1,N+1);
guess.U=zeros(dyn.nu,N);
guess.Z=repmat(z_meas,1,N);

v=max(veh.V_min,veh.ux_s*x_meas(1));
for k=1:N+1
    guess.X(dyn.idx.sigma,k)=((k-1)*Ts*v)/dyn.s_scale;
    % Hold actuator values; this produces zero actuator-rate controls.
end
zseed=z_meas;
for k=1:N
    [zk,ok,~]=solve_lifted_loads_newton(dyn,guess.X(:,k),guess.U(:,k),zseed,p_anchor,cfg.plant);
    if ok, guess.Z(:,k)=zk; zseed=zk; end
end
end
