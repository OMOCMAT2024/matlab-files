function [x0,z0,warm] = make_initial_state(cfg,dyn,track)
%MAKE_INITIAL_STATE Construct a consistent flying-lap initial condition.
base=dyn.base;
if cfg.initialization.use_direct_oc_warmstart && isfile(cfg.reference.warmstart_file)
    warm=load_direct_oc_warmstart(cfg,base);
    xv=warm.x_scaled(:,1);
    ua=warm.u_scaled(:,1);
    z0=warm.z_scaled(:,1);
else
    warm=[];
    veh=base.veh;
    ux=max(43.95,veh.V_min+1);
    xv=zeros(13,1);
    xv(1)=ux/veh.ux_s;
    xv(8)=0;
    xv(9)=0;
    xv(10:13)=(ux/veh.rw)/veh.omega_s;
    ua=[100;0;0]./base.u_s;
    z0=[veh.m*veh.g*veh.lr/veh.l/2;veh.m*veh.g*veh.lr/veh.l/2; ...
        veh.m*veh.g*veh.lf/veh.l/2;veh.m*veh.g*veh.lf/veh.l/2]./base.z_s;
end

% The stored direct-OCP trajectory may come from a formulation that allowed
% KERS power.  This MPCC deliberately uses the fixed base power limit, and
% stage 0 is hard-constrained, so make the actuator part of the measured
% initial state feasible for the CURRENT no-KERS formulation.
[ua,power_projection] = project_actuator_fixed_power(base,xv,ua);
if power_projection.was_projected
    fprintf('Projected initial warm-start drive torque %.3f -> %.3f N*m (rear power %.1f -> %.1f kW).\n', ...
        power_projection.Tt_before_Nm,power_projection.Tt_after_Nm, ...
        power_projection.power_before_W/1e3,power_projection.power_after_W/1e3);
end

x0=[xv;0;ua];
% Project the lifted loads onto h_load=0 at the exact initial state.
p0=0;
[z0,ok,res]=solve_lifted_loads_newton(dyn,x0,zeros(3,1),z0,p0,cfg.plant);
if ~ok
    error('MPCC:InitialLoadSolve','Initial tyre-load solve failed, residual %.3e.',res);
end
% Check initial track footprint.
margin=base.veh.wt/2+base.veh.ws;
n_phys=base.veh.n_s*x0(8);
if n_phys > track.wl(1)-margin || n_phys < -track.wr(1)+margin
    error('MPCC:InitialTrackViolation','Initial n=%.3f m is outside the usable track width.',n_phys);
end
end
