function sol = get_nmpcc_solution(solver,N,nx,nu,nz)
%GET_NMPCC_SOLUTION Read a full acados multiple-shooting iterate.
sol.X = zeros(nx,N+1);
sol.U = zeros(nu,N);
sol.Z = zeros(nz,N);
sol.z_available = true;
for k=0:N
    sol.X(:,k+1)=full(solver.get('x',k));
    if k<N
        sol.U(:,k+1)=full(solver.get('u',k));
        try
            sol.Z(:,k+1)=full(solver.get('z',k));
        catch
            sol.z_available = false;
        end
    end
end
end
