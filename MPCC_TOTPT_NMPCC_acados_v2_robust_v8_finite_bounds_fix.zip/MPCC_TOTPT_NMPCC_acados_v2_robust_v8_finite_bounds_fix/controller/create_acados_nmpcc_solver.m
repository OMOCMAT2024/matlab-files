function ctrl = create_acados_nmpcc_solver(cfg, dyn, track, x0)
%CREATE_ACADOS_NMPCC_SOLVER Full nonlinear acados SQP controller.
base = dyn.base;
veh = base.veh;
N = cfg.controller.N;
Ts = cfg.controller.Ts;

ocp = AcadosOcp();
ocp.model = dyn.model;
if isprop(ocp,'name'), ocp.name = cfg.acados.model_name; end
ocp.parameter_values = 0.0;
ocp.solver_options.N_horizon = N;
ocp.solver_options.tf = N*Ts;
ocp.solver_options.integrator_type = cfg.controller.integrator_type;
ocp.solver_options.sim_method_num_stages = cfg.controller.irk_num_stages;
ocp.solver_options.sim_method_num_steps = cfg.controller.irk_num_steps;
ocp.solver_options.sim_method_newton_iter = cfg.controller.irk_newton_iter;
ocp.solver_options.sim_method_newton_tol = cfg.controller.irk_newton_tol;
ocp.solver_options.collocation_type = cfg.controller.collocation_type;
ocp.solver_options.nlp_solver_type = cfg.controller.nlp_solver_type;
ocp.solver_options.nlp_solver_max_iter = cfg.controller.nlp_max_iter;
ocp.solver_options.qp_solver = cfg.controller.qp_solver;
ocp.solver_options.qp_solver_cond_N = min(cfg.controller.qp_cond_N,N);
ocp.solver_options.qp_solver_iter_max = cfg.controller.qp_iter_max;
ocp.solver_options.qp_solver_ric_alg = cfg.controller.qp_ric_alg;
ocp.solver_options.qp_solver_cond_ric_alg = cfg.controller.qp_cond_ric_alg;
ocp.solver_options.hpipm_mode = cfg.controller.hpipm_mode;
ocp.solver_options.hessian_approx = cfg.controller.hessian_approx;
ocp.solver_options.regularize_method = cfg.controller.regularize_method;
ocp.solver_options.globalization = cfg.controller.globalization;
ocp.solver_options.nlp_solver_tol_stat = cfg.controller.tol_stat;
ocp.solver_options.nlp_solver_tol_eq = cfg.controller.tol_eq;
ocp.solver_options.nlp_solver_tol_ineq = cfg.controller.tol_ineq;
ocp.solver_options.nlp_solver_tol_comp = cfg.controller.tol_comp;
ocp.solver_options.qp_solver_tol_stat = cfg.controller.tol_stat;
ocp.solver_options.qp_solver_tol_eq = cfg.controller.tol_eq;
ocp.solver_options.qp_solver_tol_ineq = cfg.controller.tol_ineq;
ocp.solver_options.qp_solver_tol_comp = cfg.controller.tol_comp;
ocp.solver_options.qp_solver_warm_start = 1;
ocp.solver_options.nlp_solver_warm_start_first_qp = true;
try ocp.solver_options.levenberg_marquardt = cfg.controller.levenberg_marquardt; catch, end

% NLS cost -> Gauss-Newton Hessian.
ocp.cost.cost_type = 'NONLINEAR_LS';
ocp.cost.cost_type_e = 'NONLINEAR_LS';
ocp.cost.W = eye(dyn.ny);
ocp.cost.W_e = eye(dyn.ny_e);
ocp.cost.yref = zeros(dyn.ny,1);
ocp.cost.yref_e = zeros(dyn.ny_e,1);
% Initial cost is identical to path cost. Leaving cost_type_0 unset is the
% supported acados convention for reusing the path cost at stage 0.

% Box bounds. Actuator values are augmented states; Urate is bounded input.
xmin = [base.x_min; -cfg.constraints.progress_backtrack_m/dyn.s_scale; base.u_min];
xmax = [base.x_max; cfg.constraints.progress_horizon_factor*veh.V_max*(N*Ts)/dyn.s_scale; base.u_max];
margin = veh.wt/2 + veh.ws;
xmin(8) = max(xmin(8), min((-track.wr + margin)/veh.n_s));
xmax(8) = min(xmax(8), max(( track.wl - margin)/veh.n_s));
if any(xmin >= xmax)
    error('MPCC:BadStateBounds','At least one NMPCC state lower bound is not below its upper bound.');
end
ocp.constraints.idxbx = (0:dyn.nx-1).';
ocp.constraints.lbx = xmin;
ocp.constraints.ubx = xmax;
ocp.constraints.idxbx_e = (0:dyn.nx-1).';
ocp.constraints.lbx_e = xmin;
ocp.constraints.ubx_e = xmax;

ocp.constraints.idxbu = (0:dyn.nu-1).';
ocp.constraints.lbu = base.du_phys_min ./ base.rate_scale;
ocp.constraints.ubu = base.du_phys_max ./ base.rate_scale;

% Nonlinear path constraints.
% Keep inactive sides finite for compatibility with older MATLAB/acados JSON
% pipelines. The finite sides are deliberately redundant, not softened
% physical limits.
bounds = make_nmpcc_constraint_bounds(cfg,base);
ocp.constraints.lh = bounds.lh;
ocp.constraints.uh = bounds.uh;
ocp.constraints.lh_e = bounds.lh_e;
ocp.constraints.uh_e = bounds.uh_e;
ocp.constraints.x0 = x0;

build_dir = cfg.acados.build_dir;
if ~exist(build_dir,'dir'), mkdir(build_dir); end
code_dir = fullfile(build_dir,'c_generated_code_ocp');
if ~exist(code_dir,'dir'), mkdir(code_dir); end
json_file = fullfile(code_dir,[cfg.acados.model_name '_ocp.json']);
ocp.code_gen_options.code_export_directory = code_dir;
ocp.code_gen_options.json_file = json_file;
if ispc && strlength(string(code_dir)) > 210
    error('MPCC:BuildPathTooLong','acados generation path is too long: %s',code_dir);
end

fprintf('Creating robust nonlinear NMPCC: N=%d, Ts=%.3f s, %s, %s Hessian.\n', ...
    N,Ts,cfg.controller.nlp_solver_type,cfg.controller.hessian_approx);
solver_creation_opts = struct();
solver_creation_opts.output_dir = fullfile(build_dir,'mex_interface');
if ~exist(solver_creation_opts.output_dir,'dir'), mkdir(solver_creation_opts.output_dir); end
solver = AcadosOcpSolver(ocp,solver_creation_opts);

ctrl.solver = solver;
ctrl.ocp = ocp;
ctrl.xmin = xmin;
ctrl.xmax = xmax;
ctrl.N = N;
ctrl.Ts = Ts;
end
