function b = make_nmpcc_constraint_bounds(cfg,base)
%MAKE_NMPCC_CONSTRAINT_BOUNDS Cross-version-safe nonlinear constraint bounds.
% acados/HPIPM supports one-sided constraints, but older MATLAB/JSON pipelines
% can mishandle +/-Inf during code generation.  Use a moderate finite bound on
% the intentionally inactive side.  In this package all nonlinear residuals
% are dimensionless and physically remain far inside +/-10 over the declared
% state/actuator bounds, so B=10 is redundant rather than a softened limit.
B = cfg.constraints.finite_inactive_bound;
if ~(isscalar(B) && isfinite(B) && B >= 5)
    error('MPCC:BadInactiveBound','cfg.constraints.finite_inactive_bound must be finite and >= 5.');
end

epsh = cfg.constraints.original_tol;
lo5 = -B*ones(5,1);   % power + four slip residuals
lo2 = -B*ones(2,1);   % left/right track residuals

if cfg.constraints.strict_direct_oc
    % [BrTh; power; 4 slips; 2 track; 4 loads; progress; denominator]
    b.lh = [-epsh; lo5; lo2; base.z_min; ...
        cfg.constraints.min_progress_rate_normalized; cfg.constraints.min_curvilinear_denominator];
    b.uh = [ epsh; zeros(5,1); zeros(2,1); base.z_max; ...
        cfg.constraints.max_progress_rate_normalized; B];
    % Terminal stage has no algebraic tyre-load variables.
    b.lh_e = [-epsh; lo5; lo2; ...
        cfg.constraints.min_progress_rate_normalized; cfg.constraints.min_curvilinear_denominator];
    b.uh_e = [ epsh; zeros(5,1); zeros(2,1); ...
        cfg.constraints.max_progress_rate_normalized; B];
else
    % [power; 4 slips; 2 track; 4 loads; progress; denominator]
    b.lh = [lo5; lo2; base.z_min; ...
        cfg.constraints.min_progress_rate_normalized; cfg.constraints.min_curvilinear_denominator];
    b.uh = [zeros(5,1); zeros(2,1); base.z_max; ...
        cfg.constraints.max_progress_rate_normalized; B];
    b.lh_e = [lo5; lo2; ...
        cfg.constraints.min_progress_rate_normalized; cfg.constraints.min_curvilinear_denominator];
    b.uh_e = [zeros(5,1); zeros(2,1); ...
        cfg.constraints.max_progress_rate_normalized; B];
end

if any(~isfinite([b.lh; b.uh; b.lh_e; b.uh_e]))
    error('MPCC:NonfiniteConstraintBound','Generated nonlinear constraint bounds must all be finite.');
end
end
