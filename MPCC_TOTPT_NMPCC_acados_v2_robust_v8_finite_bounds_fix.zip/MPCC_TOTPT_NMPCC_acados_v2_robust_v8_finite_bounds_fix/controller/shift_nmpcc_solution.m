function guess = shift_nmpcc_solution(prev,x_meas,z_meas,ds_actual_scaled,p_new,dyn,cfg)
%SHIFT_NMPCC_SOLUTION Shift the previous nonlinear solution by one MPC stage.
N=size(prev.U,2);
guess.X=zeros(size(prev.X));
guess.U=zeros(size(prev.U));
guess.Z=zeros(size(prev.Z));
guess.X(:,1)=x_meas;
for j=2:N+1
    src=min(j+1,N+1);
    guess.X(:,j)=prev.X(:,src);
    guess.X(dyn.idx.sigma,j)=guess.X(dyn.idx.sigma,j)-ds_actual_scaled;
end
if N>1, guess.U(:,1:N-1)=prev.U(:,2:N); end
guess.U(:,N)=prev.U(:,N);

if isfield(prev,'z_available') && prev.z_available
    if N>1, guess.Z(:,1:N-1)=prev.Z(:,2:N); end
    guess.Z(:,N)=prev.Z(:,N);
else
    guess.Z=repmat(z_meas,1,N);
end
guess.Z(:,1)=z_meas;

% Project shifted algebraic states onto h_load=0. This costs only four small
% Newton solves per stage and greatly improves IRK/SQP consistency.
if cfg.initialization.project_loads_on_every_guess_stage
    zseed=z_meas;
    for k=1:N
        [zk,ok,~]=solve_lifted_loads_newton(dyn,guess.X(:,k),guess.U(:,k),zseed,p_new,cfg.plant);
        if ok
            guess.Z(:,k)=zk;
            zseed=zk;
        else
            guess.Z(:,k)=zseed;
        end
    end
end
end
