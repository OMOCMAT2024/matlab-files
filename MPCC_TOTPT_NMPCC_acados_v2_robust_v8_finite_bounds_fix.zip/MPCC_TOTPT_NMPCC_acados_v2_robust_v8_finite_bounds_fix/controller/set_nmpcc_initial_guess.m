function set_nmpcc_initial_guess(solver, guess)
%SET_NMPCC_INITIAL_GUESS Set stagewise x/u/z primal iterate for acados v0.5.x.
N = size(guess.U,2);
if size(guess.X,2) ~= N+1
    error('MPCC:BadInitialGuess','guess.X must have N+1 columns.');
end
for k = 0:N
    solver.set('x',guess.X(:,k+1),k);
end
for k = 0:N-1
    solver.set('u',guess.U(:,k+1),k);
    if isfield(guess,'Z') && ~isempty(guess.Z)
        solver.set('z',guess.Z(:,k+1),k);
    end
end
end
