# Design and convergence notes

## Why IRK/DAE
The four lifted tyre loads are algebraic variables tied to the vehicle state and actuator through `h_load=0`. The controller therefore exposes them to acados as algebraic states and appends `h_load` to the implicit residual. IRK is appropriate for this implicit DAE structure and avoids an artificial explicit approximation of the load solve inside the controller.

## Why nonlinear least squares + Gauss-Newton
The robust objective is written as residuals: high desired progress rate, small contouring/heading/body-motion residuals, actuator/rate regularization and drive/brake overlap. The desired progress-rate reference is deliberately above the feasible maximum, so the least-squares optimum attempts to progress as fast as constraints permit. Gauss-Newton yields a positive-semidefinite approximation to the cost Hessian and is generally less brittle than taking the exact Hessian of a nonconvex economic progress term.

## Why complementarity is penalized by default
The equality `Tt*Tb=0` represents mutually exclusive drive/brake. At `Tt=Tb=0` its gradient is zero, violating the regularity that SQP benefits from. A sufficiently strong smooth overlap penalty preserves the preference for non-overlap without inserting that degeneracy into the hard equality Jacobian. Strict mode exists for research comparison.

## Scaling
All original normalized vehicle states, actuator states and loads keep the source model's scales. New progress is scaled by 100 m, actuator rates are divided by their physical rate scales, and the objective uses normalized state variables. Constraint residuals therefore remain close to order one wherever possible.

## Warm start
The supplied direct-OCP trajectory is not a reference trajectory; it is only a nonlinear initial iterate. v2 uses its actual time history and then solves the four algebraic load equations at every horizon node. After each successful control step, the previous prediction is shifted and all load nodes are projected again.

## Retry hierarchy
1. shifted previous NMPCC solution;
2. fresh time-aligned, load-projected direct-OCP guess;
3. conservative flat guess.
A failure after all three is reported rather than silently applying an invalid control.

## Plant/controller separation
The controller enforces track/performance/load constraints. The plant integrates the same physical vehicle model but does not impose controller path inequalities. In the default plant, lifted loads are solved internally at each RK4 stage, reducing the algebraic subsystem locally while keeping a fixed, user-controlled integration step.
