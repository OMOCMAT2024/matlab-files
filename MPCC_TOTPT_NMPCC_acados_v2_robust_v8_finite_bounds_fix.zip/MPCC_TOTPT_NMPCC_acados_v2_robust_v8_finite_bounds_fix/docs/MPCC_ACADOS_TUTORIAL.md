---
title: "Tutorial: Nonlinear MPCC with the TOTPT F1 Vehicle Model, CasADi and acados"
subtitle: "Robust v2 package — architecture, equations, solver choices, tuning and modification guide"
author: "Package technical documentation"
date: "12 August 2026"
toc: true
toc-depth: 3
geometry: margin=1in
fontsize: 10pt
---

# 1. Purpose and scope

This tutorial explains the complete `MPCC_TOTPT_NMPCC_acados_v2_robust` package. It is intended both for a first-time MPCC/acados user and for someone who later needs to change the horizon, track, vehicle parameters, constraints, plant integrator or objective without accidentally breaking the numerical formulation.

The package has one overriding modeling rule: **the controller and the simulated plant use the vehicle model from the supplied direct optimal-control (TOTPT) package**. The MPCC is not allowed to replace it with a bicycle model merely because that would be easier to solve. The controller additionally retains the important path/performance constraints associated with that model. The plant uses the same physical-time vehicle equations but does not artificially impose the controller's path inequalities.

The implementation stack is MATLAB, CasADi and acados. The source copies `source_direct_oc/my_model.m` and `source_direct_oc/my_params.m` are retained so that the physical model remains traceable to the direct-OCP source. The runtime MPCC deliberately disables KERS and DRS: the nominal drag coefficient is used and both KERS flags supplied to the source model are zero.

A crucial distinction is that the package performs **nonlinear MPC/MPCC**. MATLAB does not construct an LTV vehicle model and does not manually assemble the QP used by the earlier MPCC implementation. The nonlinear dynamics, nonlinear tyre-load equations, nonlinear track geometry and nonlinear performance constraints are passed to acados. Full SQP solves the nonlinear OCP, internally solving QP subproblems as part of the nonlinear optimization algorithm.

# 2. Relationship to classical MPCC

The classical model-predictive contouring-control formulation introduced for autonomous racing combines path generation and path following in a single receding-horizon optimization. Rather than giving the controller a precomputed racing line to track, the objective rewards progress while penalizing deviation from a geometric reference path. In a Cartesian formulation, an auxiliary progress variable is commonly introduced because computing the exact closest-point projection inside the online optimization would itself be an optimization problem. A lag error couples the auxiliary progress to the vehicle position, while the contouring error measures lateral deviation.

The present package has an important simplification available because the TOTPT vehicle model is **already expressed in road/Frenet coordinates**. Its state `n` is the lateral displacement from the road centerline and `xi` is the heading error relative to the track tangent. Therefore:

- `n` already plays the role of contouring error;
- `xi` directly measures orientation mismatch to the path;
- the road-coordinate kinematics directly provide physical progress rate `s_dot`.

For that reason the package does not introduce a redundant Cartesian closest-point projection variable and a separate lag-error state. It uses a local progress state `sigma` for numerical scaling and for evaluating the track ahead of the vehicle. Conceptually this is a curvilinear nonlinear MPCC/economic NMPC formulation built from the same contouring-versus-progress idea.

# 3. Package map

The package is organized by responsibility:

- `mpcc_default_config.m` — numerical settings, costs, constraints, plant settings and build location.
- `source_direct_oc/` — source-faithful `my_model.m` and `my_params.m`.
- `model/build_direct_oc_base_functions.m` — executes the source model and wraps its CasADi functions.
- `model/build_nmpcc_dae_model.m` — creates the augmented acados DAE, nonlinear constraints and NLS cost.
- `track/` — reconstructs the Shanghai track and CasADi interpolants.
- `controller/` — builds the acados OCP solver and manages the nonlinear warm start.
- `plant/` — fixed-step RK4/Newton plant and optional acados IRK-DAE plant.
- `initialization/` — loads the direct-OCP solution as an initial iterate, constructs guesses and projects tyre loads.
- `tests/` — model-level preflight and combined checks.
- `utils/` — API compatibility, plotting, validation and diagnostics.
- `reference_data/direct_oc_warmstart_no_kers_drs.mat` — compact warm-start data, not an MPCC reference line.

The top-level workflow is deliberately short:

```matlab
startup_mpcc_package
report = run_preflight();
result_short = run_short_smoke_test();
result = run_mpcc_totpt_nmpcc();
```

# 4. The source vehicle model

## 4.1 Vehicle states

The direct-OCP model supplies 13 normalized vehicle states. Their physical interpretation follows the source model:

1. longitudinal velocity `ux`;
2. lateral velocity `uy`;
3. yaw rate `r`;
4. sprung-body roll angle `phi`;
5. roll rate;
6. sprung-body pitch angle `theta`;
7. pitch rate;
8. lateral road displacement `n`;
9. road-relative heading error `xi`;
10–13. four wheel angular speeds.

The model source also defines three normalized actuator variables:

- drive torque `Tt_n`;
- brake torque `Tb_n`;
- steering angle `delta_n`.

The four lifted algebraic variables are normalized tyre vertical loads:

- `Fz_FL_n`;
- `Fz_FR_n`;
- `Fz_RL_n`;
- `Fz_RR_n`.

All source state, actuator and load normalization factors are reused. This matters because re-scaling only some parts of a large nonlinear OCP is a common way to create Jacobian columns with wildly different magnitudes.

## 4.2 Physical-time dynamics

The direct-OCP code contains both road/spatial relationships and the physical-time state derivative `y_xdot`. The MPCC controller and plant use the physical-time derivative. This is essential because the receding-horizon controller is discretized with a fixed sample time `Ts`, and the simulated plant must advance in physical seconds rather than spatial increments.

The source road kinematics contain the familiar Frenet denominator

\[
D = 1-n\kappa(s),
\]

and the centerline progress rate is

\[
\dot{s}=\frac{u_x\cos\xi-u_y\sin\xi+\varepsilon_v}{1-n\kappa(s)}.
\]

The small source-model velocity regularization is retained. The controller additionally constrains the Frenet denominator away from zero because a trajectory approaching `1-n*kappa=0` produces a coordinate singularity and very poor derivatives.

# 5. Why the tyre loads form a DAE

The direct OCP lifts the four tyre loads and imposes four equations

\[
h_{load}(x,u,z,p)=0.
\]

The loads are therefore not arbitrary controls and they are not ordinary differential states. They are algebraic unknowns determined simultaneously with the vehicle dynamics.

In v2 the acados controller uses the algebraic state

\[
z=[F_{z,FL,n},F_{z,FR,n},F_{z,RL,n},F_{z,RR,n}]^T
\]

and the implicit residual

\[
F(X,\dot X,U,z,p)=
\begin{bmatrix}
\dot X-f(X,U,z,p)\\
h_{load}(X,U,z,p)
\end{bmatrix}=0.
\]

This formulation has several advantages. The controller sees exactly the lifted-load relation that the direct OCP uses; the tyre forces are evaluated with loads consistent with the algebraic equations; and acados can integrate the complete implicit system with IRK rather than hiding a separate load solver inside every controller derivative call.

The formulation assumes that, in the normal operating region, the four load equations locally determine a unique physically meaningful `z`. The plant Newton projection and preflight tests explicitly check this local algebraic consistency.

# 6. Augmented MPCC state and control

The controller differential state is

\[
X=[x_{veh};\sigma;T_{t,n};T_{b,n};\delta_n],
\]

which has 17 components.

The new local progress state is scaled by `cfg.scaling.progress_m = 100 m`. If physical progress from the current anchor is `Delta s`, then

\[
\sigma=\frac{\Delta s}{100\;m}.
\]

The physical actuator values are made differential states because the original direct OCP limits their physical rates. The MPCC controls are therefore normalized actuator rates, not the actuator values themselves. This converts physical rate limits into ordinary box bounds on the three MPCC controls and avoids finite-difference rate constraints between consecutive controls.

After each plant sample, the actual progress is transferred to an anchor parameter and `sigma` is reset to zero. This is an exact coordinate change: the absolute position used by the track functions is

\[
s_{abs}=L p+s_{scale}\sigma,
\]

where `p` is the normalized anchor and `L` is track length. Shifting the anchor by exactly the distance removed from `sigma` leaves `s_abs` unchanged.

# 7. Track representation

The package uses the Shanghai source arrays from the supplied direct-OCP data. It mirrors the visible preprocessing in the direct-OCP setup: the duplicated endpoint is removed, the specified curvature patch is applied when enabled, and the data are resampled to the controller grid.

CasADi interpolants provide, as functions of absolute progress:

- curvature `kappa(s)`;
- usable left width `wl(s)`;
- usable right width `wr(s)`;
- centerline `X(s),Y(s)` for plotting;
- tangent angle `Theta(s)` for reconstruction/diagnostics.

KERS/DRS schedules are not part of the v2 track functions. The model wrapper always uses nominal drag and zero KERS flags. This avoids introducing discontinuous or artificially smoothed binary schedules into derivatives of the NMPCC.

# 8. MPCC objective in v2

## 8.1 Why v1's economic exact Hessian was risky

A direct economic cost such as `-q*s_dot` is attractive because it expresses maximum progress transparently. But `s_dot` contains trigonometric terms and division by the Frenet denominator. Its exact second derivative need not be positive semidefinite. When a full SQP method passes that curvature into QP subproblems, poor warm starts or highly nonlinear regions can produce difficult or indefinite Hessians.

v2 deliberately prioritizes robust convergence. The objective is represented as nonlinear least-squares residuals and acados uses a Gauss-Newton Hessian approximation.

## 8.2 Progress residual

The normalized progress rate is

\[
v_p=\dot s/V_s.
\]

The residual is

\[
r_p=\sqrt{q_p}(v_p-v_{p,ref}).
\]

`v_p,ref` is intentionally chosen slightly above the practically feasible maximum. The controller therefore cannot generally make the residual zero; instead it tries to raise progress as far as the vehicle and constraints permit. This converts a maximum-progress intention into an NLS form with a Gauss-Newton Hessian.

A terminal progress residual gives the horizon endpoint an additional incentive to advance.

## 8.3 Contouring and regularization residuals

Additional residuals penalize normalized:

- lateral displacement `n`;
- heading error `xi`;
- roll and pitch;
- lateral velocity and yaw rate;
- drive, brake and steering actuator magnitude;
- actuator rates.

The contouring weight is deliberately not large. Racing MPCC must be allowed to use the track width; an excessive contouring penalty collapses the solution toward centerline tracking and defeats much of the purpose of MPCC.

# 9. Drive/brake complementarity: strict versus robust

The direct OCP imposes approximately

\[
T_{t,n}T_{b,n}=0.
\]

This encodes mutually exclusive drive and braking. It is physically sensible, but as a hard nonlinear equality it is unfriendly to generic SQP near neutral actuator values. The gradient is

\[
\nabla(T_tT_b)=[T_b,T_t],
\]

so at `T_t=T_b=0` the constraint has zero gradient. This can make the equality Jacobian rank-deficient exactly where a controller may naturally pass through neutral torque.

Therefore v2's **robust default** removes this one equality from the hard nonlinear-constraint vector and instead adds

\[
r_{db}=\sqrt{q_{db}}\,T_{t,n}T_{b,n}
\]

to the NLS cost. Drive/brake overlap remains strongly discouraged without forcing a degenerate equality into every SQP linearization.

For research comparison, the original equality can be restored:

```matlab
cfg = mpcc_default_config();
cfg.constraints.strict_direct_oc = true;
```

Strict mode is not recommended as the first commissioning configuration.

# 10. Hard constraints retained by the controller

The robust controller retains the important physical and geometric constraints from the direct-OCP formulation:

1. fixed engine/motor power limit, without KERS augmentation;
2. four tyre slip inequalities;
3. left and right track-footprint constraints including vehicle margin;
4. lower and upper bounds on all four algebraic tyre loads;
5. bounds on the original vehicle states;
6. bounds on drive torque, brake torque and steering angle;
7. physical actuator-rate bounds through normalized MPCC controls;
8. nonnegative/limited progress rate;
9. a lower bound on the Frenet denominator.

The terminal nonlinear constraints omit algebraic-load bounds because the acados terminal stage has no algebraic variable; terminal power/slip/track/progress/denominator constraints remain defined from the terminal differential state and actuator states.

# 11. Scaling and conditioning

Good scaling does not make a bad nonlinear program good, but poor scaling can make a good formulation appear unsolvable. v2 follows four rules.

First, all original vehicle states keep the source direct-OCP scales. Second, actuator states and tyre loads keep their original scales. Third, actuator-rate controls are divided by physical rate scales, so control magnitudes are near one at their bounds. Fourth, new progress is scaled by 100 m.

The cost is formed from already normalized quantities. Consequently the Jacobian and Gauss-Newton matrix do not combine raw values such as hundreds of thousands of watts, thousands of newtons, hundredths of radians and kilometres of track distance without normalization.

When modifying the package, do not simply increase a cost by many orders of magnitude to “force” a constraint. Hard constraints should remain constraints. Cost weights should express preference among feasible solutions and provide useful numerical regularization.

# 12. acados discretization and nonlinear solver

## 12.1 Default horizon

The default is:

- controller sample time `Ts=0.05 s`;
- `N=20` intervals;
- 1.0 s prediction horizon.

A longer horizon usually improves anticipation but increases NLP/QP work. For first commissioning, keeping a moderate horizon is safer than immediately using 40–80 nodes with the full nonlinear F1 model.

## 12.2 IRK and Radau IIA

The controller uses implicit Runge-Kutta because the model contains algebraic tyre-load equations. Three-stage Gauss-Radau IIA collocation is the default. This is well suited to stiff/implicit systems and avoids constructing an explicit controller ODE by repeatedly solving loads outside the acados integrator.

One IRK integration step is used per shooting interval initially. If integration error is later demonstrated to be a limiting factor, increase `irk_num_steps` before indiscriminately increasing solver tolerances or cost weights.

## 12.3 Full SQP

The default `nlp_solver_type='SQP'` obeys the requirement not to manually linearize the MPCC in MATLAB. Full SQP iterates nonlinear dynamics and constraints until convergence or the configured iteration limit.

`MERIT_BACKTRACKING` globalization reduces the chance that an aggressive full SQP step increases the nonlinear merit function. `PROJECT` regularization and a small Levenberg-Marquardt term provide additional numerical protection. HPIPM is used in robust mode for the QP subproblems.

# 13. Warm-start strategy

A racing NMPCC with a high-dimensional nonlinear vehicle model should not start from arbitrary zero trajectories if a physically meaningful offline trajectory is available.

The compact MAT file contains the supplied direct-OCP states, actuators, loads, time and lap fraction. Importantly, this trajectory is **not tracked in the MPCC objective**. It is only an initial nonlinear iterate.

v2 fixes two warm-start weaknesses from v1.

First, horizon nodes are sampled using the actual direct-OCP time vector `t_opt`. A constant-speed conversion from time to distance can be badly wrong in braking zones and corners. Second, all four lifted tyre loads are solved again with the current v2 DAE at every prediction stage. This is necessary because v2 no longer activates KERS/DRS and because interpolation alone does not guarantee exact algebraic consistency.

The retained historical direct-OCP MAT file can contain drive-torque points consistent with a KERS-augmented power ceiling (approximately base power plus 60 kW). Because KERS is disabled in this MPCC, every actuator state taken from that warm-start is projected after interpolation onto the current fixed `veh.power_motor_max` using the current rear-wheel speeds. The MAT file itself is not rewritten; it remains traceable source data rather than an asserted feasible MPCC trajectory.

After every successful NMPCC solve, the solution is shifted one stage. The local progress coordinate is shifted by the actual plant progress, and every algebraic load is reprojected before the next SQP call.

# 14. Failure-recovery strategy

At each closed-loop step the package tries, in order:

1. the shifted previous NMPCC solution;
2. a newly constructed, time-aligned direct-OCP warm start with load projection;
3. a conservative flat guess with held actuators and projected loads.

If all attempts fail, the simulation stops and prints acados statistics. The package does not silently apply an unverified control after an optimization failure.

In a real vehicle implementation an independent safety/fallback controller would also be required. This research simulation package intentionally does not pretend that an NLP retry is a complete safety architecture.

# 15. Plant simulation

## 15.1 Default fixed-step RK4 + load Newton

The default plant is designed to mimic a deterministic fixed-rate simulation while preserving the direct-OCP model.

At each RK4 stage:

1. take the current trial vehicle state and actuator;
2. solve the four equations `h_load=0` with damped Newton;
3. evaluate the exact source physical-time derivative `y_xdot` using those loads;
4. form the RK4 increment.

The plant fixed step defaults to `1e-3 s`. `Ts/fixed_dt` must be an integer, ensuring an exact integer number of plant steps per controller sample.

This is an explicit ODE integration only after the algebraic variables have been locally eliminated by Newton projection. It is appropriate while the load equations remain locally solvable and the chosen time step resolves the fastest dynamics of interest.

## 15.2 Optional acados IRK-DAE plant

For comparison, `cfg.plant.method='acados_irk_dae'` uses `AcadosSimSolver` on the same implicit DAE. This eliminates any concern that RK4/Newton and controller IRK treat the algebraic system differently. It is also a useful validation cross-check: the two plant methods should agree closely when tolerances and steps are sufficiently tight.

# 16. Running the package on Windows

## 16.1 Prerequisites

Use the MATLAB/CasADi/acados installation in which a standard acados MATLAB example already compiles. The package cannot repair a broken MinGW/CMake/acados installation by itself.

On Windows, initialize the same acados environment you use for existing examples, then change MATLAB's current folder to the package root and run `startup_mpcc_package`.

The package chooses a short acados build directory to reduce Windows path-length problems. You may define `TOTPT_NMPCC_BUILD_DIR`; the code can also reuse an existing `MPCC_ACADOS_BUILD_DIR` convention.

## 16.2 Preflight first

Run:

```matlab
report = run_preflight();
```

This does not compile acados code. It checks dimensions, track data, scales, algebraic loads, path-constraint sanity, KERS/DRS disabling, progress-frame invariance, one fixed plant step, warm-start actuator-rate bounds and warm-start load consistency.

A preflight failure is a modeling/data error and should be fixed before code generation.

## 16.3 Short smoke test

Then run:

```matlab
result_short = run_short_smoke_test();
```

This is the first test that invokes real acados code generation/MEX compilation. It runs only 0.5 s closed loop so an interface or numerical problem appears quickly.

## 16.4 Full run

After the smoke test succeeds:

```matlab
result = run_mpcc_totpt_nmpcc();
```

The result structure contains state histories, loads, actuator states and rates, solver times/status, track progress, path residuals and reconstructed global coordinates.

# 17. How to interpret convergence diagnostics

A successful acados status does not alone prove the controller is well tuned. Inspect:

- maximum dynamics/equality residual;
- nonlinear inequality residuals;
- algebraic load residuals;
- QP/NLP iteration counts;
- solve-time distribution;
- actuator saturation and rate saturation;
- Frenet denominator;
- minimum track margin;
- tyre-load bounds and slip constraints.

If the first solve fails but the direct-OCP retry succeeds, warm-start shifting may be the issue. If all guesses fail at the same track location, inspect a physical constraint or model singularity. If QPs fail while nonlinear residuals are moderate, scaling/Hessian/regularization deserve attention. If Newton load projection fails before acados is called, the problem is in the algebraic load subsystem or its initial seed, not the NLP solver.

# 18. Tuning procedure

Use a disciplined order.

**Step 1: prove model consistency.** Do not tune costs until `run_preflight` passes and the short smoke test integrates the plant without load failures.

**Step 2: keep robust complementarity mode.** Do not enable the hard drive/brake equality during first commissioning.

**Step 3: inspect progress and centerline behavior.** If the car is excessively centerline-bound, decrease `q_contour`. If it takes geometrically unreasonable excursions, increase contouring/heading moderately and verify track margins.

**Step 4: inspect actuator chatter.** Increase the corresponding `q_rate` gradually. Large rate weights can make the car too slow to react; use physical rate limits as the hard protection.

**Step 5: increase horizon only after stable operation.** Try `N=30`, then `N=40`, measuring both solve time and convergence. Long horizon is not automatically better if the nonlinear initialization becomes poor.

**Step 6: integration refinement.** If state predictions disagree materially with the plant, increase IRK steps or compare with the optional acados DAE plant.

# 19. Changing controller sample time or horizon

To change horizon length:

```matlab
cfg = mpcc_default_config();
cfg.controller.N = 30;
result = run_mpcc_totpt_nmpcc(cfg);
```

To change sample time:

```matlab
cfg.controller.Ts = 0.04;
cfg.plant.fixed_dt = 0.001;
```

The plant step must divide `Ts` exactly. When changing `Ts`, reconsider actuator-rate regularization and the number of prediction nodes needed to preserve an adequate preview time.

# 20. Changing the plant integration step

For a smaller default plant step:

```matlab
cfg = mpcc_default_config();
cfg.plant.fixed_dt = 5e-4;
```

A smaller step is not automatically more “realistic”; it reduces time-discretization error at greater cost. Validate convergence by halving the plant step and comparing closed-loop trajectories. If results change materially, the larger step was not converged.

# 21. Changing MPCC weights

All weights are in `mpcc_default_config.m`. Because the residuals are normalized, moderate order-of-magnitude changes are meaningful. Avoid changing many weights at once.

For more freedom to use track width:

```matlab
cfg.cost.q_contour = 0.03;
```

For smoother steering-rate behavior:

```matlab
cfg.cost.q_rate(3) = 0.08;
```

For stronger drive/brake separation in robust mode:

```matlab
cfg.cost.q_drive_brake_overlap = 25;
```

After changing weights, compare actual overlap and constraint residuals rather than assuming a larger penalty has the intended effect.

# 22. Changing the vehicle model

The correct modification point is the source direct-OCP model/parameter interface, not an ad-hoc second MPC model. If `my_model.m` state dimension, actuator dimension or algebraic-load dimension changes, wrappers that currently assert 13/3/4 dimensions must be updated deliberately.

After any model change:

1. rebuild/check scaling;
2. update state/actuator/load bounds;
3. verify the physical-time derivative output;
4. update warm-start data dimensions;
5. rerun preflight before compiling acados.

Do not add a new state to the plant while forgetting it in the controller, or vice versa.

# 23. Replacing the track

A new track needs monotone progress and consistent curvature/width/centerline arrays. The controller requires at least curvature and left/right usable widths; plotting requires centerline coordinates.

The important invariant is that all track quantities are functions of the same periodic progress coordinate. Any new preprocessing should be made explicit in the track builder rather than hidden in a workspace script.

# 24. Why KERS and DRS are absent

The original direct-OCP source includes parameters and symbols for KERS/DRS-related operation. The user explicitly requested that these need not be included in the MPCC package. v2 therefore makes the runtime decision unambiguous:

```text
Cd = veh.Cd_nominal
kers_on = 0
kers_last_on = 0
```

The source files still contain the symbols because they are preserved copies of the model. Their presence in source should not be confused with runtime activation.

# 25. Investigation of the first package

The v2 redesign was not merely cosmetic. The audit treated v1 as suspect and identified several concrete or high-probability problems.

**API robustness.** Status, time and statistics handling were revised to align with current acados MATLAB conventions while retaining conservative fallbacks where useful.

**Hessian conditioning.** The external economic exact-Hessian formulation was replaced by NLS/Gauss-Newton to avoid feeding strongly nonconvex progress curvature directly into QP Hessians.

**Constraint qualification.** Hard drive/brake complementarity is disabled by default because its Jacobian degenerates at neutral torque.

**Warm-start dynamics.** The offline trajectory is now sampled using its true time history rather than constant-speed spatial extrapolation.

**Algebraic consistency.** Every initialized and shifted load node is Newton-projected.

**Recovery.** Two independent fallback guesses are available after a shifted-warm-start failure.

**Unnecessary hybrid features.** KERS/DRS schedules and their transition interpolation are removed.

These changes target not only coding mistakes but also failure modes that can make a mathematically correct NMPCC appear unreliable.

# 26. What the package can and cannot guarantee

The package includes internal consistency tests, source-level audits and a deliberately small first compile/run test. Nevertheless, no document can guarantee that an arbitrary PC/toolchain will compile generated C code without actually executing that toolchain. The environment used to assemble this package does not contain the user's Windows MATLAB/acados/MEX installation. Therefore the only rigorous final proof of target compatibility is a successful `run_short_smoke_test` on that PC.

This limitation is intentionally explicit. A reproducible engineering workflow distinguishes source/model verification from target compiler verification rather than claiming the latter without evidence.

# 27. Recommended commissioning checklist

Before a full lap, verify all of the following:

- `run_preflight` passes;
- acados standard MATLAB example already compiles on the machine;
- short Windows build path is selected;
- `run_short_smoke_test` returns only successful solver statuses;
- lifted-load residual remains near the configured Newton tolerance;
- no state/load NaNs appear;
- progress remains forward;
- Frenet denominator remains comfortably positive;
- tyre loads remain physical;
- track constraints have margin;
- drive/brake overlap in robust mode is small;
- solve time is compatible with the intended sample time before claiming real-time performance.

Only then extend the simulation duration or increase the horizon.

# 28. References and source basis

The MPCC concepts follow the supplied paper by Alexander Liniger, Alexander Domahidi and Manfred Morari, *Optimization-based autonomous racing of 1:43 scale RC cars* (2014), especially its one-level contouring-control formulation, progress concept and receding-horizon racing perspective.

The supplied AMZ Driverless system paper provides additional autonomous-racing and simulation context, including the use of predictive control and first-principles simulation.

For acados syntax and capabilities, use the official acados documentation and the examples installed with the same acados version as the MATLAB interface. This package was revised for the current v0.5.x interface conventions, including the modern code-generation-options naming and explicit whole-horizon stage ranges where applicable.

# Appendix A. Default configuration summary

```text
Controller Ts                       0.05 s
Prediction intervals               20
Prediction time                    1.0 s
Controller integrator              IRK
Collocation                        Gauss-Radau IIA
IRK stages                         3
IRK steps / shooting interval      1
NLP solver                         full SQP
QP solver                          partial-condensing HPIPM
Hessian approximation              Gauss-Newton
Globalization                      merit backtracking
Regularization                     PROJECT + small LM
Plant                              fixed-step RK4 + load Newton
Default plant step                 0.001 s
Hard drive/brake complementarity   OFF (penalty used)
KERS                               OFF
DRS                                OFF
```

# Appendix B. Minimal modification examples

Longer horizon:

```matlab
cfg = mpcc_default_config();
cfg.controller.N = 30;
result = run_mpcc_totpt_nmpcc(cfg);
```

Optional implicit plant:

```matlab
cfg = mpcc_default_config();
cfg.plant.method = 'acados_irk_dae';
result = run_mpcc_totpt_nmpcc(cfg);
```

Strict original complementarity:

```matlab
cfg = mpcc_default_config();
cfg.constraints.strict_direct_oc = true;
result = run_mpcc_totpt_nmpcc(cfg);
```

Smaller plant step:

```matlab
cfg = mpcc_default_config();
cfg.plant.fixed_dt = 5e-4;
result = run_mpcc_totpt_nmpcc(cfg);
```
