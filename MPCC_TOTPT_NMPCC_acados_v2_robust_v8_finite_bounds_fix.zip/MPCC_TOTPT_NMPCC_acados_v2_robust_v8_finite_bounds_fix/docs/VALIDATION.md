# Validation checklist

`run_preflight` checks model dimensions, scaling positivity, Shanghai progress-grid monotonicity/length, tyre-load projection, initial constraint sanity, explicit disabling of KERS/DRS, local progress-frame invariance, one fixed-step RK4/Newton plant step, warm-start rate bounds and algebraic-load consistency.

`run_short_smoke_test` is the first test that actually invokes acados C-code generation/MEX compilation and runs 0.5 s closed loop.

The package archive should also be tested with an external ZIP integrity check. Target-specific MATLAB/acados compiler success cannot be established outside the user's installed Windows toolchain.

The preflight also verifies that the time-interpolated direct-OCP warm-start, after fixed-power actuator projection, satisfies the MPCC rear-power upper bound.
