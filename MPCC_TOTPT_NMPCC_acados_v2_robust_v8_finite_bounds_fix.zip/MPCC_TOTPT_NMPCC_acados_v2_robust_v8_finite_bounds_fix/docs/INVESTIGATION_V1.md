# Investigation of v1

The second package was produced by assuming the first package contained mistakes and then auditing its model mapping, nonlinear-program structure, initialization, solver interaction and convergence conditioning.

## Defects and high-risk choices found

1. **Solver return/status handling:** v1 called `solve()` and then queried `get('status')`. v2 records the return value of `solve()` as the primary status.
2. **Timing/statistics API:** v1 queried `get('time_tot')`; v2 prefers `get_stats('time_tot')` and retains a compatibility fallback.
3. **Statistics printing:** v2 prefers `print_statistics()` with a fallback for older interfaces.
4. **Initial state:** v2 prefers `set('constr_x0',x0)` before legacy bound-setter fallbacks.
5. **Indefinite exact Hessian risk:** v1 used an external economic cost and exact Hessian. Progress through nonlinear Frenet kinematics can create indefinite curvature. v2 uses nonlinear least squares and Gauss-Newton.
6. **Hard complementarity:** `Tt_n*Tb_n=0` is nonconvex and has a zero gradient at the neutral point. This can make SQP subproblems poorly conditioned. Robust v2 penalizes overlap; strict mode remains available.
7. **Warm-start parametrization:** v1 advanced through the offline solution using a constant-speed spatial estimate. v2 indexes the offline solution with its actual `t_opt` history.
8. **Algebraic consistency:** v1 did not re-solve all lifted loads at every initialized and shifted prediction node. v2 Newton-projects every node.
9. **Dead derivative guess:** v1 formed an `Xdot` guess which was not supplied to the OCP solver. v2 removes this misleading work.
10. **Limited recovery:** v1 mainly retried the same warm-start family. v2 adds a fresh projected direct-OCP retry and a conservative flat-guess retry.
11. **KERS/DRS complexity:** v1 retained piecewise distance schedules and smoothed their binary transitions through interpolation. They are not needed for the requested MPCC and are removed in v2.
12. **Source fidelity vs runtime:** the copied `my_model.m` and `my_params.m` still contain KERS/DRS symbols because they are retained as source-faithful originals. The MPCC wrapper always feeds nominal Cd and zero KERS flags, so those features are inactive at runtime.

## What was not changed

The 13-state vehicle equations, tyre-force equations, physical-time derivative returned by `my_model.m`, tyre-load lifting equations and core Shanghai source arrays were not replaced by a simpler MPC model.
