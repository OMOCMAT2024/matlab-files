# Robust nonlinear MPCC using the TOTPT F1 vehicle and Shanghai track

This is the second, convergence-oriented version of the MATLAB/CasADi/acados package. It uses the **same vehicle equations** from `source_direct_oc/my_model.m` and the same Shanghai source track arrays, but solves a nonlinear receding-horizon MPCC with acados. KERS and DRS are deliberately disabled in the MPCC wrapper: constant nominal `Cd` is supplied and both KERS flags are always zero.

## Main numerical changes from v1

1. `NONLINEAR_LS` cost + `GAUSS_NEWTON` Hessian rather than an external economic cost with an exact, potentially indefinite Hessian.
2. The direct-OCP drive/brake complementarity equality is, by default, a smooth nonlinear least-squares penalty instead of a hard equality. `cfg.constraints.strict_direct_oc=true` restores the original hard equality for comparison.
3. Direct-OCP warm starts are indexed by their **time history**, not by a constant-speed distance guess; all four lifted tyre loads are reprojected by Newton at every prediction node.
4. Shifted closed-loop guesses also reproject every algebraic load.
5. Solver status is taken from `solver.solve()`; timing uses `get_stats('time_tot')` with a legacy fallback.
6. Initial-state setting prefers `constr_x0`; statistics printing prefers the modern interface.
7. KERS/DRS schedules and their interpolation have been removed from the controller/track path.
8. Failed nonlinear solves retry from a fresh projected direct-OCP guess and then from a conservative flat guess.

## Model structure

Differential state: `[x_vehicle(13); sigma; Tt_n; Tb_n; delta_n]` (17 states).

Control: normalized physical actuator rates `[Tt_dot; Tb_dot; delta_dot]` (3 inputs).

Algebraic state: the four normalized tyre vertical loads used by the direct OCP (4 algebraic variables).

The implicit acados DAE is `[Xdot-f(X,U,Z,p); h_load(X,U,Z,p)] = 0`. Thus the controller does not discard or approximate the original lifted tyre-load equations.

Because the supplied vehicle model is already in Frenet road coordinates, its normalized `n` state is directly the contouring error and its `s_dot` kinematics provide progress. The local state `sigma` prevents absolute lap distance from becoming a poorly scaled controller state; after each plant step it is reset to zero and the track anchor parameter is advanced by exactly the same distance.

## Robust default solver

- `Ts = 0.05 s`, `N = 20` (1.0 s horizon)
- IRK, 3-stage Gauss-Radau IIA, 1 integration step/shooting interval
- full `SQP`, maximum 40 iterations
- `PARTIAL_CONDENSING_HPIPM`, ROBUST mode
- nonlinear least squares + Gauss-Newton Hessian
- `PROJECT` regularization and `MERIT_BACKTRACKING` globalization
- small Levenberg-Marquardt regularization where supported
- shifted warm start with algebraic-load reprojection

The controller keeps power, slip, track footprint, tyre-load, state, actuator, actuator-rate, progress-direction and Frenet-denominator constraints. The same nonlinear path constraints are imposed at the shooting nodes, including the fixed initial node; the closed-loop plant and algebraic projection are therefore designed to keep the measured state feasible. If future work adds disturbances large enough to violate track/performance constraints, softening selected path constraints is preferable to silently deleting them.

## Plant

Default `cfg.plant.method='rk4_newton'` integrates the same 13 physical-time vehicle ODEs with fixed-step RK4. At every RK stage, the same four lifted-load equations are solved by damped Newton. This gives a fixed and customizable real-time-style plant step while keeping controller path constraints off the plant.

Optional `cfg.plant.method='acados_irk_dae'` uses acados IRK directly on the same DAE.

## Run order

In the same MATLAB environment where acados examples already run:

```matlab
cd <this package>
startup_mpcc_package
report = run_preflight();
result_short = run_short_smoke_test();
result = run_mpcc_totpt_nmpcc();
```

For all checks:

```matlab
startup_mpcc_package
run_all_checks
```

For strict direct-OCP complementarity:

```matlab
cfg = mpcc_default_config();
cfg.constraints.strict_direct_oc = true;
result = run_mpcc_totpt_nmpcc(cfg);
```

Robust mode is recommended first.

## Important verification boundary

The package has been source-audited, consistency-checked, archive-tested, and rewritten against the current acados MATLAB API conventions available in the official documentation. The execution environment used to build this package does not contain your Windows MATLAB/acados/MEX toolchain, so the final target-specific C/MEX compilation can only be proven on your PC. `run_preflight` performs non-compiling symbolic/model checks; `run_short_smoke_test` is the deliberately small first compile-and-run test.

See `docs/INVESTIGATION_V1.md`, `docs/DESIGN_AND_CONVERGENCE.md`, and the accompanying PDF tutorial for the detailed rationale.

## MATLAB acados interface compatibility note

The runtime wrappers deliberately use the common MATLAB API supported by both
acados v0.5.4 and v0.5.5: `solver.solve()` is called without an output, status
is read with `solver.get('status')`, timing with `solver.get('time_tot')`, and
stage parameters are set one node at a time via `solver.set('p',p,stage)`.
This avoids the v0.5.5-only stage-range setter in mixed installations.


## v8 finite-bound compatibility fix

The nonlinear OCP no longer sends `+/-Inf` on intentionally inactive sides of
one-sided constraints.  It uses a finite redundant dimensionless bound of 10,
shared by solver construction and preflight.  This avoids older MATLAB/acados
JSON pipelines interpreting an infinite side incorrectly.  The physical active
limits (power, slip, track, tyre load, progress and Frenet denominator) are
unchanged.  Preflight now audits every shooting-node state and nonlinear
constraint against the exact bounds passed to acados for both the direct-OCP
and conservative-flat initial guesses.
