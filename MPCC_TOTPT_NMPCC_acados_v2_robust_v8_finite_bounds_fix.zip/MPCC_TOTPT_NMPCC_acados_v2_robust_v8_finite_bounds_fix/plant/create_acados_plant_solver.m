function plant = create_acados_plant_solver(cfg,dyn)
%CREATE_ACADOS_PLANT_SOLVER Optional fixed-horizon IRK DAE plant integrator.
% The simulation model contains ONLY the same implicit DAE used by the
% controller; OCP costs and path constraints are intentionally not copied.
% This matches the requested plant/controller separation.

% Build a slim AcadosModel so the simulator sees dynamics only.
m = AcadosModel();
m.name = [cfg.acados.model_name '_plant_model'];
m.x = dyn.model.x;
m.xdot = dyn.model.xdot;
m.u = dyn.model.u;
m.z = dyn.model.z;
m.p = dyn.model.p;
m.f_impl_expr = dyn.model.f_impl_expr;

sim = AcadosSim();
sim.model = m;
if isprop(sim,'name')
    sim.name = [cfg.acados.model_name '_plant'];
end
sim.parameter_values = 0.0;
sim.solver_options.integrator_type = 'IRK';
sim.solver_options.num_stages = cfg.plant.irk_num_stages;
sim.solver_options.num_steps = cfg.plant.irk_num_steps;
sim.solver_options.newton_iter = cfg.plant.irk_newton_iter;
sim.solver_options.newton_tol = cfg.plant.irk_newton_tol;
sim.solver_options.collocation_type = cfg.plant.collocation_type;
sim.solver_options.output_z = true;
sim.solver_options.Tsim = cfg.controller.Ts;
% No sensitivities are needed for a stand-alone plant simulation.
sim.solver_options.sens_forw = false;
sim.solver_options.sens_adj = false;
sim.solver_options.sens_hess = false;
try sim.solver_options.sens_algebraic = false; catch, end

% Use a distinct short export folder so OCP and simulator objects do not collide.
build_dir = fullfile(cfg.acados.build_dir,'plant');
if ~exist(build_dir,'dir'), mkdir(build_dir); end
code_dir = fullfile(build_dir,'c_generated_code_sim');
if ~exist(code_dir,'dir'), mkdir(code_dir); end
sim.code_gen_options.code_export_directory = code_dir;
sim.code_gen_options.json_file = fullfile(code_dir,[cfg.acados.model_name '_plant_sim.json']);
% AcadosSimSolver compiles its generic MATLAB interface relative to the current
% folder on some interface versions. Construct it from the same short build
% tree to avoid Windows/MinGW path-length failures.
old_dir = pwd;
cleanup = onCleanup(@() cd(old_dir)); %#ok<NASGU>
cd(build_dir);
plant.solver = AcadosSimSolver(sim);
plant.sim = sim;
end
