function [xnext,znext,info] = plant_step_acados_irk(plant,dyn,x,u,z,p,cfg)
%PLANT_STEP_ACADOS_IRK One fixed Ts IRK DAE plant step.
% The plant has no OCP path constraints. The algebraic tyre-load equations
% remain part of f_impl_expr because they are part of the supplied model.
S=plant.solver;

% Start from an algebraically consistent load vector. This also gives an
% implicit-derivative initial guess for IRK Newton iterations.
[z0,ok0,res0]=solve_lifted_loads_newton(dyn,x,u,z,p,cfg.plant);
if ~ok0
    error('MPCC:AcadosPlantLoad','Pre-IRK load projection failed (%.3e).',res0);
end
xdot0=full(dyn.f(x,u,z0,p));

% acados >= v0.5 exposes simulate(x,u,z,xdot,p) for implicit integrators.
% Keep conservative fallbacks for MATLAB-interface variants while retaining
% exactly the same AcadosSim DAE formulation.
try
    xnext=S.simulate(x,u,z0,xdot0,p);
catch ME5
    try
        S.set('p',p);
        xnext=S.simulate(x,u,z0,xdot0);
    catch ME4
        try
            S.set('p',p);
            S.set('z',z0);
            S.set('xdot',xdot0);
            S.set('x',x);
            S.set('u',u);
            S.solve();
            xnext=full(S.get('x'));
        catch MEset
            error('MPCC:AcadosPlantSim',[ ...
                'Acados DAE plant integration failed. simulate(x,u,z,xdot,p): ' ME5.message ...
                ' | simulate after p-set: ' ME4.message ...
                ' | set/solve fallback: ' MEset.message ...
                '. Switch cfg.plant.method to ''rk4_newton'' for the default fixed-step plant.']);
        end
    end
end
xnext=full(xnext(:));

% acados reports algebraic z at the start of the simulation interval. Use it
% only as a warm-start candidate, then solve h_load=0 at xnext so the plant
% output is consistent at the end of the interval.
zguess=z0;
try
    zcand=full(S.get('z'));
    if numel(zcand)==dyn.nz && all(isfinite(zcand(:)))
        zguess=zcand(:);
    end
catch
end
[znext,ok,res]=solve_lifted_loads_newton(dyn,xnext,u,zguess,p,cfg.plant);
if ~ok
    error('MPCC:AcadosPlantLoad','Post-IRK load projection failed (%.3e).',res);
end
info.substeps=cfg.plant.irk_num_steps;
info.fixed_dt=cfg.controller.Ts/cfg.plant.irk_num_steps;
info.max_load_residual=max(res0,res);
end
