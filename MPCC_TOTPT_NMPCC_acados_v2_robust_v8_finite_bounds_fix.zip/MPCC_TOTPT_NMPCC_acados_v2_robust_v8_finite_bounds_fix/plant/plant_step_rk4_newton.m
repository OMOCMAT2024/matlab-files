function [xnext,znext,info] = plant_step_rk4_newton(dyn,x,u_rate,z,p,Ts,opts)
%PLANT_STEP_RK4_NEWTON Fixed-step RK4 of the supplied time ODEs.
% At every RK stage the four lifted tyre loads are solved implicitly. No
% controller path constraints (track/power/slip/complementarity) are imposed.
if ~(isscalar(opts.fixed_dt) && isfinite(opts.fixed_dt) && opts.fixed_dt > 0)
    error('MPCC:PlantStep','cfg.plant.fixed_dt must be a finite positive scalar.');
end
ratio = Ts/opts.fixed_dt;
M = round(ratio);
if M < 1 || abs(ratio-M) > 1e-10*max(1,abs(ratio))
    error('MPCC:PlantStep', ...
        'Controller Ts=%.16g s must be an integer multiple of plant fixed_dt=%.16g s.',Ts,opts.fixed_dt);
end
h = opts.fixed_dt;
zcur=z(:); xcur=x(:); maxres=0;
for m=1:M
    [z1,ok,r1]=solve_lifted_loads_newton(dyn,xcur,u_rate,zcur,p,opts); assert_ok(ok,r1,m,1);
    k1=full(dyn.f(xcur,u_rate,z1,p));
    x2=xcur+0.5*h*k1;
    [z2,ok,r2]=solve_lifted_loads_newton(dyn,x2,u_rate,z1,p,opts); assert_ok(ok,r2,m,2);
    k2=full(dyn.f(x2,u_rate,z2,p));
    x3=xcur+0.5*h*k2;
    [z3,ok,r3]=solve_lifted_loads_newton(dyn,x3,u_rate,z2,p,opts); assert_ok(ok,r3,m,3);
    k3=full(dyn.f(x3,u_rate,z3,p));
    x4=xcur+h*k3;
    [z4,ok,r4]=solve_lifted_loads_newton(dyn,x4,u_rate,z3,p,opts); assert_ok(ok,r4,m,4);
    k4=full(dyn.f(x4,u_rate,z4,p));
    xcur=xcur+(h/6)*(k1+2*k2+2*k3+k4);
    [zcur,ok,rf]=solve_lifted_loads_newton(dyn,xcur,u_rate,z4,p,opts); assert_ok(ok,rf,m,5);
    maxres=max([maxres,r1,r2,r3,r4,rf]);
end
xnext=xcur; znext=zcur;
info.substeps=M; info.fixed_dt=h; info.max_load_residual=maxres;
end

function assert_ok(ok,res,m,stage)
if ~ok
    error('MPCC:PlantLoadNewton','Lifted tyre-load Newton solve failed at substep %d RK stage %d (res %.3e).',m,stage,res);
end
end
