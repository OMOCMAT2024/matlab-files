function [z,ok,resnorm] = solve_lifted_loads_newton(dyn,x,u,z0,p,opts)
%SOLVE_LIFTED_LOADS_NEWTON Solve the four supplied h_load(x,u,z,p)=0 equations.
% This follows the same analytic-Jacobian damped-Newton reduction used by
% the direct-OCP package's fixed-step time simulator, with an explicit
% success flag so an MPCC plant step never silently accepts a bad load solve.
z=z0(:); ok=false; resnorm=inf;

r=full(dyn.h_load(x,u,z,p));
r=r(:);
if any(~isfinite(r)), return; end
resnorm=norm(r,inf);
if resnorm <= opts.load_newton_tol
    ok=true; return
end

for it=1:opts.load_newton_max_iter %#ok<NASGU>
    r=full(dyn.h_load(x,u,z,p));
    r=r(:);
    if any(~isfinite(r)), return; end
    resnorm=norm(r,inf);
    if resnorm <= opts.load_newton_tol
        ok=true; return
    end

    J=full(dyn.h_load_jac_z(x,u,z,p));
    if any(~isfinite(J(:))), return; end
    if rcond(J) < 1e-12
        dz=-pinv(J)*r;
    else
        dz=-(J\r);
    end
    if any(~isfinite(dz)), return; end

    alpha=1.0;
    accepted=false;
    while alpha >= opts.load_newton_damping_min
        ztry=z+alpha*dz;
        rtry=full(dyn.h_load(x,u,ztry,p));
        rtry=rtry(:);
        if all(isfinite(rtry)) && ...
                (norm(rtry,inf) <= 0.9*resnorm || norm(rtry,inf) <= opts.load_newton_tol)
            z=ztry;
            accepted=true;
            break
        end
        alpha=0.5*alpha;
    end

    if ~accepted
        % Match the guarded small-step fallback of the supplied direct-OCP
        % simulator instead of taking a full Newton step that increased the
        % algebraic residual.
        z=z+0.10*dz;
    end
end

r=full(dyn.h_load(x,u,z,p));
r=r(:);
if any(~isfinite(r)), return; end
resnorm=norm(r,inf);
ok=resnorm <= 10*opts.load_newton_tol;
end
