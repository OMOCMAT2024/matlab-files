function cfg = mpcc_default_config()
%MPCC_DEFAULT_CONFIG Robust nonlinear TOTPT/acados MPCC configuration.
root = fileparts(mfilename('fullpath'));

cfg.package_root = root;
cfg.model.source_dir = fullfile(root,'source_direct_oc');
cfg.track.data_dir = fullfile(root,'track_data','Shanghai');
cfg.reference.warmstart_file = fullfile(root,'reference_data','direct_oc_warmstart_no_kers_drs.mat');

% Controller discretization in physical time.
cfg.controller.Ts = 0.05;             % [s]
cfg.controller.N = 20;                % 1.0 s prediction horizon
cfg.controller.integrator_type = 'IRK';
cfg.controller.irk_num_stages = 3;
cfg.controller.irk_num_steps = 1;
cfg.controller.irk_newton_iter = 6;
cfg.controller.irk_newton_tol = 1e-9;
cfg.controller.collocation_type = 'GAUSS_RADAU_IIA';

% Full nonlinear SQP. The user does not linearize the vehicle model.
cfg.controller.nlp_solver_type = 'SQP';
cfg.controller.nlp_max_iter = 40;
cfg.controller.qp_solver = 'PARTIAL_CONDENSING_HPIPM';
cfg.controller.qp_cond_N = 10;
cfg.controller.qp_iter_max = 120;
cfg.controller.qp_ric_alg = 1;
cfg.controller.qp_cond_ric_alg = 1;
cfg.controller.hpipm_mode = 'ROBUST';
cfg.controller.hessian_approx = 'GAUSS_NEWTON';
cfg.controller.regularize_method = 'PROJECT';
cfg.controller.globalization = 'MERIT_BACKTRACKING';
cfg.controller.levenberg_marquardt = 1e-6;
cfg.controller.tol_stat = 2e-4;
cfg.controller.tol_eq = 2e-5;
cfg.controller.tol_ineq = 2e-5;
cfg.controller.tol_comp = 2e-5;

% Robust nonlinear least-squares MPCC cost. The desired progress speed is
% deliberately above the vehicle's feasible maximum, so minimizing this
% residual acts as a smooth maximum-progress objective while retaining a
% positive-semidefinite Gauss-Newton cost Hessian.
cfg.cost.progress_rate_reference = 1.05; % s_dot / veh.V_s
cfg.cost.q_progress = 8.0;
cfg.cost.q_contour = 0.06;
cfg.cost.q_heading = 0.08;
cfg.cost.q_roll = 0.02;
cfg.cost.q_pitch = 0.02;
cfg.cost.q_lateral_velocity = 0.01;
cfg.cost.q_yaw_rate = 0.01;
cfg.cost.q_actuator = [4e-4; 4e-4; 3e-3];
cfg.cost.q_rate = [6e-3; 6e-3; 4e-2];
cfg.cost.q_drive_brake_overlap = 12.0;
cfg.cost.q_terminal_contour = 0.20;
cfg.cost.q_terminal_heading = 0.20;
cfg.cost.q_terminal_progress = 1.0;

% Constraint treatment. Robust mode keeps the physical power/slip/track/load
% constraints hard, but moves the troublesome drive/brake complementarity
% equality into the smooth least-squares cost. Set strict_direct_oc=true to
% restore the original Tt_n*Tb_n=0 nonlinear equality for comparison.
cfg.constraints.strict_direct_oc = false;
cfg.constraints.original_tol = 1e-5;
% Use finite redundant bounds for inactive sides of nonlinear constraints.
% This avoids cross-version MATLAB/JSON handling of +/-Inf turning a one-sided
% constraint into an unintended two-sided constraint in older acados releases.
cfg.constraints.finite_inactive_bound = 10.0;
cfg.constraints.min_progress_rate_normalized = 0.0;
cfg.constraints.max_progress_rate_normalized = 1.20;
cfg.constraints.min_curvilinear_denominator = 0.08;
cfg.constraints.progress_backtrack_m = 20;
cfg.constraints.progress_horizon_factor = 1.35;

% Local curvilinear progress scaling.
cfg.scaling.progress_m = 100.0;       % [m] per normalized sigma unit

% Same Shanghai source arrays and same curvature patch used by my_oc.m.
cfg.track.num_points = 2722;
cfg.track.apply_curvature_patch = true;
cfg.track.curvature_patch_first = 17865;
cfg.track.curvature_patch_last = 22616;
cfg.track.curvature_patch_scale = 0.93;

% KERS/DRS are intentionally disabled in this MPCC package. The direct-OCP
% vehicle source still declares those symbolic parameters, but the MPCC
% always feeds kers_on=0, kers_last_on=0 and constant veh.Cd_nominal.
cfg.model.disable_kers_drs = true;

% Plant integration. Default: fixed-step RK4 with algebraic-load projection
% at every RK stage. This uses the same 13 physical-time ODEs as controller.
cfg.plant.method = 'rk4_newton';      % 'rk4_newton' or 'acados_irk_dae'
cfg.plant.fixed_dt = 1e-3;            % [s]
cfg.plant.load_newton_tol = 1e-9;
cfg.plant.load_newton_max_iter = 15;
cfg.plant.load_newton_damping_min = 1/128;
cfg.plant.irk_num_stages = 3;
cfg.plant.irk_num_steps = 3;
cfg.plant.irk_newton_iter = 10;
cfg.plant.irk_newton_tol = 1e-9;
cfg.plant.collocation_type = 'GAUSS_RADAU_IIA';

% Closed-loop run.
cfg.simulation.max_time = 120;
cfg.simulation.stop_after_laps = 1;
cfg.simulation.max_steps = ceil(cfg.simulation.max_time/cfg.controller.Ts);
cfg.simulation.make_plots = true;
cfg.simulation.print_every = 10;

% Initialization. The direct-OCP trajectory is only an initial iterate.
cfg.initialization.use_direct_oc_warmstart = true;
cfg.initialization.reuse_previous_nmpcc_solution = true;
cfg.initialization.project_loads_on_every_guess_stage = true;

% Retry policy. Each retry starts from a fresh algebraically projected guess.
cfg.robustness.retry_from_direct_oc = true;
cfg.robustness.retry_from_flat_guess = true;

% Short Windows build path.
cfg.acados.build_dir = get_totpt_nmpcc_build_dir(root);
cfg.acados.model_name = 'totpt_f1_nmpcc_v2';
end
