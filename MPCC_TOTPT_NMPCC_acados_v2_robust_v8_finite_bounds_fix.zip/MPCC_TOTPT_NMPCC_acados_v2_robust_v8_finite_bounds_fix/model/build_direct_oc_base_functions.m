function base = build_direct_oc_base_functions(cfg)
%BUILD_DIRECT_OC_BASE_FUNCTIONS Reuse the supplied direct-OCP vehicle model.
% The source my_model.m is not edited. This wrapper exposes the same
% physical-time derivatives and lifted tyre-load residuals to acados.
import casadi.*
source_dir = cfg.model.source_dir;
if ~isfile(fullfile(source_dir,'my_model.m')) || ~isfile(fullfile(source_dir,'my_params.m'))
    error('MPCC:MissingDirectOCModel','my_model.m/my_params.m not found in %s',source_dir);
end
old_dir = pwd;
cleanup = onCleanup(@() cd(old_dir)); %#ok<NASGU>
cd(source_dir);
veh = my_params();

% my_model.m is a script that creates sf dynamically in this function
% workspace. Since R2019b, MATLAB requires identifiers introduced by a
% script to be explicitly declared when a same-named function exists on
% the path. Declare sf before run() so the parser resolves it as the
% CasADi variable created by my_model.m, not the MATLAB/Stateflow sf function.
sf = []; %#ok<NASGU>
run('my_model.m');

% Fixed-power direct-OCP path constraints. KERS is intentionally omitted.
pw_drive_rear_normalized = Tt * (omega_rl+omega_rr)/2 / (Tt_s*omega_s);
pw_drive_rear_ub_normalized = veh.power_motor_max / (Tt_s*omega_s);
power_limit = pw_drive_rear_normalized - pw_drive_rear_ub_normalized;

sv = veh.slip_ratio_value;
slip_body_fl = ((1-sv)*(ux-0.5*r*veh.t1) - omega_fl*veh.rw) / (omega_s*veh.rw);
slip_body_fr = ((1-sv)*(ux+0.5*r*veh.t1) - omega_fr*veh.rw) / (omega_s*veh.rw);
slip_body_rl = ((1-sv)*(ux-0.5*r*veh.t2) - omega_rl*veh.rw) / (omega_s*veh.rw);
slip_body_rr = ((1-sv)*(ux+0.5*r*veh.t2) - omega_rr*veh.rw) / (omega_s*veh.rw);
h_performance = [power_limit; slip_body_fl; slip_body_fr; slip_body_rl; slip_body_rr];
BrTh = Tt_n*Tb_n;

base.veh = veh;
base.nx_vehicle = nx;
base.nu_actuator = nu;
base.nz = nz;
base.x_s = full(x_s);
base.u_s = full(u_s);
base.z_s = full(z_s);
base.x_min = full(x_min);
base.x_max = full(x_max);
base.u_min = full(u_min);
base.u_max = full(u_max);
base.z_min = full(z_min);
base.z_max = full(z_max);
base.du_phys_min = [veh.Tt_dot_min; veh.Tb_dot_min; veh.delta_dot_min];
base.du_phys_max = [veh.Tt_dot_max; veh.Tb_dot_max; veh.delta_dot_max];
base.rate_scale = max(abs([base.du_phys_min,base.du_phys_max]),[],2);

base.f_time = Function('totpt_time_rhs_v2',{x,u,z,pv},{y_xdot,h_load,sf}, ...
    {'x','u','z','pv'},{'xdot','h_load','sf'});
base.f_performance = Function('totpt_performance_path_v2',{x,u,pv},{h_performance}, ...
    {'x','u','pv'},{'h'});
base.f_drive_brake = Function('totpt_drive_brake_v2',{u},{BrTh},{'u'},{'product'});
base.f_monitor = Function('totpt_monitor_v2',{x,u,z,pv}, ...
    {y_tyre,y_slip,y_acc,y_aero,y_torque,y_mu,y_pwr,y_load}, ...
    {'x','u','z','pv'}, {'tyre','slip','acc','aero','torque','mu','pwr','load'});
end
