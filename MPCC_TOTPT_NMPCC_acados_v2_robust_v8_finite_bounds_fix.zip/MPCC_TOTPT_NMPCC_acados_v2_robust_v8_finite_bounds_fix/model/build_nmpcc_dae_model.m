function dyn = build_nmpcc_dae_model(cfg, base, track)
%BUILD_NMPCC_DAE_MODEL Full nonlinear time-domain DAE for acados NMPCC.
% Differential state = [13 direct-OCP vehicle states; local sigma; Tt,Tb,delta]
% Control            = normalized physical actuator rates
% Algebraic state    = four lifted normalized tyre vertical loads
import casadi.*
veh = base.veh;
tf = make_casadi_track_functions(track,'nmpcc_v2');

nxv = base.nx_vehicle;
nx = nxv + 4;
nu = 3;
nz = base.nz;

X = SX.sym('X',nx,1);
Xdot = SX.sym('Xdot',nx,1);
Urate = SX.sym('Urate',nu,1);
Z = SX.sym('Z',nz,1);
p = SX.sym('p',1,1);          % lap anchor / track.L

xv = X(1:nxv);
sigma = X(nxv+1);
uact = X(nxv+2:nxv+4);
progress_s = cfg.scaling.progress_m;
s_abs = track.L*p + progress_s*sigma;
kappa = tf.kappa(s_abs);

% Deliberately disable DRS/KERS. my_model.m still declares the four-element
% pv vector, therefore constant Cd and zero KERS flags are supplied here.
pv = [kappa; veh.Cd_nominal; 0; 0];

[xdot_v,h_load,~] = base.f_time(xv,uact,Z,pv);
ux = veh.ux_s*xv(1);
uy = veh.uy_s*xv(2);
n = veh.n_s*xv(8);
xi = veh.xi_s*xv(9);
coord_den = 1 - n*kappa;
speed_along_track = ux*cos(xi) - uy*sin(xi) + veh.vx_eps;
s_dot = speed_along_track/coord_den;
sigma_dot = s_dot/progress_s;
uact_dot = (base.rate_scale./base.u_s).*Urate;
f_aug = [xdot_v; sigma_dot; uact_dot];
f_impl = [Xdot - f_aug; h_load];

model = AcadosModel();
model.name = cfg.acados.model_name;
model.x = X;
model.xdot = Xdot;
model.u = Urate;
model.z = Z;
model.p = p;
model.f_impl_expr = f_impl;

% Nonlinear constraints.
h_perf = base.f_performance(xv,uact,pv); % power + four slip constraints
margin = veh.wt/2 + veh.ws;
left_res = xv(8) - (tf.wl(s_abs)-margin)/veh.n_s;
right_res = -xv(8) - (tf.wr(s_abs)-margin)/veh.n_s;
progress_rate_n = s_dot/veh.V_s;
BrTh = base.f_drive_brake(uact);

if cfg.constraints.strict_direct_oc
    h = [BrTh; h_perf; left_res; right_res; Z; progress_rate_n; coord_den];
    h_e = [BrTh; h_perf; left_res; right_res; progress_rate_n; coord_den];
    labels = {'drive_brake_product','rear_power_limit','slip_FL','slip_FR','slip_RL','slip_RR', ...
        'track_left','track_right','Fz_FL_n','Fz_FR_n','Fz_RL_n','Fz_RR_n', ...
        'progress_rate_n','frenet_denominator'};
else
    h = [h_perf; left_res; right_res; Z; progress_rate_n; coord_den];
    h_e = [h_perf; left_res; right_res; progress_rate_n; coord_den];
    labels = {'rear_power_limit','slip_FL','slip_FR','slip_RL','slip_RR', ...
        'track_left','track_right','Fz_FL_n','Fz_FR_n','Fz_RL_n','Fz_RR_n', ...
        'progress_rate_n','frenet_denominator'};
end
model.con_h_expr = h;
model.con_h_expr_e = h_e;

% Robust NLS cost. This lets acados use a positive-semidefinite
% Gauss-Newton Hessian instead of the indefinite exact Hessian of v1.
q = cfg.cost;
y = [ ...
    sqrt(q.q_progress)*(progress_rate_n-q.progress_rate_reference); ...
    sqrt(q.q_contour)*xv(8); ...
    sqrt(q.q_heading)*xv(9); ...
    sqrt(q.q_roll)*xv(4); ...
    sqrt(q.q_pitch)*xv(6); ...
    sqrt(q.q_lateral_velocity)*xv(2); ...
    sqrt(q.q_yaw_rate)*xv(3); ...
    sqrt(q.q_actuator(1))*uact(1); ...
    sqrt(q.q_actuator(2))*uact(2); ...
    sqrt(q.q_actuator(3))*uact(3); ...
    sqrt(q.q_rate(1))*Urate(1); ...
    sqrt(q.q_rate(2))*Urate(2); ...
    sqrt(q.q_rate(3))*Urate(3); ...
    sqrt(q.q_drive_brake_overlap)*BrTh];
model.cost_y_expr = y;

% Terminal residual rewards horizon progress while keeping the terminal
% cost least-squares. The reference is a deliberately aggressive feasible-
% seeking target, not a precomputed racing line.
sigma_ref_terminal = q.progress_rate_reference*veh.V_s*(cfg.controller.N*cfg.controller.Ts)/progress_s;
y_e = [sqrt(q.q_terminal_contour)*xv(8); ...
       sqrt(q.q_terminal_heading)*xv(9); ...
       sqrt(q.q_terminal_progress)*(sigma-sigma_ref_terminal)];
model.cost_y_expr_e = y_e;

% Functions for plant, warm-start projection, diagnostics and tests.
dyn.model = model;
dyn.base = base;
dyn.track_functions = tf;
dyn.nx = nx;
dyn.nu = nu;
dyn.nz = nz;
dyn.nh = length(labels);
dyn.nh_e = size(h_e,1);
dyn.path_labels = labels;
dyn.idx.vehicle = 1:nxv;
dyn.idx.sigma = nxv+1;
dyn.idx.actuator = nxv+2:nxv+4;
dyn.s_scale = progress_s;
dyn.ny = size(y,1);
dyn.ny_e = size(y_e,1);
dyn.f = Function('totpt_aug_rhs_v2',{X,Urate,Z,p},{f_aug},{'x','u','z','p'},{'xdot'});
dyn.h_load = Function('totpt_aug_load_res_v2',{X,Urate,Z,p},{h_load},{'x','u','z','p'},{'h'});
dyn.h_load_jac_z = Function('totpt_aug_load_jacz_v2',{X,Urate,Z,p},{jacobian(h_load,Z)},{'x','u','z','p'},{'J'});
dyn.path = Function('totpt_aug_path_v2',{X,Urate,Z,p},{h},{'x','u','z','p'},{'h'});
dyn.path_e = Function('totpt_aug_path_e_v2',{X,p},{h_e},{'x','p'},{'h'});
dyn.sdot = Function('totpt_aug_sdot_v2',{X,p},{s_dot,coord_den},{'x','p'},{'sdot','coord_den'});
dyn.pv = Function('totpt_track_pv_v2',{X,p},{pv},{'x','p'},{'pv'});
dyn.cost_y = Function('totpt_cost_y_v2',{X,Urate,Z,p},{y},{'x','u','z','p'},{'y'});
end
