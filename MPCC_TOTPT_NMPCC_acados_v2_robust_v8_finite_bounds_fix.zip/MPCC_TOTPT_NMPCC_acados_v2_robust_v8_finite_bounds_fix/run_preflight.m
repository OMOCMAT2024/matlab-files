function report = run_preflight()
%RUN_PREFLIGHT Root-level wrapper for the non-compiling package checks.
startup_mpcc_package();
report = run_package_preflight();
end
