function validate_mpcc_config(cfg)
%VALIDATE_MPCC_CONFIG Numerical/configuration consistency checks.
assert(isscalar(cfg.controller.Ts) && isfinite(cfg.controller.Ts) && cfg.controller.Ts>0,'MPCC:Config','Ts must be positive.');
assert(isscalar(cfg.controller.N) && cfg.controller.N>=1 && cfg.controller.N==round(cfg.controller.N),'MPCC:Config','N must be a positive integer.');
assert(cfg.scaling.progress_m>0 && isfinite(cfg.scaling.progress_m),'MPCC:Config','progress_m must be positive.');
assert(cfg.controller.irk_num_stages>=1 && cfg.controller.irk_num_stages==round(cfg.controller.irk_num_stages),'MPCC:Config','IRK stages must be integer.');
assert(cfg.controller.irk_num_steps>=1 && cfg.controller.irk_num_steps==round(cfg.controller.irk_num_steps),'MPCC:Config','IRK steps must be integer.');
assert(cfg.controller.irk_newton_iter>=1 && cfg.controller.irk_newton_iter==round(cfg.controller.irk_newton_iter),'MPCC:Config','IRK Newton iter must be integer.');
assert(any(strcmp(cfg.controller.collocation_type,{'GAUSS_RADAU_IIA','GAUSS_LEGENDRE'})),'MPCC:Config','Unsupported collocation type.');
assert(strcmp(cfg.controller.hessian_approx,'GAUSS_NEWTON'),'MPCC:Config','v2 robust default requires GAUSS_NEWTON Hessian.');
assert(cfg.constraints.min_curvilinear_denominator>0,'MPCC:Config','Frenet denominator guard must be positive.');
assert(cfg.constraints.max_progress_rate_normalized>cfg.constraints.min_progress_rate_normalized,'MPCC:Config','Progress-rate bounds inconsistent.');
assert(cfg.cost.progress_rate_reference>0,'MPCC:Config','Progress-rate reference must be positive.');
assert(all(cfg.cost.q_actuator>=0) && all(cfg.cost.q_rate>=0),'MPCC:Config','NLS weights must be nonnegative.');
assert(cfg.cost.q_progress>0 && cfg.cost.q_drive_brake_overlap>=0,'MPCC:Config','Progress/overlap weights invalid.');
if strcmpi(cfg.plant.method,'rk4_newton')
    assert(cfg.plant.fixed_dt>0 && isfinite(cfg.plant.fixed_dt),'MPCC:Config','Plant fixed_dt must be positive.');
    ratio=cfg.controller.Ts/cfg.plant.fixed_dt;
    assert(abs(ratio-round(ratio))<=1e-10*max(1,abs(ratio)),'MPCC:Config','Ts must be an integer multiple of fixed_dt.');
elseif strcmpi(cfg.plant.method,'acados_irk_dae')
    assert(cfg.plant.irk_num_stages>=1 && cfg.plant.irk_num_steps>=1 && cfg.plant.irk_newton_iter>=1,'MPCC:Config','Plant IRK options invalid.');
else
    error('MPCC:Config','Unknown plant method: %s',cfg.plant.method);
end
if ~isfield(cfg.constraints,'finite_inactive_bound') || ...
        ~isscalar(cfg.constraints.finite_inactive_bound) || ...
        ~isfinite(cfg.constraints.finite_inactive_bound) || cfg.constraints.finite_inactive_bound < 5
    error('MPCC:BadConfig','constraints.finite_inactive_bound must be finite and >= 5.');
end

end
