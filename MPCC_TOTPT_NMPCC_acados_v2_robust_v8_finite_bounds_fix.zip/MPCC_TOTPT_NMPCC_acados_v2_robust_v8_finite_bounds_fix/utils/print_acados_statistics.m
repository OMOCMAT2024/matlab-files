function print_acados_statistics(solver)
%PRINT_ACADOS_STATISTICS Compatible statistics printer.
try
    solver.print_statistics();
catch
    try solver.print('stat'); catch, end
end
end
