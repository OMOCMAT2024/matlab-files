function set_initial_state_constraint(solver,x)
%SET_INITIAL_STATE_CONSTRAINT Update measured stage-0 equality.
% Prefer the documented MATLAB closed-loop setter; keep stagewise fallback.
try
    solver.set('constr_x0',x);
catch ME_x0
    try
        solver.set('lbx',x,0);
        solver.set('ubx',x,0);
    catch ME_bounds
        error('MPCC:SetInitialStateFailed', ...
            'constr_x0 failed: %s | stagewise lbx/ubx failed: %s',ME_x0.message,ME_bounds.message);
    end
end
end
