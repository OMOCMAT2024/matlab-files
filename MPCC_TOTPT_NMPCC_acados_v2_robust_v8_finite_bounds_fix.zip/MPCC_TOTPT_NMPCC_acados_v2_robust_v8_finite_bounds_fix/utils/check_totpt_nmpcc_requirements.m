function check_totpt_nmpcc_requirements()
%CHECK_TOTPT_NMPCC_REQUIREMENTS Fail early if the modern acados/CasADi MATLAB API is absent.
required_classes = {'AcadosOcp','AcadosOcpSolver','AcadosModel','AcadosSim','AcadosSimSolver'};
for i = 1:numel(required_classes)
    if exist(required_classes{i},'class') ~= 8
        error('MPCC:AcadosInterfaceMissing', ...
            'Required acados MATLAB class %s is not on the MATLAB path.',required_classes{i});
    end
end
try
    import casadi.* %#ok<IMPORT>
    q = SX.sym('q'); %#ok<NASGU>
catch ME
    error('MPCC:CasadiInterfaceMissing','CasADi MATLAB interface is not usable: %s',ME.message);
end
end
