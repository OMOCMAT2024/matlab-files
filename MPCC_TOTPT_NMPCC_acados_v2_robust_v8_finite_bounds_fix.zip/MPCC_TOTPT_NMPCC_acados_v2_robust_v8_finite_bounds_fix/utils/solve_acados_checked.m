function [status,time_tot] = solve_acados_checked(solver)
%SOLVE_ACADOS_CHECKED Solve with AcadosOcpSolver across v0.5.4/v0.5.5 APIs.
% AcadosOcpSolver.solve() is a void method in both interfaces.  Read solver
% status and timing after the solve through the stable MATLAB get() API.
solver.solve();
status = full(solver.get('status'));
status = status(1);

time_tot = nan;
try
    time_tot = full(solver.get('time_tot'));
    time_tot = time_tot(1);
catch
    % Keep timing optional: status is the authoritative solve result.
end
end
