function set_stage_parameter_all(solver,p,N)
%SET_STAGE_PARAMETER_ALL Set p at every OCP node with cross-version API.
% v0.5.4 accepts solver.set('p',p,stage). v0.5.5 also accepts this form,
% while adding a stage-range setter.  The stagewise form is therefore the
% common denominator and avoids silent failures on pre-v0.5.5 interfaces.
p = full(p(:));
for stage = 0:N
    solver.set('p',p,stage);
end
end
