function plot_mpcc_results(result,track,base)
%PLOT_MPCC_RESULTS Basic closed-loop diagnostics.
t=result.time;
figure('Name','TOTPT nonlinear MPCC - track'); hold on; grid on; axis equal;
plot(track.P_L(:,1),track.P_L(:,2),'LineWidth',1.0);
plot(track.P_R(:,1),track.P_R(:,2),'LineWidth',1.0);
plot(track.x,track.y,'--','LineWidth',0.75);
plot(result.X_global,result.Y_global,'LineWidth',1.4);
legend('Left boundary','Right boundary','Centerline','NMPCC plant','Location','best');
xlabel('X [m]'); ylabel('Y [m]'); title('Closed-loop plant trajectory');

figure('Name','TOTPT nonlinear MPCC - states');
subplot(3,1,1); plot(t,3.6*result.x_vehicle_phys(1,:)); grid on; ylabel('u_x [km/h]');
subplot(3,1,2); plot(t,result.x_vehicle_phys(8,:)); grid on; ylabel('n [m]');
subplot(3,1,3); plot(t,rad2deg(result.x_vehicle_phys(9,:))); grid on; ylabel('\xi [deg]'); xlabel('time [s]');

figure('Name','TOTPT nonlinear MPCC - actuators');
subplot(4,1,1); stairs(t,result.actuator_phys(1,:)); grid on; ylabel('T_t [Nm]');
subplot(4,1,2); stairs(t,result.actuator_phys(2,:)); grid on; ylabel('T_b [Nm]');
subplot(4,1,3); stairs(t,rad2deg(result.actuator_phys(3,:))); grid on; ylabel('\delta [deg]');
subplot(4,1,4); plot(t(1:end-1),1e3*result.solve_time); grid on; ylabel('solve [ms]'); xlabel('time [s]');

figure('Name','TOTPT nonlinear MPCC - tyre loads');
plot(t,result.z_phys.'); grid on; xlabel('time [s]'); ylabel('F_z [N]');
legend('FL','FR','RL','RR');

fprintf('Maximum normalized lifted-load residual in logged sample points: %.3e\n',max(result.load_residual_inf));
fprintf('Maximum acados solve time: %.3f ms, median %.3f ms\n',1e3*max(result.solve_time),1e3*median(result.solve_time));
end
