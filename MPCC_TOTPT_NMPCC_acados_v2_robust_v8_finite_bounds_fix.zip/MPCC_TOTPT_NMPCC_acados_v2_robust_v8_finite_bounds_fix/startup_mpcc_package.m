function root = startup_mpcc_package()
%STARTUP_MPCC_PACKAGE Add only the runtime folders required by this package.
root = fileparts(mfilename('fullpath'));
addpath(root);
addpath(fullfile(root,'controller'));
addpath(fullfile(root,'model'));
addpath(fullfile(root,'plant'));
addpath(fullfile(root,'track'));
addpath(fullfile(root,'initialization'));
addpath(fullfile(root,'utils'));
addpath(fullfile(root,'tests'));
addpath(fullfile(root,'source_direct_oc'));

if exist('AcadosOcp','class') ~= 8
    error('MPCC:AcadosMissing', ['AcadosOcp is not on the MATLAB path. ' ...
        'Run the acados MATLAB environment setup first (on Windows: acados_env_variables_windows).']);
end
if exist('casadi.SX','class') ~= 8 && exist('SX','class') ~= 8
    try
        import casadi.* %#ok<IMPORT>
    catch ME
        error('MPCC:CasadiMissing','CasADi is not available: %s',ME.message);
    end
end
end
