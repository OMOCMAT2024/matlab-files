function result = run_short_smoke_test()
%RUN_SHORT_SMOKE_TEST Build the solver and run 0.5 seconds closed loop.
cfg=mpcc_default_config();
cfg.simulation.max_time=0.5;
cfg.simulation.max_steps=round(cfg.simulation.max_time/cfg.controller.Ts);
cfg.simulation.stop_after_laps=inf;
cfg.simulation.print_every=1;
cfg.simulation.make_plots=false;
result=run_mpcc_totpt_nmpcc(cfg);
end
