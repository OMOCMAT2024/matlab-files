function build_dir = get_totpt_nmpcc_build_dir(package_root)
%GET_TOTPT_NMPCC_BUILD_DIR Short writable acados build directory.
% Windows/MinGW can create very long dependency paths for generated CasADi
% functions, so deliberately prefer a drive-root folder with no spaces.
if nargin < 1 || isempty(package_root)
    package_root = fileparts(mfilename('fullpath'));
end

explicit_dir = getenv('TOTPT_NMPCC_BUILD_DIR');
if isempty(explicit_dir)
    % Also honor the environment variable used by the supplied repeat-safe
    % MPCC package so the user's already-working Windows setup can be reused.
    explicit_dir = getenv('MPCC_ACADOS_BUILD_DIR');
end

if ~isempty(explicit_dir)
    if is_absolute_path_local(explicit_dir)
        candidates = {char(explicit_dir)};
    else
        candidates = {fullfile(package_root,char(explicit_dir))};
    end
elseif ispc
    candidates = {};
    drive_token = regexp(package_root,'^[A-Za-z]:','match','once');
    if ~isempty(drive_token)
        candidates{end+1} = [drive_token filesep 'tnm55']; %#ok<AGROW>
    end
    candidates{end+1} = fullfile(tempdir,'tnm55'); %#ok<AGROW>
else
    candidates = {fullfile(package_root,'b')};
end

last_error = '';
build_dir = '';
for i = 1:numel(candidates)
    candidate = char(candidates{i});
    if contains(candidate,' ')
        last_error = sprintf('candidate contains spaces: %s',candidate);
        continue
    end
    try
        if ~exist(candidate,'dir')
            [ok,msg] = mkdir(candidate);
            if ~ok, error('%s',msg); end
        end
        probe_file = fullfile(candidate,'totpt_nmpcc_write_probe.tmp');
        fid = fopen(probe_file,'w');
        if fid < 0, error('cannot create a file in %s',candidate); end
        cleanup = onCleanup(@() close_and_delete_probe(fid,probe_file)); %#ok<NASGU>
        fwrite(fid,'ok');
        fclose(fid);
        fid = -1;
        delete(probe_file);
        clear cleanup
        build_dir = candidate;
        break
    catch ME
        last_error = ME.message;
    end
end

if isempty(build_dir)
    error('MPCC:NoWritableShortBuildDirectory', ...
        ['No short writable acados build directory could be created. Set ' ...
         'TOTPT_NMPCC_BUILD_DIR (or MPCC_ACADOS_BUILD_DIR) to a short writable ' ...
         'absolute path without spaces, for example D:\tnm55. Last error: %s'],last_error);
end
if ispc && length(build_dir) > 100
    error('MPCC:BuildDirectoryTooLong', ...
        ['The acados build directory is %d characters long. Set TOTPT_NMPCC_BUILD_DIR ' ...
         'to a shorter path such as D:\tnm55. Current path: %s'], ...
         length(build_dir),build_dir);
end
end

function close_and_delete_probe(fid,probe_file)
if fid >= 0
    try fclose(fid); catch, end
end
if exist(probe_file,'file')
    try delete(probe_file); catch, end
end
end

function tf = is_absolute_path_local(path_value)
if ispc
    tf = ~isempty(regexp(path_value,'^[A-Za-z]:[\\/]','once')) || startsWith(path_value,'\\');
else
    tf = startsWith(path_value,'/');
end
end
